import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'core/audio.dart';
import 'core/theme.dart';
import 'screens/garena_splash_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // Warm up the offline sound engine (never blocks startup on failure).
  Sfx.instance.init();
  // App is landscape-only (lobby, characters, store, match).
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: AppColors.bgBottom,
    ),
  );
  runApp(const LudoRushApp());
}

class LudoRushApp extends StatelessWidget {
  const LudoRushApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ludo Rush',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      home: const GarenaSplashScreen(),
    );
  }
}
