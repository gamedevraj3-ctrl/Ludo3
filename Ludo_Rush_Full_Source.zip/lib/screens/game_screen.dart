import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/audio.dart';
import '../core/theme.dart';
import '../game/board_map.dart';
import '../game/engine.dart';
import '../game/game_speed.dart';
import '../game/models.dart';
import '../widgets/board_painter.dart';
import '../widgets/dice_widget.dart';
import '../widgets/player_card.dart';
import '../widgets/token_widget.dart';
import 'result_screen.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({super.key, required this.config});
  final GameConfig config;

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen>
    with SingleTickerProviderStateMixin {
  late final LudoEngine engine;
  late final AnimationController _glow;
  String? _toast;
  int _lastEventStamp = 0;
  bool _navigated = false;

  @override
  void initState() {
    super.initState();
    // Landscape-only match. Board is rotated 90° left so it fills the
    // wide canvas correctly; settings/timer on the left rail, dice on the right.
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    engine = LudoEngine(
      config: widget.config,
      // Route every engine event straight into the offline sound engine.
      onSound: Sfx.instance.play,
    );
    engine.addListener(_onEngine);
    _glow = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
    WidgetsBinding.instance.addPostFrameCallback((_) => engine.start());
  }

  void _onEngine() {
    if (!mounted) return;
    // surface newest event as a toast
    if (engine.events.isNotEmpty) {
      final e = engine.events.last;
      if (e.stamp != _lastEventStamp) {
        _lastEventStamp = e.stamp;
        _toast = e.text;
        Future<void>.delayed(engine.speed.toastVisible, () {
          if (mounted && _toast == e.text) setState(() => _toast = null);
        });
      }
    }
    if (engine.finished && !_navigated) {
      _navigated = true;
      Future<void>.delayed(engine.speed.resultDelay, () {
        if (!mounted) return;
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(
            builder: (_) =>
                ResultScreen(rows: engine.results(), config: widget.config),
          ),
        );
      });
    }
    setState(() {});
  }

  @override
  void dispose() {
    engine.removeListener(_onEngine);
    engine.dispose();
    _glow.dispose();
    super.dispose();
  }

  /// Current pacing preset (can be changed mid-match from settings).
  SpeedPreset get _speed => engine.speedPreset;

  /// Pass & play (all friends on one phone) uses per-seat dice instead of the
  /// single shared roll button at the bottom of the screen.
  bool get _passAndPlay => widget.config.mode == GameMode.passAndPlay;

  /// May [p]'s own corner dice be tapped right now?
  bool _seatCanRoll(Player p) =>
      _passAndPlay &&
      !engine.finished &&
      !engine.paused &&
      engine.current.id == p.id &&
      engine.dice == null &&
      !engine.rolling &&
      !engine.moving;

  /// Base single-cell hop duration in ms, taken from the engine's speed
  /// preset so board animation and game pacing always stay in sync.
  double get _hopMs => 250 * _speed.factor;

  Future<void> _persistSpeed(SpeedPreset sp) async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('speed', sp.index);
  }

  // ------------------------------------------------------------ interactions

  void _onTapToken(Player p, int tokenIndex) {
    if (!engine.myTurn || engine.dice == null) return;
    if (p.id != engine.current.id) return;
    if (!engine.movable.contains(tokenIndex)) return;
    // No haptics — vibration-free; sound only.
    Sfx.instance.tap();
    engine.moveToken(tokenIndex);
  }


  /// Dialogs aligned with the rotated portrait match UI (not device landscape).
  Future<T?> _showPortraitDialog<T>({
    required Widget Function(BuildContext dialogCtx) builder,
  }) {
    return showGeneralDialog<T>(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'dialog',
      barrierColor: Colors.black.withValues(alpha: 0.55),
      transitionDuration: const Duration(milliseconds: 220),
      pageBuilder: (ctx, anim, secondary) {
        return SafeArea(
          child: LayoutBuilder(
            builder: (context, cts) {
              final pw = cts.maxHeight;
              final ph = cts.maxWidth;
              return Center(
                child: RotatedBox(
                  quarterTurns: 3,
                  child: SizedBox(
                    width: pw,
                    height: ph,
                    child: AnimatedBuilder(
                      animation: anim,
                      builder: (_, __) {
                        final t = Curves.easeOutCubic.transform(anim.value);
                        return Opacity(
                          opacity: t.clamp(0.0, 1.0),
                          child: Transform.scale(
                            scale: 0.92 + 0.08 * t,
                            child: Center(child: builder(ctx)),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              );
            },
          ),
        );
      },
      transitionBuilder: (context, animation, secondary, child) => child,
    );
  }

  Future<bool> _confirmExit() async {
    final res = await _showPortraitDialog<bool>(
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.panelDark,
        title: const Text('Leave match?', style: AppText.h2),
        content: Text(
          widget.config.matchMode.isClassic
              ? 'If you leave now the match ends and your current progress '
                    'is treated as final.'
              : 'If you leave now your current score is treated as final.',
          style: AppText.body,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Keep playing'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.pRed),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Leave'),
          ),
        ],
      ),
    );
    return res ?? false;
  }

  // ------------------------------------------------------------ build

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        if (await _confirmExit()) {
          if (!mounted) return;
          engine.forceFinish();
        }
      },
      child: Scaffold(
        body: Container(
          decoration: const BoxDecoration(gradient: AppColors.screenBg),
          child: Stack(
            children: [
              // subtle darker purple diagonal pattern (reference video look)
              const Positioned.fill(
                child: IgnorePointer(
                  child: CustomPaint(painter: _BackdropPainter()),
                ),
              ),
              SafeArea(
                child: LayoutBuilder(
                  builder: (context, cts) {
                    // Device is landscape, but game UI is built as PORTRAIT
                    // then rotated 90° left so board + dice + timer all match.
                    // Portrait width  = landscape height
                    // Portrait height = landscape width
                    final pw = cts.maxHeight;
                    final ph = cts.maxWidth;
                    return Center(
                      child: RotatedBox(
                        quarterTurns: 3, // 90° counter-clockwise (left)
                        child: SizedBox(
                          width: pw,
                          height: ph,
                          child: _portraitBody(pw, ph),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }


  /// Portrait match layout (rotated 90° left by [build] for landscape devices).
  /// Timer = top centre (slightly lower). Dice = centre, 90° right, raised.
  Widget _portraitBody(double pw, double ph) {
    final outer = _passAndPlay ? 0.22 : 0.0;
    final boardSize = min(
      pw * 0.88,
      ph * 0.58 / (1 + outer),
    );
    return Column(
      children: [
        // TOP — settings left, big timer centre (lower)
        Padding(
          padding: const EdgeInsets.fromLTRB(10, 40, 10, 4),
          child: Stack(
            alignment: Alignment.center,
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _circleBtn(
                      icon: Icons.settings,
                      onTap: () async {
                        engine.pause();
                        await _showSettings();
                        if (!mounted) return;
                        engine.resume();
                      },
                    ),
                    const SizedBox(width: 6),
                    const Text('Settings', style: AppText.small),
                  ],
                ),
              ),
              _portraitTimerPill(),
            ],
          ),
        ),
        // CENTRE — board
        Expanded(
          child: Center(child: _boardWithCornerDice(boardSize)),
        ),
        // BOTTOM CENTRE — dice (90° right, raised) + hint
        if (!_passAndPlay)
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 4),
            child: Transform.translate(
              offset: const Offset(0, -32),
              child: _portraitDiceBar(),
            ),
          )
        else
          const SizedBox(height: 8),
      ],
    );
  }

  Widget _portraitTimerPill() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
      decoration: BoxDecoration(
        gradient: AppColors.purplePill,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.stroke, width: 1.8),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.35),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            widget.config.timed ? Icons.timer_outlined : Icons.all_inclusive,
            size: 26,
            color: Colors.white,
          ),
          const SizedBox(width: 10),
          Text(
            widget.config.timed ? engine.clockText : 'Classic',
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w900,
              color: Colors.white,
              letterSpacing: 1.0,
            ),
          ),
        ],
      ),
    );
  }

  Widget _portraitDiceBar() {
    final myTurn = engine.myTurn;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          engine.finished
              ? ''
              : myTurn
                  ? (engine.dice == null
                      ? 'Your turn — tap the dice'
                      : 'Select a token to move')
                  : '${engine.current.name} is playing…',
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w800,
            color: Colors.white70,
          ),
        ),
        const SizedBox(height: 4),
        // 90° right
        Transform.rotate(
          angle: pi / 2,
          child: RollDiceButton(
            value: engine.dice,
            enabled: myTurn && engine.dice == null && !engine.rolling,
            rolling: engine.rolling,
            turnProgress: engine.finished
                ? 0
                : engine.turnRemaining / widget.config.turnSeconds.toDouble(),
            ringColor: engine.current.color.main,
            // Parent is +90° CW; -pi keeps ring drain starting at screen-top.
            ringStartAngle: -pi,
            onTap: () => engine.rollDice(),
          ),
        ),
      ],
    );
  }

  // ------------- left rail: settings + clock/mode (landscape) -------------
  //
  // NOTE (update): the top-right "Your Score" purple box and the green
  // "OFFLINE" badge that used to sit under it have been removed per request
  // #5 — the live score is already shown inside each seat's own PlayerCard,
  // so this was pure duplication.
  //
  // Landscape update: this used to be a horizontal top bar stretching the
  // full portrait width; it is now a slim vertical rail down the LEFT edge
  // of the landscape screen, stacking settings above the clock/mode pill,
  // so the board itself can stay centred and un-rotated.

  Widget _leftRail() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _circleBtn(
            icon: Icons.settings,
            onTap: () async {
              // Freeze match clock, turn clock, animations and the queued
              // next-turn callbacks while the sheet is open…
              engine.pause();
              await _showSettings();
              // …and always un-freeze afterwards, however the sheet was
              // dismissed (Resume, back gesture or tap outside).
              if (!mounted) return;
              engine.resume();
            },
          ),
          const SizedBox(height: 4),
          const Text('Settings', style: AppText.small, textAlign: TextAlign.center),
          const SizedBox(height: 22),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
            decoration: BoxDecoration(
              gradient: AppColors.purplePill,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: AppColors.stroke, width: 1.6),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  widget.config.timed
                      ? Icons.timer_outlined
                      : Icons.casino_outlined,
                  color: Colors.white,
                  size: 20,
                ),
                const SizedBox(height: 4),
                Text(
                  widget.config.timed ? engine.clockText : 'CLASSIC',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    letterSpacing: 0.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _circleBtn({required IconData icon, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 52,
        height: 52,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: AppColors.purplePill,
          border: Border.all(color: AppColors.stroke, width: 1.6),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.3),
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Icon(icon, color: Colors.white, size: 26),
      ),
    );
  }

  // ---------------- board + player panels + tokens ----------------

  /// PASS & PLAY: the board plus one dice per friend sitting OUTSIDE the board,
  /// in that player's own screen corner (below/above their avatar) — exactly
  /// where Ludo King puts them. Bots mode returns the bare board unchanged.
  Widget _boardWithCornerDice(double size) {
    if (!_passAndPlay) return _boardArea(size);

    final u = size / 15.0;
    // The Ludo King plate is a wide two-segment strip, so it only needs
    // vertical room above and below the board — its width tucks in over the
    // board's own corner columns.
    final plateW = u * 4.9;
    final plateH = plateW * 0.62;
    final gap = u * 0.30;
    final pad = plateH + gap; // vertical room added above and below the board

    final occupied = {for (final p in engine.players) p.seat: p};

    return SizedBox(
      width: size,
      height: size + pad * 2,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          // the board itself, sitting between the two dice rows
          Positioned(left: 0, top: pad, child: _boardArea(size)),

          // one dice per seated friend, outside the board in their own corner
          for (final seat in Seat.values)
            if (occupied[seat] != null)
              _cornerDice(occupied[seat]!, plateW, size, pad, gap),
        ],
      ),
    );
  }

  Widget _boardArea(double size) {
    final u = size / 15.0;
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          // static board
          SizedBox(
            width: size,
            height: size,
            child: const CustomPaint(painter: BoardPainter()),
          ),

          // player cards inside the 4 corner bases
          ..._seatPanels(size, u),

          // movable-cell hints
          ..._moveHints(size, u),

          // tokens
          ..._tokens(size, u),

          // event notification bar across the bottom of the board
          // (matches the reference video's kill/announcement strip)
          if (_toast != null)
            Positioned(
              left: 0,
              right: 0,
              bottom: -size * 0.055,
              child: IgnorePointer(
                child: Center(
                  child: _SlideInBar(
                    trigger: _toast!,
                    child: Container(
                      constraints: BoxConstraints(maxWidth: size * 1.02),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 9,
                      ),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            const Color(0xFF241546).withValues(alpha: 0.96),
                            const Color(0xFF3B1F63).withValues(alpha: 0.96),
                            const Color(0xFF241546).withValues(alpha: 0.96),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(11),
                        border: Border.all(
                          color: AppColors.glow.withValues(alpha: 0.65),
                          width: 1.4,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.45),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Text(
                        _toast!,
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w800,
                          color: Colors.white,
                          height: 1.15,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  List<Widget> _seatPanels(double size, double u) {
    final widgets = <Widget>[];
    final occupied = {for (final p in engine.players) p.seat: p};

    for (final seat in Seat.values) {
      final color = seat.color;
      final origin = BoardMap.baseOrigin[color]!;
      final rect = Rect.fromLTWH(origin.c * u, origin.r * u, u * 6, u * 6);
      final p = occupied[seat];
      widgets.add(
        Positioned(
          left: rect.left,
          top: rect.top,
          width: rect.width,
          height: rect.height,
          child: p == null
              ? EmptySeatPanel(color: color, compact: size < 340)
              : PlayerCard(
                  player: p,
                  isTurn: engine.current.id == p.id && !engine.finished,
                  dice: engine.current.id == p.id ? engine.dice : null,
                  turnProgress:
                      engine.turnRemaining /
                      widget.config.turnSeconds.toDouble(),
                  compact: size < 340,
                  showScore: widget.config.timed,
                  // Pass & play draws a bigger dice in each seat's own outer
                  // board corner instead, so the panel badge is dropped.
                  // Bots mode is left exactly as it was.
                  showDice: !_passAndPlay,
                ),
        ),
      );
    }

    return widgets;
  }

  /// A single friend's dice, parked OUTSIDE the ludo board in that friend's own
  /// screen corner — below the avatar for the two bottom seats and above it for
  /// the two top seats, exactly like Ludo King. Every board colour gets its own
  /// tinted plate. PASS & PLAY only; bots mode is untouched.
  Widget _cornerDice(
    Player p,
    double plateW,
    double size,
    double pad,
    double gap,
  ) {
    final origin = BoardMap.baseOrigin[p.color]!;
    final live = _seatCanRoll(p);
    final isTurn = engine.current.id == p.id && !engine.finished;
    final rolling = engine.rolling && engine.current.id == p.id;
    final face = isTurn ? (engine.dice ?? p.lastDice) : p.lastDice;

    //   yellow -> above top-left      blue -> above top-right
    //   green  -> below bottom-left   red  -> below bottom-right
    final onLeft = origin.c == 0;
    final onTop = origin.r == 0;
    final plateH = plateW * 0.62;

    // Align each plate with its own base panel; the board spans [pad, pad+size]
    // vertically, so the top row sits just above it and the bottom row below.
    final left = onLeft ? 0.0 : size - plateW;
    final top = onTop ? pad - plateH - gap : pad + size + gap;

    return Positioned(
      left: left,
      top: top,
      width: plateW,
      height: plateH,
      child: GestureDetector(
        onTap: live
            ? () {
                engine.rollDice();
              }
            : null,
        behavior: HitTestBehavior.opaque,
        child: AnimatedScale(
          duration: const Duration(milliseconds: 220),
          scale: rolling ? 1.08 : (live ? 1.0 + 0.05 * _glow.value : 0.96),
          child: Transform.rotate(
            // a small wobble while the dice is tumbling
            angle: rolling ? sin(_glow.value * 2 * pi) * 0.10 : 0,
            child: CornerDicePlate(
              value: face,
              width: plateW,
              seatColor: p.color.main,
              seatDark: p.color.dark,
              // Keep the pin facing the board and the die facing the screen
              // edge, so all four plates mirror each other neatly.
              pinOnLeft: !onLeft,
              live: live,
              pulse: live ? _glow.value : 0.0,
              turnProgress: isTurn
                  ? engine.turnRemaining / widget.config.turnSeconds.toDouble()
                  : null,
            ),
          ),
        ),
      ),
    );
  }

  /// Target-cell rings + a floating badge above each movable pawn showing the
  /// rolled dice number (exactly like the reference gameplay video).
  List<Widget> _moveHints(double size, double u) {
    if (!engine.myTurn || engine.dice == null || engine.movable.isEmpty) {
      return const [];
    }
    final p = engine.current;
    final d = engine.dice!;
    final hints = <Widget>[];

    // 1) soft pulsing ring on every landing cell
    for (final idx in engine.movable) {
      final t = p.tokens[idx];
      // A closed classic token always lands on its own start square.
      final cell = t.open
          ? BoardMap.cellFor(p.color, t.pos + d)
          : BoardMap.cellFor(p.color, 0);
      final c = BoardMap.centerOf(cell, size);
      hints.add(
        Positioned(
          left: c.dx - u * 0.44,
          top: c.dy - u * 0.44,
          child: IgnorePointer(
            child: AnimatedBuilder(
              animation: _glow,
              builder: (_, __) => Container(
                width: u * 0.88,
                height: u * 0.88,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: p.color.main.withValues(
                    alpha: 0.14 + 0.16 * _glow.value,
                  ),
                  border: Border.all(
                    color: p.color.main.withValues(
                      alpha: 0.55 + 0.4 * _glow.value,
                    ),
                    width: u * 0.075,
                  ),
                ),
              ),
            ),
          ),
        ),
      );
    }

    // 2) dice-number badge hovering over each pawn that can make that move
    final seen = <String>{};
    for (final idx in engine.movable) {
      final t = p.tokens[idx];
      final cell = t.open
          ? BoardMap.cellFor(p.color, t.pos)
          : BoardMap.yardSlot(p.color, t.index);
      final key = '${cell.r}_${cell.c}';
      if (!seen.add(key)) continue; // one badge per stack
      final c = BoardMap.centerOf(cell, size);
      hints.add(
        Positioned(
          left: c.dx - u * 0.40,
          top: c.dy - u * 1.42,
          child: IgnorePointer(
            child: AnimatedBuilder(
              animation: _glow,
              builder: (_, __) => Transform.translate(
                offset: Offset(0, -u * 0.10 * _glow.value),
                child: _MoveBadge(number: d, color: p.color, unit: u),
              ),
            ),
          ),
        ),
      );
    }
    return hints;
  }

  List<Widget> _tokens(double size, double u) {
    final widgets = <Widget>[];

    // Group tokens by grid cell, then merge same-colored tokens of the same
    // player into one pawn carrying a count badge (keeps the board readable).
    final Map<String, List<_TokenRef>> byCell = {};
    for (final p in engine.players) {
      for (final t in p.tokens) {
        // Classic mode: a token that has not been opened yet waits in its
        // own base yard instead of sitting on the start square.
        final cell = t.open
            ? BoardMap.cellFor(p.color, t.pos)
            : BoardMap.yardSlot(p.color, t.index);
        final key = '${cell.r}_${cell.c}';
        byCell.putIfAbsent(key, () => []).add(_TokenRef(p, t, cell));
      }
    }

    byCell.forEach((key, list) {
      // sub-group by owner so 4 tokens of one colour show as a single stack
      final Map<int, List<_TokenRef>> byOwner = {};
      for (final ref in list) {
        byOwner.putIfAbsent(ref.player.id, () => []).add(ref);
      }

      final groups = byOwner.values.toList();
      // Stacks belonging to whoever currently holds the turn (works for both
      // Bots and Play & Pass — "current" is simply whichever seat is active
      // right now) are collected separately and appended LAST below, so they
      // always paint on top of any other colour sharing this cell. Position
      // (dx/dy fan angle) still uses the original group index `g`, so the
      // layout doesn't visually shuffle when the turn changes — only the
      // paint order and size change.
      final below = <Widget>[];
      final onTop = <Widget>[];

      for (var g = 0; g < groups.length; g++) {
        final stack = groups[g];
        final p = stack.first.player;
        final base = BoardMap.centerOf(stack.first.cell, size);

        // fan out different players sharing one safe cell
        final n = groups.length;
        double dx = 0, dy = 0;
        if (n > 1) {
          final a = (2 * pi / n) * g - pi / 2;
          final r = u * (n == 2 ? 0.18 : 0.24);
          dx = cos(a) * r;
          dy = sin(a) * r;
        }

        // pick the token that can move (so tapping the stack always works)
        _TokenRef pickable = stack.first;
        for (final ref in stack) {
          if (engine.movable.contains(ref.token.index)) {
            pickable = ref;
            break;
          }
        }

        final canMove =
            engine.myTurn &&
            engine.dice != null &&
            engine.current.id == p.id &&
            engine.movable.contains(pickable.token.index);

        final animating =
            engine.current.id == p.id &&
            stack.any((r) => r.token.index == engine.animatingToken);

        // This stack belongs to whichever seat currently holds the turn —
        // give it a size boost and top z-order so it's always the easy,
        // obvious one to tap when several colours share a cell.
        final isCurrentTurnStack =
            !engine.finished && engine.current.id == p.id;

        final pawnW =
            u *
            (stack.first.token.finished ? 0.60 : 0.80) *
            (isCurrentTurnStack ? 1.22 : 1.0);

        // Slide duration follows the engine's humanized hop timing so the
        // pawn glides between cells instead of teleporting.
        final hopping =
            engine.hopToken != null &&
            engine.current.id == p.id &&
            stack.any((r) => r.token.index == engine.hopToken);

        final widget = AnimatedPositioned(
          key: ValueKey('stk_${p.id}_${key}_$g'),
          duration: Duration(
            milliseconds: (_hopMs * (hopping ? 0.86 : 0.5)).round(),
          ),
          curve: Curves.easeInOut,
          left: base.dx + dx - pawnW / 2,
          top: base.dy + dy - pawnW * 0.78,
          child: GestureDetector(
            onTap: canMove ? () => _onTapToken(p, pickable.token.index) : null,
            behavior: HitTestBehavior.opaque,
            child: AnimatedBuilder(
              animation: _glow,
              builder: (_, __) => _HopBounce(
                // re-trigger the little jump on every single-cell hop
                trigger: hopping ? engine.hopSeq : -1,
                height: pawnW * 0.26,
                duration: Duration(milliseconds: (_hopMs * 0.8).round()),
                child: Pawn(
                  color: p.color,
                  size: pawnW,
                  highlight: canMove || animating,
                  glowPhase: _glow.value,
                  count: stack.length,
                ),
              ),
            ),
          ),
        );

        if (isCurrentTurnStack) {
          onTop.add(widget);
        } else {
          below.add(widget);
        }
      }

      widgets.addAll(below);
      widgets.addAll(onTop);
    });

    return widgets;
  }

  // ---------------- right rail: roll dice + hint (landscape) ----------------

  // NOTE (update): the bottom-right "Score" leaderboard button has been
  // removed per request #5 — it duplicated info already visible on every
  // seat's own PlayerCard.
  //
  // Landscape update: this used to be a horizontal bottom bar; it is now a
  // slim vertical rail down the RIGHT edge of the landscape screen (bots
  // mode only — pass & play has a dice in every board corner already and
  // needs no shared rail here).
  Widget _rightRail() {
    final myTurn = engine.myTurn;
    // Pass & play gives every friend their own dice in their own board corner,
    // so there is no shared roll button and no name plate here at all.
    final pnp = _passAndPlay;
    if (pnp) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          RollDiceButton(
            value: engine.dice,
            enabled: myTurn && engine.dice == null && !engine.rolling,
            rolling: engine.rolling,
            turnProgress: engine.finished
                ? 0
                : engine.turnRemaining / widget.config.turnSeconds.toDouble(),
            ringColor: engine.current.color.main,
            onTap: () {
              engine.rollDice();
            },
            // sound is emitted by the engine itself (roll / six / etc.)
          ),
          const SizedBox(height: 10),
          AnimatedOpacity(
            opacity: engine.finished ? 0 : 1,
            duration: const Duration(milliseconds: 200),
            child: Text(
              engine.finished
                  ? ''
                  : myTurn
                  ? (engine.dice == null
                        ? 'Your turn\ntap the dice'
                        : 'Select a token\nto move')
                  : '${engine.current.name}\nis playing…',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 11.5,
                fontWeight: FontWeight.w800,
                color: myTurn ? AppColors.gold : Colors.white70,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Settings panel slides up from the *visual* bottom (dice side).
  /// Game UI is RotatedBox(quarterTurns: 3); a normal ModalBottomSheet
  /// would rise from the physical bottom and look like it comes from the side.
  Future<void> _showSettings() async {
    await showGeneralDialog<void>(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'Settings',
      barrierColor: Colors.black.withValues(alpha: 0.55),
      transitionDuration: const Duration(milliseconds: 280),
      pageBuilder: (ctx, anim, secondary) {
        return SafeArea(
          child: LayoutBuilder(
            builder: (context, cts) {
              // Same portrait mapping as the match UI.
              final pw = cts.maxHeight;
              final ph = cts.maxWidth;
              return Center(
                child: RotatedBox(
                  quarterTurns: 3,
                  child: SizedBox(
                    width: pw,
                    height: ph,
                    child: AnimatedBuilder(
                      animation: anim,
                      builder: (_, __) {
                        final t = Curves.easeOutCubic.transform(anim.value);
                        return Stack(
                          children: [
                            // tap outside to dismiss
                            Positioned.fill(
                              child: GestureDetector(
                                behavior: HitTestBehavior.opaque,
                                onTap: () => Navigator.pop(ctx),
                                child: const SizedBox.expand(),
                              ),
                            ),
                            Align(
                              alignment: Alignment.bottomCenter,
                              child: Transform.translate(
                                offset: Offset(0, (1 - t) * 220),
                                child: Opacity(
                                  opacity: t.clamp(0.0, 1.0),
                                  child: Material(
                                    color: AppColors.panelDark,
                                    borderRadius: const BorderRadius.vertical(
                                      top: Radius.circular(22),
                                    ),
                                    clipBehavior: Clip.antiAlias,
                                    child: ConstrainedBox(
                                      constraints: BoxConstraints(
                                        maxHeight: ph * 0.72,
                                        maxWidth: pw,
                                      ),
                                      child: SingleChildScrollView(
                                        padding: const EdgeInsets.fromLTRB(
                                          18, 16, 18, 26,
                                        ),
                                        child: _settingsBody(ctx),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                ),
              );
            },
          ),
        );
      },
      transitionBuilder: (context, animation, secondary, child) => child,
    );
  }

  Widget _settingsBody(BuildContext sheetCtx) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Settings', style: AppText.h2),
        const SizedBox(height: 6),
        const Text('Game paused', style: AppText.small),
        const SizedBox(height: 16),
        const Text('Game speed', style: AppText.small),
        const SizedBox(height: 8),
        Row(
          children: SpeedPreset.values.map((sp) {
            final sel = _speed == sp;
            return Expanded(
              child: GestureDetector(
                onTap: () {
                  engine.setSpeed(sp);
                  _persistSpeed(sp);
                  Navigator.pop(sheetCtx);
                },
                child: Container(
                  margin: const EdgeInsets.only(right: 8),
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(
                    gradient: sel ? AppColors.purplePill : null,
                    color: sel ? null : Colors.black.withValues(alpha: 0.26),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: sel ? AppColors.glow : Colors.white12,
                      width: sel ? 1.6 : 1,
                    ),
                  ),
                  child: Center(
                    child: Text(
                      sp.label,
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w800,
                        color: sel ? Colors.white : Colors.white60,
                      ),
                    ),
                  ),
                ),
              ),
            );
          }).toList(),
        ),
        const SizedBox(height: 8),
        _SoundSwitchTile(),
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.info_outline, color: Colors.white70),
          title: Text(
            '${widget.config.matchMode.label} Rules',
            style: AppText.body,
          ),
          onTap: () {
            Navigator.pop(sheetCtx);
            _showRules();
          },
        ),
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.flag, color: AppColors.pRed),
          title: const Text('Resign match', style: AppText.body),
          onTap: () {
            Navigator.pop(sheetCtx);
            engine.forceFinish();
          },
        ),
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.play_arrow, color: AppColors.online),
          title: const Text('Resume', style: AppText.body),
          onTap: () => Navigator.pop(sheetCtx),
        ),
      ],
    );
  }

  void _showRules() {
    final m = widget.config.matchMode;
    final String text;
    if (m.isClassic) {
      text =
          '• Roll a 6 to bring a token out of your base yard.\n\n'
          '• Rolling a 6 grants you an extra turn.\n\n'
          '• Land on a rival token to send it back — extra turn.\n\n'
          '• Star cells and start boxes are safe.\n\n'
          '• BLOCK: 2+ same colour on one cell cannot be cut.\n\n'
          '• Exact count needed to enter HOME.\n\n'
          '• First to bring all 4 tokens HOME wins.';
    } else if (m.isRush) {
      text =
          '• Match lasts ${widget.config.matchSeconds ~/ 60} minutes — highest score wins.\n\n'
          '• All 4 tokens start OPEN.\n\n'
          '• 1 step = 1 point. HOME = +56.\n\n'
          '• Cut steals the victim token points.\n\n'
          '• Safe stars + blocks apply.\n\n'
          '• 6 or cut = extra turn.';
    } else if (m.isKill) {
      text =
          '• KILL MODE: pehle cut, phir home.\n\n'
          '• Roll a 6 to open a token from the yard.\n\n'
          '• Bina cut ke HOME stretch band hai.\n\n'
          '• Pehli cut se saari tokens home-eligible.\n\n'
          '• Cut = extra turn. Blocks & safe zones apply.\n\n'
          '• First to bring all 4 tokens HOME wins.';
    } else {
      text =
          '• DEATH MATCH: first to ${widget.config.killTarget} kills wins.\n\n'
          '• Tokens start OPEN — chase and cut.\n\n'
          '• Har successful cut = +1 kill.\n\n'
          '• 2+ same colour stack = cannot be cut.\n\n'
          '• Safe stars apply. HOME optional.\n\n'
          '• Cut or 6 = extra turn.';
    }

    _showPortraitDialog<void>(
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.panelDark,
        title: Text(
          '${widget.config.matchMode.label} Rules',
          style: AppText.h2,
        ),
        content: SingleChildScrollView(
          child: Text(text, style: AppText.body),
        ),
        actions: [
          FilledButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Got it'),
          ),
        ],
      ),
    );
  }
}

/// In-match sound on/off row (kept stateful so the switch reacts instantly
/// without rebuilding the whole settings sheet).
class _SoundSwitchTile extends StatefulWidget {
  @override
  State<_SoundSwitchTile> createState() => _SoundSwitchTileState();
}

class _SoundSwitchTileState extends State<_SoundSwitchTile> {
  @override
  Widget build(BuildContext context) {
    final on = Sfx.instance.enabled;
    return SwitchListTile(
      contentPadding: EdgeInsets.zero,
      dense: true,
      value: on,
      activeThumbColor: AppColors.online,
      secondary: Icon(
        on ? Icons.volume_up_rounded : Icons.volume_off_rounded,
        color: on ? AppColors.online : Colors.white38,
      ),
      title: const Text('Sound effects', style: AppText.body),
      subtitle: Text(
        on ? 'Dice, hops, cuts & fanfare' : 'Muted',
        style: AppText.small,
      ),
      onChanged: (v) async {
        await Sfx.instance.setEnabled(v);
        if (!mounted) return;
        setState(() {});
        if (v) Sfx.instance.tap();
      },
    );
  }
}

class _TokenRef {
  final Player player;
  final Token token;
  final Cell cell;
  _TokenRef(this.player, this.token, this.cell);
}

/// Small floating pill showing the rolled dice number above a movable pawn.
class _MoveBadge extends StatelessWidget {
  const _MoveBadge({
    required this.number,
    required this.color,
    required this.unit,
  });

  final int number;
  final PColor color;
  final double unit;

  @override
  Widget build(BuildContext context) {
    final d = unit * 0.80;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: d,
          height: d,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color.lerp(color.main, Colors.white, 0.30)!, color.dark],
            ),
            border: Border.all(color: Colors.white, width: d * 0.10),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.4),
                blurRadius: d * 0.22,
                offset: Offset(0, d * 0.08),
              ),
            ],
          ),
          child: Text(
            '$number',
            style: TextStyle(
              fontSize: d * 0.52,
              fontWeight: FontWeight.w900,
              color: Colors.white,
              height: 1,
            ),
          ),
        ),
        // little pointer tail toward the pawn
        CustomPaint(
          size: Size(d * 0.42, d * 0.26),
          painter: _TailPainter(color.dark),
        ),
      ],
    );
  }
}

/// Fades + slides the notification bar in whenever [trigger] changes.
class _SlideInBar extends StatefulWidget {
  const _SlideInBar({required this.trigger, required this.child});
  final String trigger;
  final Widget child;

  @override
  State<_SlideInBar> createState() => _SlideInBarState();
}

class _SlideInBarState extends State<_SlideInBar>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 320),
  )..forward();

  @override
  void didUpdateWidget(_SlideInBar old) {
    super.didUpdateWidget(old);
    if (old.trigger != widget.trigger) _c.forward(from: 0);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final e = CurvedAnimation(parent: _c, curve: Curves.easeOutCubic);
    return AnimatedBuilder(
      animation: e,
      builder: (context, child) => Opacity(
        opacity: e.value,
        child: Transform.translate(
          offset: Offset(0, (1 - e.value) * 14),
          child: child,
        ),
      ),
      child: widget.child,
    );
  }
}

class _TailPainter extends CustomPainter {
  _TailPainter(this.color);
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final path = Path()
      ..moveTo(0, 0)
      ..lineTo(size.width, 0)
      ..lineTo(size.width / 2, size.height)
      ..close();
    canvas.drawPath(path, Paint()..color = color);
  }

  @override
  bool shouldRepaint(covariant _TailPainter old) => old.color != color;
}

/// Lifts the pawn in a small arc every time [trigger] changes, so a multi-cell
/// move reads as a sequence of real hops instead of one long slide.
class _HopBounce extends StatefulWidget {
  const _HopBounce({
    required this.trigger,
    required this.height,
    required this.duration,
    required this.child,
  });

  final int trigger;
  final double height;
  final Duration duration;
  final Widget child;

  @override
  State<_HopBounce> createState() => _HopBounceState();
}

class _HopBounceState extends State<_HopBounce>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: widget.duration,
  );

  @override
  void didUpdateWidget(_HopBounce old) {
    super.didUpdateWidget(old);
    if (widget.trigger != old.trigger && widget.trigger >= 0) {
      _c
        ..duration = widget.duration
        ..forward(from: 0);
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (context, child) {
        // sin arc: 0 -> up -> 0
        final lift = sin(_c.value * pi) * widget.height;
        final squash = 1.0 - sin(_c.value * pi) * 0.06;
        return Transform.translate(
          offset: Offset(0, -lift),
          child: Transform.scale(
            scaleY: squash,
            alignment: Alignment.bottomCenter,
            child: child,
          ),
        );
      },
      child: widget.child,
    );
  }
}

/// Very subtle diagonal stripe + vignette pattern behind the whole game.
class _BackdropPainter extends CustomPainter {
  const _BackdropPainter();

  @override
  void paint(Canvas canvas, Size size) {
    // diagonal stripes
    final stripe = Paint()
      ..color = Colors.white.withValues(alpha: 0.016)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 12;
    const gap = 34.0;
    for (double x = -size.height; x < size.width + size.height; x += gap) {
      canvas.drawLine(
        Offset(x, 0),
        Offset(x + size.height, size.height),
        stripe,
      );
    }

    // corner vignette so the board stays the visual focus
    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = RadialGradient(
          center: Alignment.center,
          radius: 0.95,
          colors: [Colors.transparent, Colors.black.withValues(alpha: 0.30)],
          stops: const [0.55, 1.0],
        ).createShader(Offset.zero & size),
    );
  }

  @override
  bool shouldRepaint(covariant _BackdropPainter old) => false;
}
