import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'splash_screen.dart';

/// Free Fire–style pre-boot: pure black → logo fades in slowly → hold → fade out → loading.
class GarenaSplashScreen extends StatefulWidget {
  const GarenaSplashScreen({super.key});

  @override
  State<GarenaSplashScreen> createState() => _GarenaSplashScreenState();
}

class _GarenaSplashScreenState extends State<GarenaSplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _fade = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1400),
  );

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _run();
  }

  Future<void> _run() async {
    // Black screen first, then slow fade-in of logo (FF-style).
    await Future<void>.delayed(const Duration(milliseconds: 400));
    if (!mounted) return;
    await _fade.forward();
    await Future<void>.delayed(const Duration(milliseconds: 1800));
    if (!mounted) return;
    await _fade.reverse();
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 400),
        pageBuilder: (_, a, __) =>
            FadeTransition(opacity: a, child: const SplashScreen()),
      ),
    );
  }

  @override
  void dispose() {
    _fade.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    // Real FF logo is large — ~55–65% of the shorter screen side.
    final logoSize = (size.shortestSide * 0.62).clamp(180.0, 360.0);
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: FadeTransition(
          opacity: CurvedAnimation(parent: _fade, curve: Curves.easeInOut),
          child: Image.asset(
            'assets/ui/garena_logo.png',
            width: logoSize,
            height: logoSize,
            fit: BoxFit.contain,
            errorBuilder: (_, __, ___) => Icon(
              Icons.sports_esports,
              size: logoSize * 0.55,
              color: const Color(0xFFE10600),
            ),
          ),
        ),
      ),
    );
  }
}
