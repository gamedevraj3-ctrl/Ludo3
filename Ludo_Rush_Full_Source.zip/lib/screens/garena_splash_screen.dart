import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'splash_screen.dart';

/// Free Fire–style pre-boot: black screen + red Garena dragon logo,
/// then resource-loading splash.
class GarenaSplashScreen extends StatefulWidget {
  const GarenaSplashScreen({super.key});

  @override
  State<GarenaSplashScreen> createState() => _GarenaSplashScreenState();
}

class _GarenaSplashScreenState extends State<GarenaSplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _fade = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 700),
  );

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _run();
  }

  Future<void> _run() async {
    await _fade.forward();
    await Future<void>.delayed(const Duration(milliseconds: 1600));
    if (!mounted) return;
    await _fade.reverse();
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 350),
        pageBuilder: (_, a, __) =>
            FadeTransition(opacity: a, child: const SplashScreen()),
      ),
    );
  }

  @override
  void dispose() {
    _fade.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.sizeOf(context).height;
    final logoSize = (h * 0.42).clamp(120.0, 220.0);
    return Scaffold(
      backgroundColor: Colors.black,
      body: FadeTransition(
        opacity: _fade,
        child: Center(
          child: Image.asset(
            'assets/ui/garena_logo.png',
            width: logoSize,
            height: logoSize,
            fit: BoxFit.contain,
            errorBuilder: (_, __, ___) => Icon(
              Icons.sports_esports,
              size: logoSize * 0.6,
              color: const Color(0xFFE10600),
            ),
          ),
        ),
      ),
    );
  }
}
