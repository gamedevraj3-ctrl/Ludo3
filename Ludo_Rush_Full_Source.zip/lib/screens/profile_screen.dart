import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/audio.dart';
import '../game/characters.dart' as roster;
import '../widgets/avatar.dart';

/// Free Fire–style profile screen (same layout as reference):
/// left vertical tabs · centre full-body character · right ID / ranks / stats.
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({
    super.key,
    required this.name,
    required this.character,
    required this.onEditName,
    required this.onChangeCharacter,
  });

  final String name;
  final String character;
  final VoidCallback onEditName;
  final Future<void> Function() onChangeCharacter;

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late String _name = widget.name;
  late String _character = widget.character;
  int _tab = 0; // Gallery / Overview / History

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
  }

  String get _uid {
    final h = _name.codeUnits.fold(0, (a, b) => (a * 31 + b) & 0x7FFFFFFF);
    return (100000000 + (h % 900000000)).toString();
  }

  int get _likes {
    final h = _name.codeUnits.fold(0, (a, b) => (a * 17 + b) & 0x7FFFFFFF);
    return 100 + (h % 9900);
  }

  int get _level {
    final h = _character.codeUnits.fold(0, (a, b) => (a * 13 + b) & 0x7FFFFFFF);
    return 1 + (h % 80);
  }

  @override
  Widget build(BuildContext context) {
    final cat = roster.Characters.byName(_character).category.name.toUpperCase();
    return Scaffold(
      backgroundColor: const Color(0xFF0D1118),
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Studio background
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF1C2433), Color(0xFF0A0C10), Color(0xFF050608)],
              ),
            ),
          ),
          // Floor fade
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            height: 140,
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.black.withValues(alpha: 0.65),
                  ],
                ),
              ),
            ),
          ),

          SafeArea(
            child: LayoutBuilder(
              builder: (context, cts) {
                final w = cts.maxWidth;
                final h = cts.maxHeight;
                return Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // ========== LEFT TABS (yellow active like FF) ==========
                    SizedBox(
                      width: (w * 0.09).clamp(64.0, 88.0),
                      child: Column(
                        children: [
                          const SizedBox(height: 12),
                          _vTab('GALLERY', 0),
                          _vTab('OVERVIEW', 1),
                          _vTab('HISTORY', 2),
                          const Spacer(),
                          // chat bubble like FF bottom-left
                          Padding(
                            padding: const EdgeInsets.only(bottom: 12),
                            child: Image.asset(
                              'assets/ui/icon_mail.png',
                              width: 22,
                              height: 22,
                              fit: BoxFit.contain,
                              color: Colors.white.withValues(alpha: 0.55),
                              errorBuilder: (_, __, ___) => Icon(
                                Icons.chat_bubble_outline,
                                size: 22,
                                color: Colors.white.withValues(alpha: 0.45),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    // ========== CENTRE CHARACTER (display only, smaller) ==========
                    Expanded(
                      child: Center(
                        child: FractionallySizedBox(
                          widthFactor: 0.48,
                          heightFactor: 0.88,
                          child: CharacterBlend(
                            character: _character,
                            alignment: Alignment.bottomCenter,
                            widthFactor: 1.0,
                            fallbackSeed:
                                _character.codeUnits.fold(0, (a, b) => a + b),
                          ),
                        ),
                      ),
                    ),

                    // ========== RIGHT PANEL ==========
                    SizedBox(
                      width: w * 0.36,
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(6, 8, 12, 8),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            // Title + close
                            Row(
                              children: [
                                const Spacer(),
                                const Text(
                                  'PROFILE',
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w900,
                                    color: Colors.white70,
                                    letterSpacing: 2,
                                  ),
                                ),
                                const Spacer(),
                                GestureDetector(
                                  onTap: () {
                                    Sfx.instance.uiClick();
                                    Navigator.pop(context);
                                  },
                                  child: Image.asset(
                                    'assets/ui/icon_close.png',
                                    width: 28,
                                    height: 28,
                                    fit: BoxFit.contain,
                                    errorBuilder: (_, __, ___) => Container(
                                      width: 28,
                                      height: 28,
                                      decoration: const BoxDecoration(
                                        color: Color(0xFFE0302C),
                                        shape: BoxShape.circle,
                                      ),
                                      child: const Icon(Icons.close,
                                          size: 16, color: Colors.white),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),

                            // --- FF-style profile stats banner ---
                            AspectRatio(
                              aspectRatio: 2.85,
                              child: Stack(
                                fit: StackFit.expand,
                                children: [
                                  Image.asset(
                                    'assets/ui/profile_stats_bg.png',
                                    fit: BoxFit.fill,
                                    errorBuilder: (_, __, ___) => Container(
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF12161C),
                                        borderRadius: BorderRadius.circular(6),
                                        border: Border.all(
                                          color: const Color(0xFFE8A317),
                                          width: 1.5,
                                        ),
                                      ),
                                    ),
                                  ),
                                  // Left badge window (relative)
                                  Align(
                                    alignment: const Alignment(-0.78, -0.05),
                                    child: FractionallySizedBox(
                                      widthFactor: 0.22,
                                      heightFactor: 0.62,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(4),
                                          border: Border.all(
                                            color: const Color(0xFFFFC425),
                                            width: 1.2,
                                          ),
                                        ),
                                        clipBehavior: Clip.antiAlias,
                                        child: CharacterPortrait(
                                          character: _character,
                                          size: 64,
                                          radius: 3,
                                          borderWidth: 0,
                                          alignment: const Alignment(0, -0.3),
                                          fallbackSeed: _character.codeUnits
                                              .fold(0, (a, b) => a + b),
                                        ),
                                      ),
                                    ),
                                  ),
                                  // Name + meta on white plate (right side)
                                  Positioned(
                                    left: 0,
                                    right: 0,
                                    top: 0,
                                    bottom: 0,
                                    child: FractionallySizedBox(
                                      alignment: const Alignment(0.55, 0),
                                      widthFactor: 0.58,
                                      heightFactor: 0.78,
                                      child: Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            8, 6, 8, 4),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Row(
                                              children: [
                                                Expanded(
                                                  child: Text(
                                                    _name.toUpperCase(),
                                                    maxLines: 1,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    style: const TextStyle(
                                                      fontSize: 13,
                                                      fontWeight:
                                                          FontWeight.w900,
                                                      color: Color(0xFF1A1F28),
                                                    ),
                                                  ),
                                                ),
                                                GestureDetector(
                                                  onTap: () {
                                                    Sfx.instance.uiClick();
                                                    widget.onEditName();
                                                  },
                                                  child: Image.asset(
                                                    'assets/ui/icon_setting.png',
                                                    width: 16,
                                                    height: 16,
                                                    errorBuilder: (_, __, ___) =>
                                                        const Icon(
                                                      Icons.settings,
                                                      size: 14,
                                                      color: Color(0xFF5A6570),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Text(
                                              'Lv.$_level · $cat',
                                              style: const TextStyle(
                                                fontSize: 10,
                                                fontWeight: FontWeight.w800,
                                                color: Color(0xFF3D7EFF),
                                              ),
                                            ),
                                            const Spacer(),
                                            Row(
                                              children: [
                                                const Icon(
                                                  Icons.thumb_up_alt,
                                                  size: 12,
                                                  color: Color(0xFF5A6570),
                                                ),
                                                const SizedBox(width: 3),
                                                Text(
                                                  '$_likes',
                                                  style: const TextStyle(
                                                    fontSize: 11,
                                                    fontWeight: FontWeight.w800,
                                                    color: Color(0xFF1A1F28),
                                                  ),
                                                ),
                                                const Spacer(),
                                                Text(
                                                  'UID:$_uid',
                                                  style: const TextStyle(
                                                    fontSize: 9,
                                                    fontWeight: FontWeight.w700,
                                                    color: Color(0xFF6A7380),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 10),

                            // Ranked tabs
                            Row(
                              children: [
                                Expanded(
                                  child: _rankBox(
                                    'RUSH RANKED',
                                    Icons.flash_on_rounded,
                                    '—',
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Expanded(
                                  child: _rankBox(
                                    'CLASSIC',
                                    Icons.emoji_events_rounded,
                                    '—',
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),

                            // Tab body
                            Expanded(
                              child: Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: Colors.black.withValues(alpha: 0.32),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: Colors.white10),
                                ),
                                child: _tab == 0
                                    ? _galleryPane()
                                    : _tab == 1
                                        ? _overviewPane()
                                        : _historyPane(),
                              ),
                            ),
                            const SizedBox(height: 4),
                          ],
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _vTab(String label, int i) {
    final sel = _tab == i;
    return GestureDetector(
      onTap: () {
        Sfx.instance.uiClick();
        setState(() => _tab = i);
      },
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.symmetric(vertical: 3, horizontal: 5),
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: sel ? const Color(0xFFE8A020) : const Color(0xFF1A1F28),
          borderRadius: BorderRadius.circular(3),
          border: sel
              ? null
              : Border.all(color: Colors.white.withValues(alpha: 0.08)),
        ),
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 9.5,
            fontWeight: FontWeight.w900,
            letterSpacing: 0.5,
            color: sel ? Colors.black : Colors.white60,
          ),
        ),
      ),
    );
  }

  Widget _rankBox(String title, IconData icon, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.35),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.white12),
      ),
      child: Column(
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 8.5,
              fontWeight: FontWeight.w800,
              color: Colors.white54,
              letterSpacing: 0.4,
            ),
          ),
          const SizedBox(height: 4),
          Icon(icon, size: 22, color: const Color(0xFFFFC93C)),
          Text(
            value,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w900,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  Widget _miniStat(IconData icon, String v) {
    return Padding(
      padding: const EdgeInsets.only(left: 8),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: Colors.white54),
          const SizedBox(width: 2),
          Text(
            v,
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w800,
              color: Colors.white70,
            ),
          ),
        ],
      ),
    );
  }

  Widget _galleryPane() {
    return Center(
      child: Text(
        _character,
        style: const TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w900,
          color: Colors.white70,
        ),
      ),
    );
  }

  Widget _overviewPane() {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'STATS',
          style: TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w800,
            color: Colors.white54,
            letterSpacing: 0.5,
          ),
        ),
        SizedBox(height: 10),
        _StatLine(label: 'Matches played', value: '0'),
        _StatLine(label: 'Wins', value: '0'),
        _StatLine(label: 'Booyah rate', value: '—'),
        _StatLine(label: 'Favourite mode', value: 'Rush'),
        _StatLine(label: 'Tokens captured', value: '0'),
      ],
    );
  }

  Widget _historyPane() {
    return const Center(
      child: Text(
        'No match history yet.\nPlay a match to fill this tab.',
        textAlign: TextAlign.center,
        style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.4),
      ),
    );
  }
}

class _StatLine extends StatelessWidget {
  const _StatLine({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: const TextStyle(fontSize: 12, color: Colors.white70),
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w800,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}
