import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'login_screen.dart';

/// Free-Fire-style boot screen:
/// full-bleed art background, thin progress bar at bottom,
/// only caption: "RESOURCE LOADING, PLEASE WAIT"
/// + chunk-style progress (same as before).
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _flare = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  )..repeat(reverse: true);

  double _progress = 0;

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _load();
  }

  Future<void> _load() async {
    const segments = <(double target, int climbMs, int holdMs)>[
      (0.10, 300, 900),
      (0.25, 380, 850),
      (0.50, 520, 1500),
      (0.65, 380, 850),
      (0.80, 420, 900),
      (0.92, 380, 750),
      (1.00, 320, 500),
    ];

    await Future<void>.delayed(const Duration(milliseconds: 900));
    if (!mounted) return;

    for (final (target, climbMs, holdMs) in segments) {
      const subSteps = 6;
      final start = _progress;
      final stepMs = (climbMs / subSteps).round().clamp(4, climbMs);
      for (var i = 1; i <= subSteps; i++) {
        await Future<void>.delayed(Duration(milliseconds: stepMs));
        if (!mounted) return;
        final eased = Curves.easeOut.transform(i / subSteps);
        setState(() => _progress = start + (target - start) * eased);
      }
      setState(() => _progress = target);
      await Future<void>.delayed(Duration(milliseconds: holdMs));
      if (!mounted) return;
    }

    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 420),
        pageBuilder: (_, a, __) =>
            FadeTransition(opacity: a, child: const LoginScreen()),
      ),
    );
  }

  @override
  void dispose() {
    _flare.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: LayoutBuilder(
        builder: (context, cts) {
          final w = cts.maxWidth;
          final h = cts.maxHeight;
          final s = min(h, w * 0.56);
          final barH = max(2.5, s * 0.010);
          final barBottom = s * 0.07;
          final capFont = max(7.5, s * 0.026);

          return Stack(
            fit: StackFit.expand,
            children: [
              // Full-bleed art (no black side bars)
              Container(color: Colors.black),
              Image.asset(
                'assets/ui/ff_loading_bg.jpg',
                fit: BoxFit.contain,
                width: w,
                height: h,
                alignment: Alignment.center,
                errorBuilder: (_, __, ___) => const SizedBox.shrink(),
              ),

              // soft dark gradient at bottom so bar/text stay readable
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                height: h * 0.28,
                child: IgnorePointer(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.transparent,
                          Colors.black.withValues(alpha: 0.55),
                          Colors.black.withValues(alpha: 0.82),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

              // caption + progress bar (only text on screen)
              Positioned(
                left: w * 0.08,
                right: w * 0.08,
                bottom: barBottom,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'RESOURCE LOADING, PLEASE WAIT',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: capFont,
                        fontWeight: FontWeight.w800,
                        color: Colors.white.withValues(alpha: 0.92),
                        letterSpacing: 0.8,
                        shadows: const [
                          Shadow(blurRadius: 6, color: Colors.black87),
                        ],
                      ),
                    ),
                    SizedBox(height: s * 0.028),
                    // thin yellow→orange bar
                    SizedBox(
                      height: barH,
                      child: Stack(
                        clipBehavior: Clip.none,
                        children: [
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.white.withValues(alpha: 0.18),
                              borderRadius: BorderRadius.circular(barH),
                            ),
                          ),
                          FractionallySizedBox(
                            widthFactor: _progress.clamp(0.0, 1.0),
                            child: AnimatedBuilder(
                              animation: _flare,
                              builder: (_, __) {
                                return Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(barH),
                                    gradient: LinearGradient(
                                      colors: [
                                        const Color(0xFFFFE082),
                                        Color.lerp(
                                          const Color(0xFFFFB300),
                                          const Color(0xFFFF6D00),
                                          _flare.value,
                                        )!,
                                      ],
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        color: const Color(0xFFFF9800)
                                            .withValues(alpha: 0.55),
                                        blurRadius: 8,
                                        spreadRadius: 0.5,
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
