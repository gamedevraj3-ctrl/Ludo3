import '../board_map.dart';
import '../models.dart';

/// Shared data the mode-specific bot brains need without owning the engine.
class BotContext {
  BotContext({
    required this.player,
    required this.dice,
    required this.options,
    required this.botLevel,
    required this.remainingMatchSeconds,
    required this.killTarget,
    required this.threatAt,
    required this.cutVictims,
    required this.myTokensAt,
    required this.wouldCutAtStart,
    required this.rng,
  });

  final Player player;
  final int dice;
  final List<int> options;
  final int botLevel;
  final double remainingMatchSeconds;
  final int killTarget;

  /// Threat score at [pos] for [player] (higher = more danger).
  final double Function(Player p, int pos) threatAt;

  /// Victims if [player] lands on [np]. Each entry is (victim player, carried).
  final List<({Player player, int value})> Function(Player p, int np) cutVictims;

  final int Function(Player p, int np, {int? exclude}) myTokensAt;
  final bool Function(Player p) wouldCutAtStart;
  final double Function() rng;

  bool get hard => botLevel >= 3;
}

abstract class BotBrain {
  /// Pick token index from [ctx.options].
  int choose(BotContext ctx);
}
