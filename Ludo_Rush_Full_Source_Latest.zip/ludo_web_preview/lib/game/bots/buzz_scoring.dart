import '../board_map.dart';
import '../models.dart';
import 'bot_context.dart';

/// Ludo Buzz–style pawn buckets (from decompiled `AI_Player_V1` fields).
enum BuzzBucket {
  killer, // can cut with this dice
  death, // currently under high threat
  unsafe, // on board, not safe, mild threat
  home, // in home column or can enter
  winner, // exact finish this roll
  open, // closed token, needs 6
  safe, // already safe / lands safe
  advance, // default progress
}

/// Score weights mirrored from decompiled `Ludo_AI_Player` fields:
/// killScore, winScore, homeScore, openScore, safeScore, blockScore,
/// forwardScore, starScore, backwardScore, safeRiskScore.
class BuzzScores {
  const BuzzScores({
    this.kill = 1000,
    this.win = 1400,
    this.home = 320,
    this.open = 180,
    this.safe = 160,
    this.block = 240,
    this.forward = 1.1,
    this.star = 90,
    this.escape = 220,
    this.safeRisk = 80,
  });

  final double kill;
  final double win;
  final double home;
  final double open;
  final double safe;
  final double block;
  final double forward;
  final double star;
  final double escape;
  final double safeRisk;

  /// Aggressive offline Buzz (kill-heavy).
  static const aggressive = BuzzScores(
    kill: 1100,
    win: 1350,
    home: 300,
    open: 160,
    safe: 140,
    block: 220,
    forward: 1.0,
    star: 80,
    escape: 250,
    safeRisk: 90,
  );

  /// Rush: score/home pressure a bit higher, still loves kills.
  static const rush = BuzzScores(
    kill: 900,
    win: 1100,
    home: 340,
    open: 150,
    safe: 170,
    block: 200,
    forward: 1.4,
    star: 100,
    escape: 200,
    safeRisk: 100,
  );

  /// Death match: only kills matter for the goal, but defence still helps.
  static const deathMatch = BuzzScores(
    kill: 1600,
    win: 200,
    home: 40,
    open: 120,
    safe: 180,
    block: 260,
    forward: 0.4,
    star: 60,
    escape: 280,
    safeRisk: 110,
  );
}

/// Shared Buzz-style chooser used by all mode bots.
class BuzzChooser {
  const BuzzChooser(this.weights);

  final BuzzScores weights;

  int choose(BotContext ctx) {
    if (ctx.options.length == 1) return ctx.options.first;
    // Easy bots: mostly random with light bias to kill if available.
    if (ctx.botLevel == 1) {
      for (final idx in ctx.options) {
        final t = ctx.player.tokens[idx];
        if (t.open) {
          final victims = ctx.cutVictims(ctx.player, t.pos + ctx.dice);
          if (victims.isNotEmpty) return idx;
        }
      }
      return ctx.options[(ctx.rng() * ctx.options.length).floor() %
          ctx.options.length];
    }

    var bestScore = -1e12;
    var best = ctx.options.first;

    for (final idx in ctx.options) {
      final s = scoreToken(ctx, idx);
      if (s > bestScore) {
        bestScore = s;
        best = idx;
      }
    }
    return best;
  }

  double scoreToken(BotContext ctx, int idx) {
    final p = ctx.player;
    final d = ctx.dice;
    final t = p.tokens[idx];
    var s = 0.0;

    // --- closed / yard ---
    if (!t.open) {
      s += weights.open;
      s += (4 - p.tokens.where((x) => x.onBoard).length) * 40;
      if (ctx.wouldCutAtStart(p)) s += weights.kill * 0.35;
      if (p.tokens.where((x) => x.onBoard).isEmpty) s += 60;
      s += ctx.rng() * (ctx.hard ? 10 : 30);
      return s;
    }

    final np = t.pos + d;
    final victims = ctx.cutVictims(p, np);
    final formsBlock =
        np <= BoardMap.lastRingStep && ctx.myTokensAt(p, np, exclude: idx) >= 1;
    final landsSafe = np > BoardMap.lastRingStep ||
        BoardMap.isSafePos(p.color, np) ||
        formsBlock;
    final threatLanding = landsSafe ? 0.0 : ctx.threatAt(p, np);
    final threatNow = t.onBoard ? ctx.threatAt(p, t.pos) : 0.0;

    // Priority buckets (AI_Player_V1 style)
    if (victims.isNotEmpty) {
      s += weights.kill;
      for (final v in victims) {
        s += v.value * 5.0;
        if (v.value > 40) s += 100;
      }
    }

    if (np == BoardMap.homeStep) {
      s += weights.win;
    } else if (np > BoardMap.lastRingStep) {
      s += weights.home + (np - BoardMap.lastRingStep) * 18;
    }

    // Escape death / unsafe
    if (threatNow > 0.2) {
      final after = landsSafe ? 0.0 : threatLanding;
      if (after < threatNow) {
        s += weights.escape * (threatNow - after + 0.2);
      }
    }

    if (formsBlock) s += weights.block;
    if (landsSafe) {
      s += weights.safe;
      // star / safe ring cells
      if (np <= BoardMap.lastRingStep && BoardMap.isSafePos(p.color, np)) {
        s += weights.star;
      }
    } else {
      s -= threatLanding * (weights.safeRisk + t.pos * 1.5);
    }

    // Forward progress
    s += t.pos * weights.forward;
    if (t.pos > 44) s += 35;

    // Mild penalty stacking too deep
    if (ctx.myTokensAt(p, np, exclude: idx) >= 3) s -= 40;

    // Prefer opening others when already far ahead with many yard tokens
    if (p.tokensYarded > 0 && d == 6 && t.pos < 8) s -= 15;

    s += ctx.rng() * (ctx.hard ? 12 : 40);
    return s;
  }

  /// Classify for debug / future UI feel-text (Buzz FeelText).
  BuzzBucket bucket(BotContext ctx, int idx) {
    final p = ctx.player;
    final t = p.tokens[idx];
    if (!t.open) return BuzzBucket.open;
    final np = t.pos + ctx.dice;
    if (ctx.cutVictims(p, np).isNotEmpty) return BuzzBucket.killer;
    if (np == BoardMap.homeStep) return BuzzBucket.winner;
    if (np > BoardMap.lastRingStep) return BuzzBucket.home;
    final threat = t.onBoard ? ctx.threatAt(p, t.pos) : 0.0;
    if (threat > 0.35) return BuzzBucket.death;
    if (threat > 0.12) return BuzzBucket.unsafe;
    final landsSafe = np > BoardMap.lastRingStep ||
        BoardMap.isSafePos(p.color, np) ||
        (np <= BoardMap.lastRingStep &&
            ctx.myTokensAt(p, np, exclude: idx) >= 1);
    if (landsSafe) return BuzzBucket.safe;
    return BuzzBucket.advance;
  }
}
