import 'bot_context.dart';
import 'buzz_scoring.dart';

/// Classic mode bot — Ludo Buzz AI_Player_V1 style priorities.
class ClassicBot implements BotBrain {
  const ClassicBot();

  static const _brain = BuzzChooser(BuzzScores.aggressive);

  @override
  int choose(BotContext ctx) => _brain.choose(ctx);
}
