import 'bot_context.dart';
import 'buzz_scoring.dart';

/// Death Match bot — maximize kills; defence secondary (Buzz death-match weights).
class DeathMatchBot implements BotBrain {
  const DeathMatchBot();

  static const _brain = BuzzChooser(BuzzScores.deathMatch);

  @override
  int choose(BotContext ctx) {
    // Prefer any legal cut first even on mid+ levels.
    if (ctx.botLevel >= 2) {
      for (final idx in ctx.options) {
        final t = ctx.player.tokens[idx];
        if (!t.open) continue;
        final victims = ctx.cutVictims(ctx.player, t.pos + ctx.dice);
        if (victims.isNotEmpty) return idx;
      }
    }
    return _brain.choose(ctx);
  }
}
