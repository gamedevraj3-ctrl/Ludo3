import 'bot_context.dart';
import 'buzz_scoring.dart';

/// Kill mode bot — capture + home race (Buzz killer/home buckets dominate).
class KillBot implements BotBrain {
  const KillBot();

  static const _brain = BuzzChooser(
    BuzzScores(
      kill: 1250,
      win: 1200,
      home: 360,
      open: 170,
      safe: 150,
      block: 230,
      forward: 1.05,
      star: 85,
      escape: 240,
      safeRisk: 95,
    ),
  );

  @override
  int choose(BotContext ctx) => _brain.choose(ctx);
}
