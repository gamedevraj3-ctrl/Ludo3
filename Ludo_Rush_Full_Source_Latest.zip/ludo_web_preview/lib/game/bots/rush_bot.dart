import 'bot_context.dart';
import 'buzz_scoring.dart';

/// Rush mode bot — kill + score/home pressure (Buzz weights tuned for race).
class RushBot implements BotBrain {
  const RushBot();

  static const _brain = BuzzChooser(BuzzScores.rush);

  @override
  int choose(BotContext ctx) => _brain.choose(ctx);
}
