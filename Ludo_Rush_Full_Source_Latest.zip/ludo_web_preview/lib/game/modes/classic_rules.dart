/// Classic mode rules (reference for engine + bots).
///
/// - Tokens start in yard; need a 6 to open.
/// - Exact count to enter HOME column / finish.
/// - Safe stars and blocks protect from cuts.
/// - Win: all 4 tokens HOME (or mode timer if timed).
class ClassicRules {
  const ClassicRules();

  static const bool requiresSixToOpen = true;
  static const bool homeAlwaysOpen = true;
  static const bool scoreBySteps = false;
}
