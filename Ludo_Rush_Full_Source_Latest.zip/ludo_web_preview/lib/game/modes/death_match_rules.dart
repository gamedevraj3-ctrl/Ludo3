/// Death Match rules.
///
/// - Tokens loop the outer ring only (no HOME entry).
/// - Win by reaching [killTarget] cuts (default 5).
/// - Score/podium uses kill count.
class DeathMatchRules {
  const DeathMatchRules();

  static const bool requiresSixToOpen = false;
  static const bool allowHome = false;
  static const int defaultKillTarget = 5;
}
