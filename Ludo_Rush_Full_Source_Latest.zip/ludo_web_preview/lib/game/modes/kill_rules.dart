/// Kill mode rules.
///
/// - Tokens open without 6 (rush-style entry).
/// - HOME path locked until the player scores at least 1 cut.
/// - After unlock: race tokens home.
/// - Win: usual home finish after unlock.
class KillRules {
  const KillRules();

  static const bool requiresSixToOpen = false;
  static const bool homeLockedUntilFirstKill = true;
}
