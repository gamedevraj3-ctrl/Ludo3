/// Rush mode rules.
///
/// - All tokens start open on the board path.
/// - +1 score per step; big bonus on HOME.
/// - Cuts steal carried points.
/// - Win: highest score when match timer ends (or all home variants).
class RushRules {
  const RushRules();

  static const bool requiresSixToOpen = false;
  static const bool homeAlwaysOpen = true;
  static const bool scoreBySteps = true;
}
