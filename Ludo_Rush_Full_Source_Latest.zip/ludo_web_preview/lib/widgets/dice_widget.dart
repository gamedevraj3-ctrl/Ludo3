import 'dart:math';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/theme.dart';

/// Dual dice assets:
/// - 3D tumble sheet while rolling (`dice_spritesheet.png`, 9×3 = 27 frames)
/// - Clean glossy faces when settled (`dice_faces.png`, 3×2 = 1..6)
class DiceSprite {
  DiceSprite._();

  static const rollAsset = 'assets/ui/dice/dice_spritesheet.png';
  static const faceAsset = 'assets/ui/dice/dice_faces.png';
  static const rollCols = 9;
  static const rollRows = 3;
  static const rollFrameCount = 27;
  static const faceCols = 3;
  static const faceRows = 2;
  static const rollDuration = Duration(milliseconds: 700);

  static int faceFrame(int value) => (value.clamp(1, 6) - 1);

  static ui.Image? _rollImage;
  static ui.Image? _faceImage;
  static Future<void>? _loading;

  static Future<void> load() {
    _loading ??= _decodeAll();
    return _loading!;
  }

  static Future<void> _decodeAll() async {
    Future<ui.Image> one(String path) async {
      final data = await rootBundle.load(path);
      final codec = await ui.instantiateImageCodec(data.buffer.asUint8List());
      final frame = await codec.getNextFrame();
      return frame.image;
    }

    _rollImage = await one(rollAsset);
    _faceImage = await one(faceAsset);
  }

  static ui.Image? get rollImage => _rollImage;
  static ui.Image? get faceImage => _faceImage;
}

/// Paints one cell from a sprite grid.
class DiceSpritePainter extends CustomPainter {
  DiceSpritePainter({
    required this.image,
    required this.frame,
    required this.cols,
    required this.rows,
    required this.frameCount,
  });

  final ui.Image image;
  final int frame;
  final int cols;
  final int rows;
  final int frameCount;

  @override
  void paint(Canvas canvas, Size size) {
    final fw = image.width / cols;
    final fh = image.height / rows;
    final idx = frame.clamp(0, frameCount - 1);
    final c = idx % cols;
    final r = idx ~/ cols;
    final src = Rect.fromLTWH(c * fw, r * fh, fw, fh);
    final dst = Offset.zero & size;
    canvas.drawImageRect(
      image,
      src,
      dst,
      Paint()..filterQuality = FilterQuality.high,
    );
  }

  @override
  bool shouldRepaint(covariant DiceSpritePainter old) =>
      old.image != image ||
      old.frame != frame ||
      old.cols != cols ||
      old.rows != rows;
}

/// White 3D dice face drawn with CustomPaint (fallback / small UI).
class DiceFace extends StatelessWidget {
  const DiceFace({
    super.key,
    required this.value,
    this.size = 34,
    this.dotColor = AppColors.accentDeep,
    this.faceColor = Colors.white,
  });

  final int value;
  final double size;
  final Color dotColor;
  final Color faceColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size * 0.22),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [faceColor, Color.lerp(faceColor, Colors.grey, 0.22)!],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.35),
            blurRadius: size * 0.15,
            offset: Offset(0, size * 0.07),
          ),
        ],
      ),
      child: CustomPaint(painter: _DotsPainter(value, dotColor)),
    );
  }
}

class _DotsPainter extends CustomPainter {
  _DotsPainter(this.value, this.color);
  final int value;
  final Color color;

  static const Map<int, List<List<double>>> layout = {
    1: [
      [0.5, 0.5],
    ],
    2: [
      [0.28, 0.28],
      [0.72, 0.72],
    ],
    3: [
      [0.26, 0.26],
      [0.5, 0.5],
      [0.74, 0.74],
    ],
    4: [
      [0.28, 0.28],
      [0.72, 0.28],
      [0.28, 0.72],
      [0.72, 0.72],
    ],
    5: [
      [0.26, 0.26],
      [0.74, 0.26],
      [0.5, 0.5],
      [0.26, 0.74],
      [0.74, 0.74],
    ],
    6: [
      [0.28, 0.24],
      [0.72, 0.24],
      [0.28, 0.5],
      [0.72, 0.5],
      [0.28, 0.76],
      [0.72, 0.76],
    ],
  };

  @override
  void paint(Canvas canvas, Size size) {
    final r = size.width * 0.088;
    final p = Paint()..color = color;
    final dots = layout[value.clamp(1, 6)]!;
    for (final d in dots) {
      canvas.drawCircle(Offset(d[0] * size.width, d[1] * size.height), r, p);
    }
  }

  @override
  bool shouldRepaint(covariant _DotsPainter old) =>
      old.value != value || old.color != color;
}

/// Sprite-sheet dice used while rolling / settled (Ludo Buzz style).
class SpriteDiceView extends StatefulWidget {
  const SpriteDiceView({
    super.key,
    required this.value,
    required this.rolling,
    this.size = 64,
  });

  final int? value;
  final bool rolling;
  final double size;

  @override
  State<SpriteDiceView> createState() => _SpriteDiceViewState();
}

class _SpriteDiceViewState extends State<SpriteDiceView>
    with SingleTickerProviderStateMixin {
  bool _ready = false;
  late final AnimationController _roll = AnimationController(
    vsync: this,
    duration: DiceSprite.rollDuration,
  );

  @override
  void initState() {
    super.initState();
    DiceSprite.load().then((_) {
      if (mounted) setState(() => _ready = true);
    });
    if (widget.rolling) _roll.repeat();
  }

  @override
  void didUpdateWidget(SpriteDiceView old) {
    super.didUpdateWidget(old);
    if (widget.rolling && !_roll.isAnimating) {
      _roll
        ..reset()
        ..repeat();
    } else if (!widget.rolling && _roll.isAnimating) {
      _roll.stop();
    }
  }

  @override
  void dispose() {
    _roll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_ready) {
      return DiceFace(value: widget.value ?? 6, size: widget.size * 0.85);
    }
    return AnimatedBuilder(
      animation: _roll,
      builder: (_, __) {
        if (widget.rolling) {
          final img = DiceSprite.rollImage!;
          final frame =
              (_roll.value * (DiceSprite.rollFrameCount - 1)).round().clamp(
                    0,
                    DiceSprite.rollFrameCount - 1,
                  );
          return CustomPaint(
            size: Size(widget.size, widget.size),
            painter: DiceSpritePainter(
              image: img,
              frame: frame,
              cols: DiceSprite.rollCols,
              rows: DiceSprite.rollRows,
              frameCount: DiceSprite.rollFrameCount,
            ),
          );
        }
        final img = DiceSprite.faceImage!;
        return CustomPaint(
          size: Size(widget.size, widget.size),
          painter: DiceSpritePainter(
            image: img,
            frame: DiceSprite.faceFrame(widget.value ?? 6),
            cols: DiceSprite.faceCols,
            rows: DiceSprite.faceRows,
            frameCount: 6,
          ),
        );
      },
    );
  }
}

/// Big tappable roll control — player avatar + sprite dice (Ludo Buzz layout).
class RollDiceButton extends StatefulWidget {
  const RollDiceButton({
    super.key,
    required this.value,
    required this.enabled,
    required this.rolling,
    required this.onTap,
    this.turnProgress = 1.0,
    this.ringColor,
    this.ringStartAngle = -3.141592653589793 / 2,
    this.playerAvatar,
    this.playerLabel,
  });

  final int? value;
  final bool enabled;
  final bool rolling;
  final VoidCallback onTap;
  final double turnProgress;
  final Color? ringColor;
  final double ringStartAngle;

  /// Optional circular avatar shown left of the dice (Ludo Buzz style).
  final Widget? playerAvatar;
  final String? playerLabel;

  @override
  State<RollDiceButton> createState() => _RollDiceButtonState();
}

class _RollDiceButtonState extends State<RollDiceButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1700),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ring = widget.ringColor ?? AppColors.glow;

    final diceCore = GestureDetector(
      onTap: widget.enabled ? widget.onTap : null,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          final pulse = widget.enabled ? _c.value : 0.0;
          return SizedBox(
            width: 96,
            height: 96,
            child: Stack(
              alignment: Alignment.center,
              children: [
                CustomPaint(
                  size: const Size(96, 96),
                  painter: _TurnRingPainter(
                    progress: widget.turnProgress.clamp(0.0, 1.0),
                    color: ring,
                    startAngle: widget.ringStartAngle,
                  ),
                ),
                Container(
                  width: 78,
                  height: 78,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    color: Colors.white.withValues(alpha: 0.08),
                    border: Border.all(
                      color: widget.enabled
                          ? ring.withValues(alpha: 0.55 + 0.4 * pulse)
                          : Colors.white24,
                      width: 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: ring.withValues(
                          alpha: widget.enabled ? 0.25 + 0.2 * pulse : 0.05,
                        ),
                        blurRadius: 16 + 10 * pulse,
                      ),
                    ],
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: SpriteDiceView(
                    value: widget.value,
                    rolling: widget.rolling,
                    size: 72,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );

    // Ludo Buzz: [avatar] [dice] in a row under the board
    if (widget.playerAvatar != null) {
      return Row(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: ring, width: 2.2),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.35),
                      blurRadius: 8,
                    ),
                  ],
                ),
                clipBehavior: Clip.antiAlias,
                child: widget.playerAvatar,
              ),
              if (widget.playerLabel != null) ...[
                const SizedBox(height: 4),
                Text(
                  widget.playerLabel!,
                  style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    color: Colors.white70,
                  ),
                ),
              ],
            ],
          ),
          const SizedBox(width: 12),
          diceCore,
        ],
      );
    }

    return diceCore;
  }
}

class _TurnRingPainter extends CustomPainter {
  _TurnRingPainter({
    required this.progress,
    required this.color,
    required this.startAngle,
  });

  final double progress;
  final Color color;
  final double startAngle;

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = size.width / 2 - 3;
    final bg = Paint()
      ..color = Colors.white.withValues(alpha: 0.12)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.round;
    final fg = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4.5
      ..strokeCap = StrokeCap.round;
    canvas.drawCircle(c, r, bg);
    if (progress > 0.001) {
      canvas.drawArc(
        Rect.fromCircle(center: c, radius: r),
        startAngle,
        2 * pi * progress,
        false,
        fg,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _TurnRingPainter old) =>
      old.progress != progress ||
      old.color != color ||
      old.startAngle != startAngle;
}
class CornerDicePlate extends StatelessWidget {
  const CornerDicePlate({
    super.key,
    required this.value,
    required this.width,
    required this.seatColor,
    required this.seatDark,
    this.pinOnLeft = true,
    this.live = false,
    this.pulse = 0.0,
    this.turnProgress,
    this.rolling = false,
  });

  /// Number to display. `null` = this seat has not rolled yet, so a blank face
  /// is drawn rather than pretending a 6 was thrown.
  final int? value;

  /// Total width of the conjoined plate. Height is derived from it.
  final double width;

  /// That player's colour — drives the pin segment and the glow.
  final Color seatColor;
  final Color seatDark;

  final bool pinOnLeft;

  /// True while this seat may actually tap to roll.
  final bool live;

  /// 0→1 breathing value driving the glow while [live].
  final double pulse;

  /// 1.0 → full turn time left, 0.0 → out of time. Null hides the ring.
  final double? turnProgress;

  /// Sprite-sheet tumble while this seat's roll is animating.
  final bool rolling;

  // Reference proportions: pin segment ~40%, dice tray ~60%.
  static const double _pinFrac = 0.40;

  @override
  Widget build(BuildContext context) {
    final h = width * 0.62;
    final radius = h * 0.26;
    const gold = Color(0xFFE3C77A);

    final pin = _PinSegment(
      height: h,
      seatColor: seatColor,
      seatDark: seatDark,
      live: live,
      turnProgress: turnProgress,
    );

    final tray = _DiceSegment(
      height: h,
      value: value,
      live: live,
      pulse: pulse,
      rolling: rolling,
    );

    return Container(
      width: width,
      height: h,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(
          color: live
              ? Color.lerp(gold, Colors.white, 0.30 + 0.35 * pulse)!
              : gold.withValues(alpha: 0.62),
          width: h * 0.075,
        ),
        boxShadow: [
          BoxShadow(
            color: live
                ? seatColor.withValues(alpha: 0.50 + 0.35 * pulse)
                : Colors.black.withValues(alpha: 0.42),
            blurRadius: live ? h * 0.42 + h * 0.22 * pulse : h * 0.18,
            spreadRadius: live ? h * 0.03 : 0,
            offset: Offset(0, h * 0.05),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(radius * 0.86),
        child: Row(
          children: pinOnLeft
              ? [
                  SizedBox(width: width * _pinFrac, child: pin),
                  Expanded(child: tray),
                ]
              : [
                  Expanded(child: tray),
                  SizedBox(width: width * _pinFrac, child: pin),
                ],
        ),
      ),
    );
  }
}

/// The narrow coloured segment holding the map-pin badge. Doubles as the
/// turn-timer: a thin arc sweeps around the pin while that seat is deciding.
class _PinSegment extends StatelessWidget {
  const _PinSegment({
    required this.height,
    required this.seatColor,
    required this.seatDark,
    required this.live,
    required this.turnProgress,
  });

  final double height;
  final Color seatColor;
  final Color seatDark;
  final bool live;
  final double? turnProgress;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        // dark at the bottom, brighter at the top, as in the reference
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: live
              ? [Color.lerp(seatColor, Colors.white, 0.28)!, seatDark]
              : [
                  Color.lerp(
                    seatColor,
                    Colors.white,
                    0.10,
                  )!.withValues(alpha: 0.80),
                  seatDark.withValues(alpha: 0.80),
                ],
        ),
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          if (turnProgress != null)
            Padding(
              padding: EdgeInsets.all(height * 0.10),
              child: AspectRatio(
                aspectRatio: 1,
                child: CircularProgressIndicator(
                  value: turnProgress!.clamp(0.0, 1.0),
                  strokeWidth: height * 0.075,
                  backgroundColor: Colors.black.withValues(alpha: 0.22),
                  valueColor: AlwaysStoppedAnimation(
                    turnProgress! <= 0.3
                        ? const Color(0xFFFFE04A)
                        : Colors.white,
                  ),
                ),
              ),
            ),
          CustomPaint(
            size: Size(height * 0.44, height * 0.54),
            painter: _MapPinPainter(coreColor: seatColor),
          ),
        ],
      ),
    );
  }
}

/// White teardrop map pin with a coloured core, drawn to match the reference.
class _MapPinPainter extends CustomPainter {
  _MapPinPainter({required this.coreColor});
  final Color coreColor;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final headR = w * 0.5;
    final headC = Offset(w * 0.5, headR);

    // teardrop = circular head + tapered tail down to the tip
    final path = Path()
      ..addOval(Rect.fromCircle(center: headC, radius: headR))
      ..moveTo(w * 0.16, h * 0.60)
      ..quadraticBezierTo(w * 0.42, h * 0.86, w * 0.5, h)
      ..quadraticBezierTo(w * 0.58, h * 0.86, w * 0.84, h * 0.60)
      ..close();

    canvas.drawPath(
      path,
      Paint()
        ..color = Colors.black.withValues(alpha: 0.28)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, w * 0.10),
    );
    canvas.drawPath(path, Paint()..color = Colors.white);

    // coloured core
    canvas.drawCircle(headC, headR * 0.44, Paint()..color = coreColor);
  }

  @override
  bool shouldRepaint(covariant _MapPinPainter old) =>
      old.coreColor != coreColor;
}

/// The cream tray holding the white die with black pips.
class _DiceSegment extends StatelessWidget {
  const _DiceSegment({
    required this.height,
    required this.value,
    required this.live,
    required this.pulse,
    this.rolling = false,
  });

  final double height;
  final int? value;
  final bool live;
  final double pulse;
  final bool rolling;

  @override
  Widget build(BuildContext context) {
    final die = height * 0.62;
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: live
              ? const [Color(0xFFFFFDF5), Color(0xFFF0E7D2)]
              : [
                  const Color(0xFFFFFDF5).withValues(alpha: 0.70),
                  const Color(0xFFF0E7D2).withValues(alpha: 0.70),
                ],
        ),
      ),
      alignment: Alignment.center,
      child: (value == null && !rolling)
          ? Container(
              width: die,
              height: die,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(die * 0.20),
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFFFFFFFF), Color(0xFFDCD8CF)],
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.20),
                    blurRadius: die * 0.14,
                    offset: Offset(0, die * 0.06),
                  ),
                ],
              ),
            )
          : SizedBox(
              width: die,
              height: die,
              child: SpriteDiceView(
                value: value ?? 6,
                rolling: rolling,
                size: die,
              ),
            ),
    );
  }
}
