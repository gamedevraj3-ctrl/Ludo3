import 'package:flutter/material.dart';

/// Image.asset that never throws on missing files — shows a dark placeholder.
class SafeImage extends StatelessWidget {
  const SafeImage(
    this.path, {
    super.key,
    this.width,
    this.height,
    this.fit = BoxFit.contain,
    this.alignment = Alignment.center,
    this.color,
    this.colorBlendMode,
  });

  final String path;
  final double? width;
  final double? height;
  final BoxFit fit;
  final Alignment alignment;
  final Color? color;
  final BlendMode? colorBlendMode;

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      path,
      width: width,
      height: height,
      fit: fit,
      alignment: alignment,
      color: color,
      colorBlendMode: colorBlendMode,
      errorBuilder: (_, __, ___) => Container(
        width: width,
        height: height,
        color: const Color(0xFF1A1D22),
        alignment: Alignment.center,
        child: const Icon(Icons.image_not_supported, color: Colors.white24, size: 18),
      ),
    );
  }
}
