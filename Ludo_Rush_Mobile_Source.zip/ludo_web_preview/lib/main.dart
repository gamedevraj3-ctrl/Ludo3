import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'core/audio.dart';
import 'core/theme.dart';
import 'screens/garena_splash_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  // Never let a missing asset / layout error kill the whole process.
  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.presentError(details);
    debugPrint('FlutterError: ${details.exceptionAsString()}');
  };
  PlatformDispatcher.instance.onError = (error, stack) {
    debugPrint('Uncaught: $error\n$stack');
    return true; // handled — do not crash process
  };
  ErrorWidget.builder = (FlutterErrorDetails details) {
    return Material(
      color: const Color(0xFF0B0E14),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Text(
            'UI error\n${details.exceptionAsString()}',
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white70, fontSize: 12),
          ),
        ),
      ),
    );
  };

  // Warm up the offline sound engine (never blocks startup on failure).
  try {
    Sfx.instance.init();
  } catch (e) {
    debugPrint('Sfx init failed: $e');
  }

  // App is landscape-only (lobby, characters, store, match).
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: AppColors.bgBottom,
    ),
  );
  runApp(const LudoRushApp());
}

class LudoRushApp extends StatelessWidget {
  const LudoRushApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ludo Rush',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      home: const GarenaSplashScreen(),
    );
  }
}
