import 'dart:math';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/theme.dart';

/// Optional sprite sheets (used when present; painted dice is always fallback).
class DiceSprite {
  DiceSprite._();

  static const rollAsset = 'assets/ui/dice/dice_spritesheet.png';
  static const faceAsset = 'assets/ui/dice/dice_faces.png';
  static const rollCols = 9;
  static const rollRows = 3;
  static const rollFrameCount = 27;
  static const faceCols = 3;
  static const faceRows = 2;
  static const rollDuration = Duration(milliseconds: 780);

  static int faceFrame(int value) => (value.clamp(1, 6) - 1);

  static ui.Image? _rollImage;
  static ui.Image? _faceImage;
  static Future<void>? _loading;
  static bool get hasSprites => _rollImage != null && _faceImage != null;

  static Future<void> load() {
    _loading ??= _decodeAll();
    return _loading!;
  }

  static Future<void> _decodeAll() async {
    try {
      Future<ui.Image> one(String path) async {
        final data = await rootBundle.load(path);
        final codec =
            await ui.instantiateImageCodec(data.buffer.asUint8List());
        final frame = await codec.getNextFrame();
        return frame.image;
      }

      _rollImage = await one(rollAsset);
      _faceImage = await one(faceAsset);
    } catch (_) {
      // Placeholders / missing assets — painted dice will be used.
    }
  }

  static ui.Image? get rollImage => _rollImage;
  static ui.Image? get faceImage => _faceImage;
}

class DiceSpritePainter extends CustomPainter {
  DiceSpritePainter({
    required this.image,
    required this.frame,
    required this.cols,
    required this.rows,
    required this.frameCount,
  });

  final ui.Image image;
  final int frame;
  final int cols;
  final int rows;
  final int frameCount;

  @override
  void paint(Canvas canvas, Size size) {
    final fw = image.width / cols;
    final fh = image.height / rows;
    final idx = frame.clamp(0, frameCount - 1);
    final c = idx % cols;
    final r = idx ~/ cols;
    final src = Rect.fromLTWH(c * fw, r * fh, fw, fh);
    canvas.drawImageRect(
      image,
      src,
      Offset.zero & size,
      Paint()..filterQuality = FilterQuality.high,
    );
  }

  @override
  bool shouldRepaint(covariant DiceSpritePainter old) =>
      old.image != image || old.frame != frame;
}

// =============================================================================
// Painted Ludo-Buzz dice (white face, black pips) — matches reference closely.
// =============================================================================

class DiceFace extends StatelessWidget {
  const DiceFace({
    super.key,
    required this.value,
    this.size = 34,
    this.dotColor = const Color(0xFF1A1A1A),
    this.faceColor = Colors.white,
    this.glow = false,
    this.sixBurst = false,
  });

  final int value;
  final double size;
  final Color dotColor;
  final Color faceColor;
  final bool glow;
  final bool sixBurst;

  @override
  Widget build(BuildContext context) {
    final r = size * 0.18;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(r),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white,
            Color.lerp(Colors.white, const Color(0xFFE8EEF8), 0.55)!,
          ],
        ),
        border: Border.all(
          color: sixBurst
              ? const Color(0xFF5ECBFF)
              : Colors.white.withValues(alpha: 0.9),
          width: sixBurst ? 2.2 : 1.2,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.35),
            blurRadius: size * 0.12,
            offset: Offset(0, size * 0.06),
          ),
          if (glow || sixBurst)
            BoxShadow(
              color: const Color(0xFF3DB7FF)
                  .withValues(alpha: sixBurst ? 0.85 : 0.45),
              blurRadius: size * (sixBurst ? 0.55 : 0.35),
              spreadRadius: sixBurst ? size * 0.06 : 0,
            ),
          if (sixBurst)
            BoxShadow(
              color: const Color(0xFF9AE6FF).withValues(alpha: 0.55),
              blurRadius: size * 0.9,
              spreadRadius: size * 0.08,
            ),
        ],
      ),
      child: CustomPaint(
        painter: _DotsPainter(value.clamp(1, 6), dotColor),
      ),
    );
  }
}

class _DotsPainter extends CustomPainter {
  _DotsPainter(this.value, this.color);
  final int value;
  final Color color;

  static const Map<int, List<List<double>>> layout = {
    1: [
      [0.5, 0.5]
    ],
    2: [
      [0.28, 0.28],
      [0.72, 0.72]
    ],
    3: [
      [0.26, 0.26],
      [0.5, 0.5],
      [0.74, 0.74]
    ],
    4: [
      [0.28, 0.28],
      [0.72, 0.28],
      [0.28, 0.72],
      [0.72, 0.72]
    ],
    5: [
      [0.26, 0.26],
      [0.74, 0.26],
      [0.5, 0.5],
      [0.26, 0.74],
      [0.74, 0.74]
    ],
    6: [
      [0.28, 0.24],
      [0.72, 0.24],
      [0.28, 0.5],
      [0.72, 0.5],
      [0.28, 0.76],
      [0.72, 0.76]
    ],
  };

  @override
  void paint(Canvas canvas, Size size) {
    final r = size.width * 0.095;
    final p = Paint()..color = color;
    for (final d in layout[value]!) {
      canvas.drawCircle(Offset(d[0] * size.width, d[1] * size.height), r, p);
    }
  }

  @override
  bool shouldRepaint(covariant _DotsPainter old) =>
      old.value != value || old.color != color;
}

// =============================================================================
// Rolling dice view — 3D tumble + settle + six burst
// =============================================================================

class SpriteDiceView extends StatefulWidget {
  const SpriteDiceView({
    super.key,
    required this.value,
    required this.rolling,
    this.size = 64,
  });

  final int? value;
  final bool rolling;
  final double size;

  @override
  State<SpriteDiceView> createState() => _SpriteDiceViewState();
}

class _SpriteDiceViewState extends State<SpriteDiceView>
    with TickerProviderStateMixin {
  bool _ready = false;
  late final AnimationController _roll = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 780),
  );
  late final AnimationController _six = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  );
  final _rng = Random();

  @override
  void initState() {
    super.initState();
    DiceSprite.load().then((_) {
      if (mounted) setState(() => _ready = true);
    });
    if (widget.rolling) _roll.repeat();
    if (widget.value == 6 && !widget.rolling) {
      _six.forward(from: 0);
    }
  }

  @override
  void didUpdateWidget(SpriteDiceView old) {
    super.didUpdateWidget(old);
    if (widget.rolling && !_roll.isAnimating) {
      _roll
        ..duration = const Duration(milliseconds: 780)
        ..repeat();
    } else if (!widget.rolling && _roll.isAnimating) {
      _roll.stop();
      if (widget.value == 6) _six.forward(from: 0);
    }
    if (!widget.rolling &&
        widget.value == 6 &&
        old.value != 6 &&
        !_six.isAnimating) {
      _six.forward(from: 0);
    }
  }

  @override
  void dispose() {
    _roll.dispose();
    _six.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isSix = !widget.rolling && widget.value == 6;

    return AnimatedBuilder(
      animation: Listenable.merge([_roll, _six]),
      builder: (_, __) {
        Widget face;
        if (widget.rolling) {
          // 3D tumble: spin + bounce + cycling faces (sprite or paint)
          final t = _roll.value;
          final spin = t * pi * 6;
          final bounce = 1.0 + 0.12 * sin(t * pi * 8);
          final showVal = 1 + ((t * 18).floor() % 6);
          if (_ready && DiceSprite.hasSprites) {
            final img = DiceSprite.rollImage!;
            final frame =
                (t * (DiceSprite.rollFrameCount - 1)).round().clamp(
                      0,
                      DiceSprite.rollFrameCount - 1,
                    );
            face = Transform(
              alignment: Alignment.center,
              transform: Matrix4.identity()
                ..setEntry(3, 2, 0.002)
                ..rotateY(spin * 0.35)
                ..rotateX(spin * 0.22)
                ..scale(bounce),
              child: CustomPaint(
                size: Size(widget.size, widget.size),
                painter: DiceSpritePainter(
                  image: img,
                  frame: frame,
                  cols: DiceSprite.rollCols,
                  rows: DiceSprite.rollRows,
                  frameCount: DiceSprite.rollFrameCount,
                ),
              ),
            );
          } else {
            face = Transform(
              alignment: Alignment.center,
              transform: Matrix4.identity()
                ..setEntry(3, 2, 0.002)
                ..rotateY(spin * 0.4)
                ..rotateX(spin * 0.25)
                ..scale(bounce),
              child: DiceFace(
                value: showVal,
                size: widget.size,
                glow: true,
              ),
            );
          }
        } else if (_ready && DiceSprite.hasSprites && !isSix) {
          face = CustomPaint(
            size: Size(widget.size, widget.size),
            painter: DiceSpritePainter(
              image: DiceSprite.faceImage!,
              frame: DiceSprite.faceFrame(widget.value ?? 1),
              cols: DiceSprite.faceCols,
              rows: DiceSprite.faceRows,
              frameCount: 6,
            ),
          );
        } else {
          face = DiceFace(
            value: widget.value ?? 1,
            size: widget.size,
            glow: true,
            sixBurst: isSix,
          );
        }

        // Six radial burst rings (Ludo Buzz style cyan flash)
        if (isSix) {
          final p = Curves.easeOut.transform(_six.value.clamp(0.0, 1.0));
          return SizedBox(
            width: widget.size * 1.55,
            height: widget.size * 1.55,
            child: Stack(
              alignment: Alignment.center,
              children: [
                for (var i = 0; i < 3; i++)
                  Opacity(
                    opacity: (1 - p) * (0.7 - i * 0.15),
                    child: Container(
                      width: widget.size * (1.05 + p * (0.55 + i * 0.22)),
                      height: widget.size * (1.05 + p * (0.55 + i * 0.22)),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: Color.lerp(
                            const Color(0xFF9AE6FF),
                            const Color(0xFF2F9BFF),
                            i / 2,
                          )!,
                          width: 2.5 - i * 0.5,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF5ECBFF)
                                .withValues(alpha: 0.35 * (1 - p)),
                            blurRadius: 12,
                          ),
                        ],
                      ),
                    ),
                  ),
                // spark dots
                ...List.generate(8, (i) {
                  final a = i / 8 * pi * 2 + p * 0.8;
                  final dist = widget.size * (0.55 + p * 0.35);
                  return Positioned(
                    left: widget.size * 0.775 + cos(a) * dist - 3,
                    top: widget.size * 0.775 + sin(a) * dist - 3,
                    child: Opacity(
                      opacity: (1 - p).clamp(0.0, 1.0),
                      child: Container(
                        width: 6,
                        height: 6,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: Color(0xFFB8F0FF),
                        ),
                      ),
                    ),
                  );
                }),
                face,
              ],
            ),
          );
        }

        return face;
      },
    );
  }
}

// =============================================================================
// Default person pin (Ludo Buzz style) — NOT character PNG
// =============================================================================

class BuzzPlayerPin extends StatelessWidget {
  const BuzzPlayerPin({
    super.key,
    this.size = 44,
    this.accent = const Color(0xFF7EC8FF),
  });

  final double size;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size * 0.22),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF2A3A55), Color(0xFF152033)],
        ),
        border: Border.all(color: accent.withValues(alpha: 0.95), width: 2.2),
        boxShadow: [
          BoxShadow(
            color: accent.withValues(alpha: 0.35),
            blurRadius: 8,
            spreadRadius: 0.5,
          ),
        ],
      ),
      child: Icon(
        Icons.person,
        size: size * 0.62,
        color: Colors.white.withValues(alpha: 0.92),
      ),
    );
  }
}

// =============================================================================
// Main roll control — matches reference: pin | glowing dice tray
// =============================================================================

class RollDiceButton extends StatefulWidget {
  const RollDiceButton({
    super.key,
    required this.value,
    required this.enabled,
    required this.rolling,
    required this.onTap,
    this.turnProgress = 1.0,
    this.ringColor,
    this.ringStartAngle = -pi / 2,
    this.playerAvatar,
    this.playerLabel,
    this.compact = false,
  });

  final int? value;
  final bool enabled;
  final bool rolling;
  final VoidCallback onTap;
  final double turnProgress;
  final Color? ringColor;
  final double ringStartAngle;
  final Widget? playerAvatar;
  final String? playerLabel;
  final bool compact;

  @override
  State<RollDiceButton> createState() => _RollDiceButtonState();
}

class _RollDiceButtonState extends State<RollDiceButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulse = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1400),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final accent = widget.ringColor ?? const Color(0xFF5ECBFF);
    final diceSize = widget.compact ? 52.0 : 68.0;
    final pinSize = widget.compact ? 40.0 : 48.0;

    return AnimatedBuilder(
      animation: _pulse,
      builder: (_, __) {
        final pulse = widget.enabled ? _pulse.value : 0.25;
        return Row(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Default person pin (always — ignore character avatars for Buzz look)
            BuzzPlayerPin(size: pinSize, accent: accent),
            const SizedBox(width: 10),
            // Glowing dice tray
            GestureDetector(
              onTap: widget.enabled ? widget.onTap : null,
              child: Container(
                padding: EdgeInsets.all(widget.compact ? 8 : 12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  color: const Color(0xFF0B3A6E).withValues(alpha: 0.55),
                  border: Border.all(
                    color: Color.lerp(
                      const Color(0xFF2F9BFF),
                      const Color(0xFF9AE6FF),
                      pulse,
                    )!
                        .withValues(alpha: 0.55 + 0.4 * pulse),
                    width: 2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF3DB7FF)
                          .withValues(alpha: 0.25 + 0.35 * pulse),
                      blurRadius: 18 + 12 * pulse,
                      spreadRadius: 1 + 2 * pulse,
                    ),
                  ],
                ),
                child: SpriteDiceView(
                  value: widget.value ?? 1,
                  rolling: widget.rolling,
                  size: diceSize,
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

// =============================================================================
// Corner plate for board seats (bots + pass & play) — same Buzz look
// =============================================================================

class CornerDicePlate extends StatelessWidget {
  const CornerDicePlate({
    super.key,
    required this.value,
    required this.seatColor,
    this.seatDark,
    this.width = 120,
    this.pinOnLeft = true,
    this.live = false,
    this.pulse = 0.0,
    this.rolling = false,
    this.turnProgress,
    this.onTap,
    this.label,
  });

  final int? value;
  final Color seatColor;
  final Color? seatDark;
  final double width;
  final bool pinOnLeft;
  final bool live;
  final double pulse;
  final bool rolling;
  final double? turnProgress;
  final VoidCallback? onTap;
  final String? label;

  @override
  Widget build(BuildContext context) {
    final pinSize = (width * 0.28).clamp(32.0, 46.0);
    final diceSize = (width * 0.38).clamp(40.0, 62.0);
    final accent = seatColor;
    final glow = live ? (0.35 + 0.4 * pulse) : 0.2;

    final pin = BuzzPlayerPin(size: pinSize, accent: accent);
    final tray = GestureDetector(
      onTap: live ? onTap : null,
      child: Container(
        padding: EdgeInsets.all(width * 0.06),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: const Color(0xFF0B3A6E).withValues(alpha: 0.55),
          border: Border.all(
            color: Color.lerp(
              const Color(0xFF2F9BFF),
              accent,
              0.35,
            )!.withValues(alpha: 0.5 + glow * 0.5),
            width: 2,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF3DB7FF).withValues(alpha: glow),
              blurRadius: 14 + 10 * pulse,
              spreadRadius: live ? 1.5 : 0,
            ),
          ],
        ),
        child: SpriteDiceView(
          value: value ?? 1,
          rolling: rolling,
          size: diceSize,
        ),
      ),
    );

    final row = Row(
      mainAxisSize: MainAxisSize.min,
      children: pinOnLeft
          ? [pin, SizedBox(width: width * 0.05), tray]
          : [tray, SizedBox(width: width * 0.05), pin],
    );

    return FittedBox(
      fit: BoxFit.scaleDown,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (label != null)
            Text(
              label!,
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w900,
                color: accent,
              ),
            ),
          row,
        ],
      ),
    );
  }
}

/// Legacy ring painter kept for any remaining call sites.
class _TurnRingPainter extends CustomPainter {
  _TurnRingPainter({
    required this.progress,
    required this.color,
    this.startAngle = -pi / 2,
  });

  final double progress;
  final Color color;
  final double startAngle;

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = size.width / 2 - 3;
    final bg = Paint()
      ..color = Colors.white12
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;
    final fg = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.5
      ..strokeCap = StrokeCap.round;
    canvas.drawCircle(c, r, bg);
    canvas.drawArc(
      Rect.fromCircle(center: c, radius: r),
      startAngle,
      2 * pi * progress.clamp(0.0, 1.0),
      false,
      fg,
    );
  }

  @override
  bool shouldRepaint(covariant _TurnRingPainter old) =>
      old.progress != progress || old.color != color;
}
