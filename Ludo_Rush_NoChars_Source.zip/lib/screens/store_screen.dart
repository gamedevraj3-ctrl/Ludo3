import 'package:flutter/material.dart';

import '../core/audio.dart';

/// Store screen — same 3-zone layout as Characters screen:
/// LEFT: preview panel
/// MIDDLE: "Select Item" + 2-column scrollable grid (Coming Soon)
/// RIGHT: same category tabs + close
///
/// No real items yet — everything shows Coming Soon.
class StoreScreen extends StatefulWidget {
  const StoreScreen({super.key});

  @override
  State<StoreScreen> createState() => _StoreScreenState();
}

class _StoreScreenState extends State<StoreScreen> {
  int _tab = 0;

  static const _tabs = <String>[
    'Gaming',
    'Anime',
    'Donghua',
    'Marvels',
    'K-pop',
    'Politicians',
    'Banner',
  ];

  // Orientation locked app-wide in main.dart — no local flip.

  void _back() {
    Sfx.instance.uiClick();
    Navigator.of(context).pop();
  }

  void _selectTab(int i) {
    if (i == _tab) return;
    Sfx.instance.uiClick();
    setState(() => _tab = i);
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        Navigator.of(context).pop();
      },
      child: Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Color(0xFF1A3A5C),
                Color(0xFF0D1B2A),
                Color(0xFF0A1520),
              ],
            ),
          ),
          child: SafeArea(
            child: LayoutBuilder(
              builder: (context, cts) {
                final w = cts.maxWidth;
                final h = cts.maxHeight;
                final scale = (h / 360.0).clamp(0.7, 1.35);

                return Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // LEFT — preview
                    SizedBox(
                      width: w * 0.32,
                      child: _StorePreview(
                        categoryLabel: _tabs[_tab],
                        scale: scale,
                      ),
                    ),

                    // MIDDLE — 2-col grid (coming soon)
                    Expanded(
                      child: Padding(
                        padding: EdgeInsets.symmetric(
                          vertical: 10 * scale,
                          horizontal: 4 * scale,
                        ),
                        child: _StoreGrid(
                          categoryLabel: _tabs[_tab],
                          scale: scale,
                        ),
                      ),
                    ),

                    // RIGHT — tabs
                    SizedBox(
                      width: (w * 0.13).clamp(78.0, 110.0),
                      child: _StoreSidebar(
                        tabs: _tabs,
                        selected: _tab,
                        scale: scale,
                        onSelect: _selectTab,
                        onClose: _back,
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}

// =============================================================================
// LEFT — empty preview with category name
// =============================================================================
class _StorePreview extends StatelessWidget {
  const _StorePreview({required this.categoryLabel, required this.scale});

  final String categoryLabel;
  final double scale;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(12 * scale, 8 * scale, 4 * scale, 8 * scale),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(left: 4 * scale, top: 4 * scale),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Store',
                  style: TextStyle(
                    fontSize: 22 * scale,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    letterSpacing: 0.4,
                    shadows: const [
                      Shadow(blurRadius: 8, color: Colors.black54),
                    ],
                  ),
                ),
                SizedBox(height: 4 * scale),
                Container(
                  height: 4 * scale,
                  width: 72 * scale,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(2),
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFFD54F), Color(0xFFFFA000)],
                    ),
                  ),
                ),
                SizedBox(height: 4 * scale),
                Text(
                  categoryLabel.toUpperCase(),
                  style: TextStyle(
                    fontSize: 10 * scale,
                    fontWeight: FontWeight.w700,
                    color: Colors.white54,
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 100 * scale,
                    height: 100 * scale,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: const Color(0xFF12263A),
                      border: Border.all(
                        color: const Color(0xFF3A6A9A),
                        width: 2,
                      ),
                    ),
                    child: Icon(
                      Icons.storefront_rounded,
                      size: 48 * scale,
                      color: Colors.white24,
                    ),
                  ),
                  SizedBox(height: 14 * scale),
                  Text(
                    'Coming Soon',
                    style: TextStyle(
                      fontSize: 14 * scale,
                      fontWeight: FontWeight.w900,
                      color: Colors.white38,
                      letterSpacing: 1.0,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// =============================================================================
// MIDDLE — Select Item panel, 2-col empty slots + Coming Soon
// =============================================================================
class _StoreGrid extends StatelessWidget {
  const _StoreGrid({required this.categoryLabel, required this.scale});

  final String categoryLabel;
  final double scale;

  @override
  Widget build(BuildContext context) {
    // 6 placeholder empty slots (2 cols x 3 rows) — all Coming Soon
    const slotCount = 6;

    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF0E1A28).withValues(alpha: 0.82),
        borderRadius: BorderRadius.circular(14 * scale),
        border: Border.all(
          color: const Color(0xFF2A4A6A).withValues(alpha: 0.9),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.35),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: EdgeInsets.fromLTRB(
              14 * scale,
              12 * scale,
              14 * scale,
              8 * scale,
            ),
            child: Row(
              children: [
                Text(
                  'Select Item',
                  style: TextStyle(
                    fontSize: 15 * scale,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    letterSpacing: 0.3,
                  ),
                ),
                const Spacer(),
                Text(
                  'Coming Soon',
                  style: TextStyle(
                    fontSize: 11 * scale,
                    fontWeight: FontWeight.w800,
                    color: const Color(0xFFFFC107),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.fromLTRB(
                6 * scale,
                0,
                6 * scale,
                6 * scale,
              ),
              child: GridView.builder(
                physics: const BouncingScrollPhysics(),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 8 * scale,
                  mainAxisSpacing: 8 * scale,
                  childAspectRatio: 0.95,
                ),
                itemCount: slotCount,
                itemBuilder: (_, i) {
                  return Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFF12263A),
                      borderRadius: BorderRadius.circular(10 * scale),
                      border: Border.all(
                        color: const Color(0xFF3A6A9A),
                        width: 1.6,
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.close,
                          size: 28 * scale,
                          color: Colors.white24,
                        ),
                        SizedBox(height: 6 * scale),
                        Text(
                          'Coming Soon',
                          style: TextStyle(
                            fontSize: 10 * scale,
                            fontWeight: FontWeight.w800,
                            color: Colors.white30,
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// =============================================================================
// RIGHT — Store header + close + same category tabs
// =============================================================================
class _StoreSidebar extends StatelessWidget {
  const _StoreSidebar({
    required this.tabs,
    required this.selected,
    required this.scale,
    required this.onSelect,
    required this.onClose,
  });

  final List<String> tabs;
  final int selected;
  final double scale;
  final ValueChanged<int> onSelect;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(4 * scale, 6 * scale, 10 * scale, 8 * scale),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'Store',
                  style: TextStyle(
                    fontSize: 13 * scale,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                  ),
                ),
              ),
              GestureDetector(
                onTap: onClose,
                child: Container(
                  width: 28 * scale,
                  height: 28 * scale,
                  decoration: const BoxDecoration(
                    color: Color(0xFFE53935),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.close,
                    size: 16 * scale,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 10 * scale),
          Expanded(
            child: ListView.separated(
              physics: const BouncingScrollPhysics(),
              itemCount: tabs.length,
              separatorBuilder: (_, __) => SizedBox(height: 7 * scale),
              itemBuilder: (_, i) {
                final sel = i == selected;
                return GestureDetector(
                  onTap: () => onSelect(i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 160),
                    height: 30 * scale,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8 * scale),
                      gradient: sel
                          ? const LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [Color(0xFFFFE082), Color(0xFFFFB300)],
                            )
                          : null,
                      color: sel ? null : const Color(0xFFE8EEF5),
                      boxShadow: sel
                          ? [
                              BoxShadow(
                                color: const Color(0xFFFFB300)
                                    .withValues(alpha: 0.4),
                                blurRadius: 8,
                                offset: const Offset(0, 2),
                              ),
                            ]
                          : null,
                    ),
                    child: Text(
                      tabs[i],
                      style: TextStyle(
                        fontSize: 10.5 * scale,
                        fontWeight: FontWeight.w900,
                        color: sel
                            ? const Color(0xFF3A2800)
                            : const Color(0xFF2A3544),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
