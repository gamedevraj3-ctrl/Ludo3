import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/audio.dart';
import '../widgets/avatar.dart';

/// Profile built only from Free Fire cropped PNGs (bg removed).
/// Assets live under `assets/ui/ff_profile/`.
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({
    super.key,
    required this.name,
    required this.character,
    required this.onEditName,
    required this.onChangeCharacter,
  });

  final String name;
  final String character;
  final VoidCallback onEditName;
  final Future<void> Function() onChangeCharacter;

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late String _name = widget.name;
  late String _character = widget.character;
  int _tab = 0; // 0 gallery, 1 overview, 2 role, 3+ stack items

  static const _asset = 'assets/ui/ff_profile';
  static const _bg = Color(0xFF0A0A0A);

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
  }

  @override
  void didUpdateWidget(covariant ProfileScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.name != widget.name) _name = widget.name;
    if (oldWidget.character != widget.character) {
      _character = widget.character;
    }
  }

  String get _uid {
    final h = _name.codeUnits.fold(0, (a, b) => (a * 31 + b) & 0x7FFFFFFF);
    return (100000000 + (h % 900000000)).toString();
  }

  int get _likes {
    final h = _name.codeUnits.fold(0, (a, b) => (a * 17 + b) & 0x7FFFFFFF);
    return 1000 + (h % 99000);
  }

  int get _level {
    final h =
        _character.codeUnits.fold(0, (a, b) => (a * 13 + b) & 0x7FFFFFFF);
    return 1 + (h % 80);
  }

  int get _coins {
    final h = _name.codeUnits.fold(0, (a, b) => (a * 7 + b) & 0x7FFFFFFF);
    return 10000 + (h % 90000);
  }

  int get _diamonds {
    final h =
        _character.codeUnits.fold(0, (a, b) => (a * 11 + b) & 0x7FFFFFFF);
    return 100 + (h % 4000);
  }

  void _tap() => Sfx.instance.uiClick();

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    return Scaffold(
      backgroundColor: _bg,
      body: SafeArea(
        child: Column(
          children: [
            _topBar(size.width),
            Expanded(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _leftMenu(size.height),
                  // centre stage
                  Expanded(
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        Center(
                          child: CharacterBlend(
                            character: _character,
                            alignment: Alignment.bottomCenter,
                            widthFactor: 0.9,
                            fallbackSeed:
                                _character.codeUnits.fold(0, (a, b) => a + b),
                          ),
                        ),
                      ],
                    ),
                  ),
                  // right cards
                  SizedBox(
                    width: size.width * 0.40,
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(6, 10, 14, 10),
                      child: Column(
                        children: [
                          _idCard(),
                          const SizedBox(height: 10),
                          Expanded(
                            child: Image.asset(
                              '$_asset/panel_ranked.png',
                              fit: BoxFit.contain,
                              alignment: Alignment.topCenter,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            _bottomBar(),
          ],
        ),
      ),
    );
  }

  Widget _topBar(double w) {
    return SizedBox(
      height: 52,
      child: Row(
        children: [
          const SizedBox(width: 8),
          Image.asset('$_asset/chip_brand.png', height: 36),
          const SizedBox(width: 8),
          Expanded(
            child: Stack(
              alignment: Alignment.centerLeft,
              children: [
                Image.asset(
                  '$_asset/bar_currency.png',
                  height: 40,
                  fit: BoxFit.contain,
                  alignment: Alignment.centerLeft,
                ),
                // live numbers over the currency bar
                Positioned(
                  left: 48,
                  child: Text(
                    '$_coins',
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                    ),
                  ),
                ),
                Positioned(
                  left: 140,
                  child: Text(
                    '$_diamonds +',
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              _tap();
              Navigator.pop(context);
            },
            child: Image.asset('$_asset/btn_profile_close.png', height: 40),
          ),
          const SizedBox(width: 8),
        ],
      ),
    );
  }

  Widget _leftMenu(double h) {
    return SizedBox(
      width: 150,
      child: ListView(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 6),
        children: [
          _menuImg(
            '$_asset/tab_gallery_on.png',
            selected: _tab == 0,
            onTap: () => setState(() => _tab = 0),
          ),
          _menuImg(
            '$_asset/tab_overview.png',
            selected: _tab == 1,
            onTap: () => setState(() => _tab = 1),
          ),
          _menuImg(
            '$_asset/tab_role.png',
            selected: _tab == 2,
            onTap: () => setState(() => _tab = 2),
          ),
          // stacked menu (history → wishlist) — whole strip tappable by rows
          GestureDetector(
            onTapDown: (d) {
              _tap();
              final local = d.localPosition.dy;
              // 5 equal bands
              final band = (local / 80).floor().clamp(0, 4);
              setState(() => _tab = 3 + band);
            },
            child: Opacity(
              opacity: _tab >= 3 ? 1 : 0.95,
              child: Image.asset(
                '$_asset/tabs_menu_stack.png',
                fit: BoxFit.fitWidth,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _menuImg(String path, {required bool selected, required VoidCallback onTap}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: GestureDetector(
        onTap: () {
          _tap();
          onTap();
        },
        child: Opacity(
          opacity: selected ? 1 : 0.85,
          child: Image.asset(path, fit: BoxFit.fitWidth),
        ),
      ),
    );
  }

  Widget _idCard() {
    final likes = _likes >= 1000
        ? '${(_likes / 1000).toStringAsFixed(_likes >= 10000 ? 0 : 1)}K'
        : '$_likes';
    return AspectRatio(
      aspectRatio: 667 / 261,
      child: LayoutBuilder(
        builder: (context, c) {
          final w = c.maxWidth;
          final h = c.maxHeight;
          return Stack(
            fit: StackFit.expand,
            children: [
              Image.asset('$_asset/card_id.png', fit: BoxFit.fill),
              // avatar window (left yellow area)
              Positioned(
                left: w * 0.06,
                top: h * 0.28,
                width: w * 0.16,
                height: h * 0.48,
                child: CharacterPortrait(
                  character: _character,
                  size: w * 0.16,
                  radius: 4,
                  borderWidth: 0,
                  alignment: const Alignment(0, -0.25),
                  fallbackSeed:
                      _character.codeUnits.fold(0, (a, b) => a + b),
                ),
              ),
              // name
              Positioned(
                left: w * 0.28,
                top: h * 0.30,
                right: w * 0.08,
                child: Text(
                  _name.toUpperCase(),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: h * 0.12,
                    fontWeight: FontWeight.w900,
                    color: const Color(0xFF1A1A1A),
                  ),
                ),
              ),
              // level
              Positioned(
                left: w * 0.04,
                bottom: h * 0.08,
                child: Text(
                  'Lv.$_level',
                  style: TextStyle(
                    fontSize: h * 0.09,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                  ),
                ),
              ),
              // likes
              Positioned(
                right: w * 0.08,
                top: h * 0.55,
                child: Text(
                  likes,
                  style: TextStyle(
                    fontSize: h * 0.09,
                    fontWeight: FontWeight.w800,
                    color: const Color(0xFF1A1A1A),
                  ),
                ),
              ),
              // uid
              Positioned(
                right: w * 0.06,
                bottom: h * 0.08,
                child: Text(
                  'UID:$_uid',
                  style: TextStyle(
                    fontSize: h * 0.07,
                    fontWeight: FontWeight.w700,
                    color: Colors.white70,
                  ),
                ),
              ),
              // settings gear hit
              Positioned(
                right: 0,
                top: 0,
                width: w * 0.12,
                height: h * 0.22,
                child: GestureDetector(
                  onTap: () {
                    _tap();
                    widget.onEditName();
                  },
                  behavior: HitTestBehavior.opaque,
                  child: const SizedBox.expand(),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _bottomBar() {
    return SizedBox(
      height: 48,
      child: Row(
        children: [
          const SizedBox(width: 10),
          GestureDetector(
            onTap: _tap,
            child: Image.asset('$_asset/btn_chat.png', height: 36),
          ),
          const Spacer(),
        ],
      ),
    );
  }
}
