import 'package:flutter/material.dart';

/// All colors / gradients used across Ludo Rush.
class AppColors {
  AppColors._();

  // Backgrounds (deep purple night theme)
  static const bgTop = Color(0xFF3A2E7A);
  static const bgMid = Color(0xFF2A2160);
  static const bgBottom = Color(0xFF19113F);

  static const panel = Color(0xFF3C2F8C);
  static const panelDark = Color(0xFF2B2168);
  static const stroke = Color(0xFF6A55C8);

  static const accent = Color(0xFF8B6BFF);
  static const accentDeep = Color(0xFF5B3DD1);
  static const glow = Color(0xFFC77DFF);

  static const gold = Color(0xFFFFC93C);
  static const online = Color(0xFF35D07F);

  // Player colors (FF minimap palette)
  // yellow seat → orange, blue → cyan, red → magenta, green → purple
  static const pYellow = Color(0xFFF2A02A); // orange
  static const pYellowDark = Color(0xFFC47A12);
  static const pBlue = Color(0xFF2EC8D8); // cyan
  static const pBlueDark = Color(0xFF1A9AAB);
  static const pRed = Color(0xFFD94FC4); // magenta
  static const pRedDark = Color(0xFFA83296);
  static const pGreen = Color(0xFFA06BD4); // purple
  static const pGreenDark = Color(0xFF6E3FA3);

  static const boardCell = Color(0xFFFFFFFF);
  static const boardLine = Color(0xFFBFC6D4);
  static const star = Color(0xFF9AA3B2);

  static const LinearGradient screenBg = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [bgTop, bgMid, bgBottom],
  );

  static const LinearGradient purplePill = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF5B45B8), Color(0xFF3C2C8E)],
  );
}

/// Board / seat colors.
enum PColor { yellow, blue, red, green }

extension PColorX on PColor {
  Color get main {
    switch (this) {
      case PColor.yellow:
        return AppColors.pYellow;
      case PColor.blue:
        return AppColors.pBlue;
      case PColor.red:
        return AppColors.pRed;
      case PColor.green:
        return AppColors.pGreen;
    }
  }

  Color get dark {
    switch (this) {
      case PColor.yellow:
        return AppColors.pYellowDark;
      case PColor.blue:
        return AppColors.pBlueDark;
      case PColor.red:
        return AppColors.pRedDark;
      case PColor.green:
        return AppColors.pGreenDark;
    }
  }

  String get label {
    switch (this) {
      case PColor.yellow:
        return 'Orange';
      case PColor.blue:
        return 'Cyan';
      case PColor.red:
        return 'Magenta';
      case PColor.green:
        return 'Purple';
    }
  }

  LinearGradient get cardGradient => LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [main, dark],
  );
}

class AppText {
  AppText._();

  static const TextStyle h1 = TextStyle(
    fontSize: 30,
    fontWeight: FontWeight.w900,
    color: Colors.white,
    letterSpacing: 1.2,
  );

  static const TextStyle h2 = TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.w800,
    color: Colors.white,
  );

  static const TextStyle body = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.w600,
    color: Colors.white,
  );

  static const TextStyle small = TextStyle(
    fontSize: 11,
    fontWeight: FontWeight.w600,
    color: Colors.white70,
  );
}

ThemeData buildAppTheme() {
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: AppColors.bgBottom,
    colorScheme: ColorScheme.fromSeed(
      seedColor: AppColors.accent,
      brightness: Brightness.dark,
    ),
    fontFamily: 'Roboto',
    dialogTheme: const DialogThemeData(backgroundColor: AppColors.panelDark),
    cardTheme: const CardThemeData(color: AppColors.panel),
  );
}
