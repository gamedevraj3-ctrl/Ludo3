import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/audio.dart';
import '../core/theme.dart';
import '../core/game_theme.dart';
import '../widgets/avatar.dart';
import '../game/game_speed.dart';
import '../game/characters.dart' as roster;
import '../game/models.dart';
import 'characters_screen.dart';
import 'profile_screen.dart';
import 'store_screen.dart';
import 'game_screen.dart';

/// ---------------------------------------------------------------------------
/// Part 3 rebuild — "Free Fire hub" lobby.
///
/// This replaces the earlier cyberpunk-cityscape lobby with a pixel-matched
/// recreation of the user's reference screenshot (a Free-Fire-style military
/// camp hub): top-left profile + rank crest, top-centre currency pill,
/// top-right icon trio, purple SUBSCRIBE promo banner, a vertical 6-item
/// sidebar menu, a full hero character overlay standing in the scene, and a
/// bottom-right mode-tag + START combo with a bottom-left chat icon.
///
/// All positions below are driven from the same percentage-based layout that
/// was measured directly off the reference image, so the composition holds
/// at any screen size via `LayoutBuilder` + percentage `Positioned` offsets
/// instead of fixed pixels.
/// ---------------------------------------------------------------------------
class LobbyScreen extends StatefulWidget {
  const LobbyScreen({super.key});

  @override
  State<LobbyScreen> createState() => _LobbyScreenState();
}

class _LobbyScreenState extends State<LobbyScreen>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  String _name = 'You';
  MatchMode _matchMode = MatchMode.rush;
  int _killTarget = 5;
  GameMode _gameMode = GameMode.bots;
  bool _sound = true;

  /// The character the player is wearing. Persisted, so it survives restarts.
  String _character = roster.Characters.byName('Rin').name;

  /// Pass & Play friend portraits (seats 1..n-1). Length always == _players - 1.
  List<String> _friendCharacters = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _lockLandscape();
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  void _lockLandscape() {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _lockLandscape();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _name = p.getString('name') ?? 'You';
      _sound = p.getBool('sound_on') ?? true;
      _character = roster.Characters.byName(
        p.getString('character') ?? 'Rin',
      ).name;
      final mi = p.getInt('match_mode');
      if (mi != null && mi >= 0 && mi < MatchMode.values.length) {
        _matchMode = MatchMode.values[mi];
      }
      _players = (p.getInt('last_players') ?? 4).clamp(2, 4);
      _botLevel = (p.getInt('last_level') ?? 3).clamp(1, 3);
      final si = p.getInt('speed');
      if (si != null && si >= 0 && si < SpeedPreset.values.length) {
        _speed = SpeedPreset.values[si];
      }
      _syncFriendSeats();
    });
  }

  Future<void> _saveName(String v) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('name', v);
    if (!mounted) return;
    setState(() => _name = v);
  }

  void _syncFriendSeats() {
    final need = (_players - 1).clamp(0, 3);
    final cat = roster.Characters.categoryOf(_character);
    final used = <String>{_character};
    final next = <String>[];
    // Keep only friends already in the host's current category.
    for (final f in _friendCharacters) {
      if (next.length >= need) break;
      if (used.contains(f)) continue;
      if (roster.Characters.categoryOf(f) != cat) continue;
      next.add(f);
      used.add(f);
    }
    // Fill remaining seats from host category (random-ish unique faces).
    final pool = roster.Characters.byCategory(cat)
        .where((c) => !used.contains(c.name))
        .toList();
    pool.shuffle();
    var i = 0;
    while (next.length < need) {
      String name;
      if (i < pool.length) {
        name = pool[i].name;
        i++;
      } else {
        final fallback = roster.Characters.all
            .where((c) => !used.contains(c.name))
            .toList();
        name = fallback.isNotEmpty ? fallback.first.name : 'Rin';
      }
      next.add(name);
      used.add(name);
    }
    _friendCharacters = next;
  }

  Future<void> _openCharacters() async {
    Sfx.instance.uiClick();
    final picked = await Navigator.of(context).push<String>(
      MaterialPageRoute(builder: (_) => CharactersScreen(selected: _character)),
    );
    _lockLandscape();
    if (picked != null && mounted) {
      setState(() {
        _character = picked;
        _syncFriendSeats();
      });
    }
  }

  Future<void> _openFriendCharacter(int friendIndex) async {
    Sfx.instance.uiClick();
    if (friendIndex < 0 || friendIndex >= _friendCharacters.length) return;
    final current = _friendCharacters[friendIndex];
    // Friends may only pick from the same category as the host player.
    final hostCat = roster.Characters.categoryOf(_character);
    final picked = await Navigator.of(context).push<String>(
      MaterialPageRoute(
        builder: (_) => CharactersScreen(
          selected: current,
          lockedCategory: hostCat,
          persistSelection: false,
        ),
      ),
    );
    _lockLandscape();
    if (picked != null && mounted) {
      // Enforce category even if something slipped through.
      final cat = roster.Characters.categoryOf(picked);
      if (cat != hostCat) return;
      setState(() {
        _friendCharacters[friendIndex] = roster.Characters.byName(picked).name;
      });
    }
  }

  void _openProfile() {
    Sfx.instance.uiClick();
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ProfileScreen(
          name: _name,
          character: _character,
          onEditName: _editName,
          onChangeCharacter: _openCharacters,
        ),
      ),
    ).then((_) async {
      // refresh name/character after return
      final p = await SharedPreferences.getInstance();
      if (!mounted) return;
      setState(() {
        _name = p.getString('name') ?? _name;
        _character = roster.Characters.byName(
          p.getString('character') ?? _character,
        ).name;
      });
    });
  }

  void _openStore() {

    Sfx.instance.uiClick();
    Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => const StoreScreen()))
        .then((_) => _lockLandscape());
  }

  void _openEmptySheet(String title, String note) {
    Sfx.instance.uiClick();
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.panelDark,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => _EmptySheet(title: title, note: note),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GameColors.bgVoid,
      body: Stack(
        children: [
          // 1) Free-Fire-style military camp backdrop, full-bleed.
          Positioned.fill(
            child: Image.asset(
              GameArt.ffLobbyBackground,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const DecoratedBox(
                decoration: BoxDecoration(gradient: GameGradients.screen),
              ),
            ),
          ),
          // 2) very light scrim so the daylight scene stays bright (like the
          // reference) while the UI chrome is still readable.
          Positioned.fill(
            child: IgnorePointer(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withValues(alpha: 0.22),
                      Colors.black.withValues(alpha: 0.02),
                      Colors.black.withValues(alpha: 0.10),
                      Colors.black.withValues(alpha: 0.38),
                    ],
                    stops: const [0.0, 0.22, 0.6, 1.0],
                  ),
                ),
              ),
            ),
          ),
          SafeArea(
            child: LayoutBuilder(
              builder: (context, cts) {
                final w = cts.maxWidth;
                final h = cts.maxHeight;
                return Stack(
                  clipBehavior: Clip.none,
                  children: [
                    // ---- hero character (centre stage, no pet) ----
                    if (_gameMode != GameMode.passAndPlay)
                      Positioned(
                        left: w * 0.32,
                        top: h * 0.06,
                        width: w * 0.36,
                        height: h * 0.82,
                        child: IgnorePointer(
                          child: CharacterBlend(
                            character: _character,
                            alignment: Alignment.bottomCenter,
                            widthFactor: 0.88,
                            fallbackSeed: _character.codeUnits.fold(
                              0,
                              (a, b) => a + b,
                            ),
                          ),
                        ),
                      ),

                    // ---- party strip: Pass & Play only ----
                    if (_gameMode == GameMode.passAndPlay)
                      Positioned(
                        left: w * 0.22,
                        right: w * 0.28,
                        top: h * 0.32,
                        bottom: h * 0.28,
                        child: Center(
                          child: _PartyStrip(
                            myCharacter: _character,
                            friendCharacters: _friendCharacters,
                            playerCount: _players,
                            passAndPlay: true,
                            onTapMe: () {},
                            onTapFriend: _openFriendCharacter,
                          ),
                        ),
                      ),

                    // ---- top-left: FF profile block ----
                    Positioned(
                      left: w * 0.012,
                      top: h * 0.012,
                      child: _ProfileBlock(
                        name: _name,
                        character: _character,
                        onOpenProfile: _openProfile,
                        onEditName: _editName,
                      ),
                    ),

                    // ---- top-centre: currency ----
                    Positioned(
                      left: w * 0.28,
                      top: h * 0.018,
                      child: const _CurrencyBar(gold: '8112', gems: '202'),
                    ),

                    // ---- top-right: FF-style icons ----
                    Positioned(
                      right: w * 0.01,
                      top: h * 0.015,
                      child: _TopRightIcons(
                        onCamera: () => _openEmptySheet(
                          'SCREENSHOT',
                          'Screen capture isn\'t wired up in this build.',
                        ),
                        onSettings: _openSettings,
                        sound: _sound,
                      ),
                    ),

                    // ---- left sidebar: STORE / LUCK ROYALE / BOOYAH PASS / MISSIONS / EVENTS ----
                    Positioned(
                      left: w * 0.012,
                      top: h * 0.30,
                      bottom: h * 0.14,
                      width: w * 0.16,
                      child: _Sidebar(
                        onStore: _openStore,
                        onLuckRoyale: () => _openEmptySheet(
                          'LUCK ROYALE',
                          'No crates available right now.',
                        ),
                        onCharacter: _openCharacters,
                        onVault: () => _openEmptySheet(
                          'BOOYAH PASS',
                          'Booyah Pass is coming soon.',
                        ),
                        onCollection: () => _openEmptySheet(
                          'MISSIONS',
                          'No missions available offline.',
                        ),
                        onWeapon: () => _openEmptySheet(
                          'EVENTS',
                          'No events right now.',
                        ),
                      ),
                    ),

                    // ---- right: friends list (FF style) ----
                    Positioned(
                      right: w * 0.01,
                      top: h * 0.12,
                      bottom: h * 0.22,
                      width: w * 0.13,
                      child: _FriendsRail(
                        onTap: () => _openEmptySheet(
                          'FRIENDS',
                          'Friends list is offline in this build.',
                        ),
                      ),
                    ),

                    // ---- bottom dock: F / VAULT / WEAPON / PRESET / LAB + chat ----
                    Positioned(
                      left: w * 0.01,
                      right: w * 0.28,
                      bottom: h * 0.02,
                      height: h * 0.09,
                      child: _BottomDock(
                        onChat: () => _openEmptySheet(
                          'CHAT',
                          'Chat isn\'t available offline.',
                        ),
                        onVault: () => _openEmptySheet('VAULT', 'No items stored yet.'),
                        onWeapon: () => _openEmptySheet('WEAPON', 'No weapons in this mode.'),
                        onPreset: () => _openEmptySheet('PRESET', 'Presets coming soon.'),
                        onLab: () => _openEmptySheet('LAB', 'Lab is offline.'),
                        onCharacter: _openCharacters,
                      ),
                    ),

                    // ---- bottom-right: ranked strip + START ----
                    Positioned(
                      right: w * 0.012,
                      bottom: h * 0.02,
                      child: _ModeAndStart(
                        matchMode: _matchMode,
                        gameMode: _gameMode,
                        onTapMode: _openSetup,
                        onStart: _startFromLobby,
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // ------------------------------------------------------------------ flows

  void _openSettings() {
    Sfx.instance.uiClick();
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.panelDark,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => _LobbySettingsSheet(
        onEditName: () {
          Navigator.pop(context);
          _editName();
        },
      ),
    );
  }

  void _editName() {
    Sfx.instance.uiClick();
    final ctrl = TextEditingController(text: _name);
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.panelDark,
        title: const Text('Your Name', style: AppText.h2),
        content: TextField(
          controller: ctrl,
          maxLength: 14,
          style: AppText.body,
          decoration: const InputDecoration(hintText: 'Enter name'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              final v = ctrl.text.trim();
              if (v.isNotEmpty) _saveName(v);
              Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  // Setup prefs held on the lobby so START uses them.
  int _players = 4;
  int _matchSeconds = 4 * 60;
  int _turnSeconds = 10;
  int _botLevel = 3;
  SpeedPreset _speed = SpeedPreset.fast;

  void _openSetup(GameMode mode) {
    Sfx.instance.uiClick();
    setState(() => _gameMode = mode);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.panelDark,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => _SetupSheet(
        mode: mode,
        matchMode: _matchMode,
        myName: _name,
        onApply: (cfg) {
          setState(() {
            _gameMode = cfg.mode;
            _matchMode = cfg.matchMode;
            _players = cfg.playerCount;
            _matchSeconds = cfg.matchSeconds;
            _turnSeconds = cfg.turnSeconds;
            _botLevel = cfg.botLevel;
            _speed = cfg.speed;
            _killTarget = cfg.killTarget;
            _syncFriendSeats();
          });
        },
      ),
    );
  }

  List<String> _seatCharacterList() {
    _syncFriendSeats();
    return [_character, ..._friendCharacters].take(_players).toList();
  }

  void _startFromLobby() {
    Sfx.instance.uiClick();
    // Pass & Play: use lobby-picked seats. Bots: null → engine picks random
    // faces from the player's category only.
    final seats = _gameMode == GameMode.passAndPlay
        ? _seatCharacterList()
        : null;
    _start(
      GameConfig(
        mode: _gameMode,
        matchMode: _matchMode,
        playerCount: _players,
        matchSeconds: _matchSeconds,
        turnSeconds: 10, // always 10s
        myName: _name,
        myCharacter: _character,
        seatCharacters: seats,
        botLevel: 3, // always Pro
        speed: SpeedPreset.fast, // always Fast
        killTarget: _killTarget,
      ),
    );
  }

  void _start(GameConfig cfg) {
    final seats = cfg.mode == GameMode.passAndPlay
        ? (cfg.seatCharacters ?? _seatCharacterList())
        : null;
    Navigator.of(context)
        .push(
          MaterialPageRoute(
            builder: (_) => GameScreen(
              config: GameConfig(
                mode: cfg.mode,
                matchMode: cfg.matchMode,
                playerCount: cfg.playerCount,
                matchSeconds: cfg.matchSeconds,
                turnSeconds: cfg.turnSeconds,
                myName: _name,
                myCharacter: _character,
                seatCharacters: seats,
                botLevel: cfg.botLevel,
                speed: cfg.speed,
                killTarget: cfg.killTarget,
              ),
            ),
          ),
        )
        .then((_) {
          // The match locks portrait while it's playing; re-assert landscape
          // now that we're back so the lobby never gets stuck in portrait.
          _lockLandscape();
          _load();
        });
  }
}

// =============================================================================
// Top-left FF-style profile: diamond avatar + name/guild/level + promo banner.
// =============================================================================
class _ProfileBlock extends StatelessWidget {
  const _ProfileBlock({
    required this.name,
    required this.character,
    required this.onOpenProfile,
    required this.onEditName,
  });

  final String name;
  final String character;
  final VoidCallback onOpenProfile;
  final VoidCallback onEditName;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        // Avatar + name (no Lv under name)
        GestureDetector(
          onTap: onOpenProfile,
          behavior: HitTestBehavior.opaque,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(
                width: 56,
                height: 56,
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Container(
                      width: 52,
                      height: 52,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        gradient: const LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [Color(0xFFFF6B4A), Color(0xFF8B1A2A)],
                        ),
                        border: Border.all(
                          color: const Color(0xFFFFD27A),
                          width: 2.2,
                        ),
                        boxShadow: const [
                          BoxShadow(
                            color: Color(0x88000000),
                            blurRadius: 8,
                            offset: Offset(0, 3),
                          ),
                        ],
                      ),
                      clipBehavior: Clip.antiAlias,
                      child: CharacterPortrait(
                        character: character,
                        size: 52,
                        radius: 8,
                        borderWidth: 0,
                        alignment: const Alignment(0, -0.35),
                        fallbackSeed:
                            character.codeUnits.fold(0, (a, b) => a + b),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      height: 1.1,
                      shadows: [Shadow(color: Colors.black87, blurRadius: 4)],
                    ),
                  ),
                  const SizedBox(height: 3),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 5,
                          vertical: 1,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFF2A6BFF).withValues(alpha: 0.85),
                          borderRadius: BorderRadius.circular(3),
                        ),
                        child: const Text(
                          'LUDO',
                          style: TextStyle(
                            fontSize: 8,
                            fontWeight: FontWeight.w800,
                            color: Colors.white,
                            letterSpacing: 0.4,
                          ),
                        ),
                      ),
                      const SizedBox(width: 4),
                      const Text(
                        'Rush',
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: Colors.white70,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 6),
        const SizedBox(height: 6),
        // Free Fire–style promo banner under profile
        Container(
          width: 172,
          height: 52,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF2A1A4A),
                Color(0xFF1A0E2E),
                Color(0xFF0D0818),
              ],
            ),
            border: Border.all(color: const Color(0xFFFFC425), width: 1.5),
            boxShadow: const [
              BoxShadow(
                color: Color(0x88000000),
                blurRadius: 8,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Stack(
            children: [
              // gold edge accent (left)
              Positioned(
                left: 0,
                top: 0,
                bottom: 0,
                width: 4,
                child: Container(
                  decoration: const BoxDecoration(
                    color: Color(0xFFFFC425),
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(5),
                      bottomLeft: Radius.circular(5),
                    ),
                  ),
                ),
              ),
              // soft glow
              Positioned(
                right: -10,
                top: -10,
                child: Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        const Color(0xFFFFC425).withValues(alpha: 0.22),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 6, 10, 6),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      'LUDO RUSH',
                      style: TextStyle(
                        fontSize: 8,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFFFFC425),
                        letterSpacing: 1.2,
                      ),
                    ),
                    const SizedBox(height: 2),
                    const Text(
                      'Made by Lucifer',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 0.4,
                        shadows: [
                          Shadow(color: Colors.black87, blurRadius: 4),
                        ],
                      ),
                    ),
                    const SizedBox(height: 2),
                    Container(
                      height: 2.5,
                      width: 70,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(2),
                        gradient: const LinearGradient(
                          colors: [
                            Color(0xFFFFE082),
                            Color(0xFFFFC425),
                            Color(0x00FFC425),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// =============================================================================
// Top-centre currency pill: gold coins + purple gems on a slanted dark bar.
// =============================================================================
class _CurrencyBar extends StatelessWidget {
  const _CurrencyBar({required this.gold, required this.gems});

  final String gold;
  final String gems;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 30,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: const Color(0xFF1C2433).withValues(alpha: 0.72),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white24, width: 1),
        boxShadow: GameShadows.raised,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _coinIcon(),
          const SizedBox(width: 6),
          Text(
            gold,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w900,
              color: Colors.white,
            ),
          ),
          Container(
            width: 1,
            height: 16,
            margin: const EdgeInsets.symmetric(horizontal: 12),
            color: Colors.white24,
          ),
          _gemIcon(),
          const SizedBox(width: 6),
          Text(
            gems,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w900,
              color: Colors.white,
            ),
          ),
          const SizedBox(width: 6),
          Container(
            width: 16,
            height: 16,
            decoration: const BoxDecoration(
              color: Color(0xFF3EBE52),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.add, size: 12, color: Colors.white),
          ),
        ],
      ),
    );
  }

  Widget _coinIcon() => Container(
    width: 16,
    height: 16,
    decoration: const BoxDecoration(
      color: GameColors.coin,
      shape: BoxShape.circle,
    ),
    child: const Center(
      child: Text(
        '\$',
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w900,
          color: Color(0xFF8A5A00),
        ),
      ),
    ),
  );

  Widget _gemIcon() => const Icon(
    Icons.diamond,
    size: 15,
    color: Color(0xFF9B6BD8),
  );
}

// =============================================================================
// Top-right icon trio: camera / settings / signal+battery.
// =============================================================================
class _TopRightIcons extends StatelessWidget {
  const _TopRightIcons({
    required this.onCamera,
    required this.onSettings,
    required this.sound,
  });

  final VoidCallback onCamera;
  final VoidCallback onSettings;
  final bool sound;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _dot(icon: Icons.camera_alt_rounded, onTap: onCamera),
        const SizedBox(width: 8),
        _pngDot(asset: 'assets/ui/icon_setting.png', onTap: onSettings),
        const SizedBox(width: 8),
        Container(
          width: 30,
          height: 30,
          decoration: BoxDecoration(
            color: Colors.black.withValues(alpha: 0.38),
            shape: BoxShape.circle,
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              const Icon(Icons.wifi_rounded, size: 15, color: Colors.white),
              Positioned(
                right: 4,
                top: 5,
                child: Container(
                  width: 6,
                  height: 6,
                  decoration: const BoxDecoration(
                    color: Color(0xFF3EBE52),
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _dot({required IconData icon, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 30,
        height: 30,
        decoration: BoxDecoration(
          color: Colors.black.withValues(alpha: 0.38),
          shape: BoxShape.circle,
        ),
        child: Icon(icon, size: 15, color: Colors.white),
      ),
    );
  }

  Widget _pngDot({required String asset, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 30,
        height: 30,
        decoration: BoxDecoration(
          color: Colors.black.withValues(alpha: 0.38),
          shape: BoxShape.circle,
        ),
        padding: const EdgeInsets.all(5),
        child: Image.asset(
          asset,
          fit: BoxFit.contain,
          errorBuilder: (_, __, ___) =>
              const Icon(Icons.settings_rounded, size: 15, color: Colors.white),
        ),
      ),
    );
  }
}

// =============================================================================
// Purple "FFI GAME DEV RAJ" promo banner + red SUBSCRIBE pill.
// =============================================================================
class _PromoBanner extends StatelessWidget {
  const _PromoBanner();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF5E1A63), Color(0xFF3A1042)],
        ),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: const Color(0xFFC79CF0).withValues(alpha: 0.55),
          width: 1,
        ),
        boxShadow: GameShadows.raised,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text(
            'FFI',
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w900,
              color: Colors.white,
              letterSpacing: 0.5,
              shadows: [Shadow(color: Colors.black54, blurRadius: 3)],
            ),
          ),
          const Text(
            'GAME DEV RAJ',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: Colors.white,
              letterSpacing: 0.3,
              shadows: [Shadow(color: Colors.black54, blurRadius: 3)],
            ),
          ),
          const SizedBox(height: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: const Color(0xFFE0302C),
              borderRadius: BorderRadius.circular(5),
              boxShadow: GameShadows.button,
            ),
            child: const Text(
              'SUBSCRIBE',
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w900,
                color: Colors.white,
                letterSpacing: 0.4,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// =============================================================================
// Left vertical sidebar — FF reference order:
// STORE / LUCK ROYALE / BOOYAH PASS / MISSIONS / EVENTS
// =============================================================================
class _Sidebar extends StatelessWidget {
  const _Sidebar({
    required this.onStore,
    required this.onLuckRoyale,
    required this.onCharacter,
    required this.onVault,
    required this.onCollection,
    required this.onWeapon,
  });

  final VoidCallback onStore;
  final VoidCallback onLuckRoyale;
  final VoidCallback onCharacter;
  final VoidCallback onVault;
  final VoidCallback onCollection;
  final VoidCallback onWeapon;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _item(
          icon: Icons.shopping_cart_rounded,
          label: 'STORE',
          iconColor: const Color(0xFFFF4B4B),
          glow: true,
          onTap: onStore,
          iconAsset: 'assets/ui/icon_store.png',
        ),
        const SizedBox(height: 4),
        _item(
          icon: Icons.card_giftcard_rounded,
          label: 'LUCK ROYALE',
          iconColor: const Color(0xFFFF8A3D),
          onTap: onLuckRoyale,
        ),
        const SizedBox(height: 4),
        _item(
          icon: Icons.confirmation_number_rounded,
          label: 'BOOYAH PASS',
          iconColor: const Color(0xFFFFC93C),
          onTap: onVault,
        ),
        const SizedBox(height: 4),
        _item(
          icon: Icons.flag_rounded,
          label: 'MISSIONS',
          iconColor: const Color(0xFF5B8CFF),
          onTap: onCollection,
        ),
        const SizedBox(height: 4),
        _item(
          icon: Icons.event_rounded,
          label: 'EVENTS',
          iconColor: const Color(0xFFE85D9A),
          onTap: onWeapon,
        ),
        // Character access kept via bottom dock / profile
        const SizedBox(height: 6),
        _item(
          icon: Icons.person_rounded,
          label: 'CHARACTER',
          iconColor: Colors.white,
          onTap: onCharacter,
        ),
      ],
    );
  }

  Widget _item({
    required IconData icon,
    required String label,
    required Color iconColor,
    required VoidCallback onTap,
    bool glow = false,
    String? iconAsset,
  }) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
        decoration: BoxDecoration(
          color: Colors.black.withValues(alpha: 0.46),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.white.withValues(alpha: 0.12)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (iconAsset != null)
              Image.asset(
                iconAsset,
                width: 16,
                height: 16,
                fit: BoxFit.contain,
                errorBuilder: (_, __, ___) => Icon(
                  icon,
                  size: 15,
                  color: iconColor,
                ),
              )
            else
              Icon(
                icon,
                size: 15,
                color: iconColor,
                shadows: glow
                    ? [
                        Shadow(
                          color: iconColor.withValues(alpha: 0.8),
                          blurRadius: 6,
                        ),
                      ]
                    : null,
              ),
            const SizedBox(width: 6),
            Flexible(
              child: FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(
                  label,
                  maxLines: 1,
                  softWrap: false,
                  style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    letterSpacing: 0.4,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// =============================================================================
// Bottom-left chat icon.
// =============================================================================
class _ChatIcon extends StatelessWidget {
  const _ChatIcon({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 28,
        height: 28,
        child: Image.asset(
          'assets/ui/icon_mail.png',
          fit: BoxFit.contain,
          errorBuilder: (_, __, ___) => const Icon(
            Icons.mail_outline_rounded,
            size: 20,
            color: Colors.white70,
          ),
        ),
      ),
    );
  }
}


// =============================================================================
// Right friends rail (FF-style compact list)
// =============================================================================
class _FriendsRail extends StatelessWidget {
  const _FriendsRail({required this.onTap});
  final VoidCallback onTap;

  static const _names = [
    'DREKING12',
    'AvaOm719',
    'S.W.A.6',
    '@kennyLO',
  ];

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          for (var i = 0; i < _names.length; i++) ...[
            if (i > 0) const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.45),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.white24),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 22,
                    height: 22,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [
                          HSVColor.fromAHSV(1, (i * 70) % 360, 0.6, 0.9).toColor(),
                          HSVColor.fromAHSV(1, (i * 70 + 40) % 360, 0.7, 0.6).toColor(),
                        ],
                      ),
                    ),
                    child: const Icon(Icons.person, size: 14, color: Colors.white),
                  ),
                  const SizedBox(width: 5),
                  Flexible(
                    child: Text(
                      _names[i],
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 9,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// =============================================================================
// Bottom dock — F / VAULT / WEAPON / PRESET / LAB (FF reference)
// =============================================================================
class _BottomDock extends StatelessWidget {
  const _BottomDock({
    required this.onChat,
    required this.onVault,
    required this.onWeapon,
    required this.onPreset,
    required this.onLab,
    required this.onCharacter,
  });

  final VoidCallback onChat;
  final VoidCallback onVault;
  final VoidCallback onWeapon;
  final VoidCallback onPreset;
  final VoidCallback onLab;
  final VoidCallback onCharacter;

  @override
  Widget build(BuildContext context) {
    Widget tab(IconData icon, String label, VoidCallback onTap) {
      return GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 18, color: Colors.white70),
              const SizedBox(height: 2),
              Text(
                label,
                style: const TextStyle(
                  fontSize: 8.5,
                  fontWeight: FontWeight.w800,
                  color: Colors.white70,
                  letterSpacing: 0.4,
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        // Chat
        GestureDetector(
          onTap: onChat,
          child: Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: 0.5),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.white24),
            ),
            child: const Icon(Icons.chat_bubble_outline, size: 18, color: Colors.white),
          ),
        ),
        const SizedBox(width: 8),
        // F badge
        Container(
          width: 34,
          height: 34,
          decoration: BoxDecoration(
            color: const Color(0xFF1A1A1A),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: const Color(0xFFFFC93C), width: 1.5),
          ),
          child: const Center(
            child: Text(
              'F',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w900,
                color: Color(0xFFFFC93C),
              ),
            ),
          ),
        ),
        const SizedBox(width: 4),
        Expanded(
          child: Container(
            height: 40,
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: 0.42),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.white12),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                tab(Icons.inventory_2_outlined, 'VAULT', onVault),
                tab(Icons.gps_fixed, 'WEAPON', onWeapon),
                tab(Icons.person_outline, 'PRESET', onPreset),
                tab(Icons.science_outlined, 'LAB', onLab),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

// =============================================================================
// Bottom-right: CS-RANKED style strip + big gold START (FF reference)
// =============================================================================
class _ModeAndStart extends StatelessWidget {
  const _ModeAndStart({
    required this.matchMode,
    required this.gameMode,
    required this.onTapMode,
    required this.onStart,
  });

  final MatchMode matchMode;
  final GameMode gameMode;
  final void Function(GameMode) onTapMode;
  final VoidCallback onStart;

  @override
  Widget build(BuildContext context) {
    final modeLabel = switch (matchMode) {
      MatchMode.rush => 'RUSH',
      MatchMode.classic => 'CLASSIC',
      MatchMode.kill => 'KILL',
      MatchMode.deathMatch => 'DEATH MATCH',
    };
    final sub = gameMode == GameMode.bots ? 'VS Bots · Random Map' : 'Pass & Play · Local';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      mainAxisSize: MainAxisSize.min,
      children: [
        // Ranked / mode strip (like CS-RANKED panel)
        GestureDetector(
          onTap: () => onTapMode(gameMode),
          child: Container(
            width: 168,
            padding: const EdgeInsets.fromLTRB(10, 6, 10, 6),
            decoration: BoxDecoration(
              color: const Color(0xFF141820).withValues(alpha: 0.92),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: const Color(0xFF3A4555)),
            ),
            child: Row(
              children: [
                Container(
                  width: 28,
                  height: 28,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      colors: [Color(0xFF6EC8FF), Color(0xFF2A5CFF)],
                    ),
                    border: Border.all(color: Colors.white54),
                  ),
                  child: const Icon(Icons.shield, size: 16, color: Colors.white),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        modeLabel,
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          color: Color(0xFFFFD27A),
                          letterSpacing: 0.5,
                        ),
                      ),
                      Text(
                        sub,
                        style: const TextStyle(
                          fontSize: 8,
                          fontWeight: FontWeight.w700,
                          color: Colors.white60,
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right, size: 16, color: Colors.white54),
              ],
            ),
          ),
        ),
        const SizedBox(height: 6),
        // Big START — FF gold bar
        GestureDetector(
          onTap: onStart,
          child: Container(
            width: 168,
            height: 48,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFFFFE14A), Color(0xFFF5A000), Color(0xFFE07000)],
              ),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: const Color(0xFFFFF0A0), width: 1.2),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFF8A00).withValues(alpha: 0.55),
                  blurRadius: 14,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: const Center(
              child: Text(
                'START',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 3,
                  color: Color(0xFF2A1A00),
                  shadows: [
                    Shadow(color: Colors.white38, blurRadius: 0, offset: Offset(0, 1)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// =============================================================================
// Generic "coming soon" bottom sheet used by every sidebar/HUD placeholder.
// =============================================================================
class _EmptySheet extends StatelessWidget {
  const _EmptySheet({required this.title, required this.note});

  final String title;
  final String note;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 46,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
            const SizedBox(height: 16),
            Text(title, style: AppText.h2),
            const SizedBox(height: 8),
            Text(note, style: AppText.small, textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}

/// Lobby settings sheet: sound effects toggle and a name shortcut.
class _LobbySettingsSheet extends StatefulWidget {
  const _LobbySettingsSheet({required this.onEditName});

  final VoidCallback onEditName;

  @override
  State<_LobbySettingsSheet> createState() => _LobbySettingsSheetState();
}

class _LobbySettingsSheetState extends State<_LobbySettingsSheet> {
  @override
  Widget build(BuildContext context) {
    final on = Sfx.instance.enabled;
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 46,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ),
            const SizedBox(height: 14),
            const Text('Settings', style: AppText.h2),
            const SizedBox(height: 12),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              value: on,
              
              secondary: Icon(
                on ? Icons.volume_up_rounded : Icons.volume_off_rounded,
                color: on ? AppColors.online : Colors.white38,
              ),
              title: const Text('Sound effects', style: AppText.body),
              subtitle: Text(
                on ? 'Dice, hops, cuts & fanfare' : 'Muted',
                style: AppText.small,
              ),
              onChanged: (v) async {
                await Sfx.instance.setEnabled(v);
                if (!mounted) return;
                setState(() {});
                if (v) Sfx.instance.uiClick();
              },
            ),
            const Divider(color: Colors.white12, height: 1),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.badge_outlined, color: Colors.white70),
              title: const Text('Edit name', style: AppText.body),
              trailing: const Icon(Icons.chevron_right, color: Colors.white38),
              onTap: widget.onEditName,
            ),
          ],
        ),
      ),
    );
  }
}

/// Clean professional match setup — modes, play style, players only.
/// Turn timer fixed 10s · speed fixed Fast · bots fixed Pro.
class _SetupSheet extends StatefulWidget {
  const _SetupSheet({
    required this.mode,
    required this.matchMode,
    required this.myName,
    required this.onApply,
  });

  final GameMode mode;
  final MatchMode matchMode;
  final String myName;
  final void Function(GameConfig) onApply;

  @override
  State<_SetupSheet> createState() => _SetupSheetState();
}

class _SetupSheetState extends State<_SetupSheet> {
  late MatchMode _match;
  late GameMode _mode;
  int _players = 4;
  int _minutes = 4;
  bool _customTime = false;
  double _customMinutes = 10;
  int _killTarget = 5;

  @override
  void initState() {
    super.initState();
    _match = widget.matchMode;
    _mode = widget.mode;
    _killTarget = 5;
    _loadPrefs();
  }

  Future<void> _loadPrefs() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _players = (p.getInt('last_players') ?? 4).clamp(2, 4);
      final mi = p.getInt('match_mode');
      if (mi != null && mi >= 0 && mi < MatchMode.values.length) {
        _match = MatchMode.values[mi];
      }
      final gi = p.getInt('game_mode');
      if (gi != null && gi >= 0 && gi < GameMode.values.length) {
        _mode = GameMode.values[gi];
      }
      _killTarget = (p.getInt('kill_target') ?? 5).clamp(4, 7);
    });
  }

  Future<void> _remember() async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('last_players', _players);
    await p.setInt('match_mode', _match.index);
    await p.setInt('game_mode', _mode.index);
    await p.setInt('kill_target', _killTarget);
  }

  void _apply() {
    _remember();
    widget.onApply(
      GameConfig(
        mode: _mode,
        matchMode: _match,
        playerCount: _players,
        matchSeconds: _match.isRush
            ? (_customTime ? _customMinutes.round() : _minutes) * 60
            : 30 * 60,
        turnSeconds: 10, // always
        myName: widget.myName,
        botLevel: 3, // always Pro
        speed: SpeedPreset.fast, // always Fast
        killTarget: _killTarget,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: true,
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) _apply();
      },
      child: SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 10, 20, 18),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Handle
              Center(
                child: Container(
                  width: 42,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              const Text(
                'MATCH SETUP',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.6,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Turn 10s · Speed Fast · Bots Pro',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  color: Colors.white.withValues(alpha: 0.45),
                  letterSpacing: 0.4,
                ),
              ),
              const SizedBox(height: 18),

              // —— GAME MODE ——
              _sectionTitle('GAME MODE'),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: _bigCard(
                      selected: _match == MatchMode.classic,
                      title: 'Classic',
                      subtitle: 'Home race',
                      icon: Icons.home_rounded,
                      onTap: () => setState(() => _match = MatchMode.classic),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _bigCard(
                      selected: _match == MatchMode.rush,
                      title: 'Rush',
                      subtitle: 'Score · timed',
                      icon: Icons.bolt_rounded,
                      onTap: () => setState(() => _match = MatchMode.rush),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: _bigCard(
                      selected: _match == MatchMode.kill,
                      title: 'Kill Mode',
                      subtitle: 'Cut → phir home',
                      icon: Icons.gps_fixed_rounded,
                      onTap: () => setState(() => _match = MatchMode.kill),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _bigCard(
                      selected: _match == MatchMode.deathMatch,
                      title: 'Death Match',
                      subtitle: 'Target kills',
                      icon: Icons.whatshot_rounded,
                      onTap: () =>
                          setState(() => _match = MatchMode.deathMatch),
                    ),
                  ),
                ],
              ),

              // Death Match kill target
              if (_match.isDeathMatch) ...[
                const SizedBox(height: 12),
                _sectionTitle('KILL TARGET'),
                const SizedBox(height: 8),
                Row(
                  children: [4, 5, 6, 7].map((n) {
                    final sel = _killTarget == n;
                    return Expanded(
                      child: GestureDetector(
                        onTap: () {
                          Sfx.instance.uiClick();
                          setState(() => _killTarget = n);
                        },
                        child: Container(
                          margin: const EdgeInsets.only(right: 6),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            gradient: sel ? AppColors.purplePill : null,
                            color: sel
                                ? null
                                : Colors.black.withValues(alpha: 0.28),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: sel ? AppColors.glow : Colors.white12,
                              width: sel ? 1.6 : 1,
                            ),
                          ),
                          child: Center(
                            child: Text(
                              '$n',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w900,
                                color: sel ? Colors.white : Colors.white60,
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ],

              // Rush match length (only if rush)
              if (_match.isRush) ...[
                const SizedBox(height: 12),
                _sectionTitle('MATCH TIME'),
                const SizedBox(height: 8),
                Row(
                  children: [
                    ...[4, 6].map((m) {
                      final sel = !_customTime && _minutes == m;
                      return Expanded(
                        child: GestureDetector(
                          onTap: () {
                            Sfx.instance.uiClick();
                            setState(() {
                              _customTime = false;
                              _minutes = m;
                            });
                          },
                          child: Container(
                            margin: const EdgeInsets.only(right: 8),
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            decoration: BoxDecoration(
                              gradient: sel ? AppColors.purplePill : null,
                              color: sel
                                  ? null
                                  : Colors.black.withValues(alpha: 0.28),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: sel ? AppColors.glow : Colors.white12,
                                width: sel ? 1.6 : 1,
                              ),
                            ),
                            child: Center(
                              child: Text(
                                '$m min',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w800,
                                  color: sel ? Colors.white : Colors.white60,
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    }),
                    Expanded(
                      child: GestureDetector(
                        onTap: () {
                          Sfx.instance.uiClick();
                          setState(() => _customTime = true);
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            gradient: _customTime ? AppColors.purplePill : null,
                            color: _customTime
                                ? null
                                : Colors.black.withValues(alpha: 0.28),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color:
                                  _customTime ? AppColors.glow : Colors.white12,
                              width: _customTime ? 1.6 : 1,
                            ),
                          ),
                          child: Center(
                            child: Text(
                              'Custom',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w800,
                                color:
                                    _customTime ? Colors.white : Colors.white60,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                if (_customTime) ...[
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.28),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.white12),
                    ),
                    child: Column(
                      children: [
                        Text(
                          '${_customMinutes.round()} min',
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            color: Colors.white,
                          ),
                        ),
                        SliderTheme(
                          data: SliderTheme.of(context).copyWith(
                            activeTrackColor: const Color(0xFFB388FF),
                            inactiveTrackColor: Colors.white24,
                            thumbColor: const Color(0xFF7B3FE4),
                            overlayColor:
                                const Color(0xFF7B3FE4).withValues(alpha: 0.2),
                          ),
                          child: Slider(
                            min: 1,
                            max: 25,
                            divisions: 24,
                            value: _customMinutes.clamp(1, 25),
                            onChanged: (v) =>
                                setState(() => _customMinutes = v),
                          ),
                        ),
                        const Text(
                          '1 — 25 minutes',
                          style: TextStyle(
                            fontSize: 10,
                            color: Colors.white38,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],

              const SizedBox(height: 18),

              // —— PLAY STYLE ——
              _sectionTitle('PLAY STYLE'),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: _bigCard(
                      selected: _mode == GameMode.bots,
                      title: 'With Bots',
                      subtitle: 'AI opponents · Pro',
                      icon: Icons.smart_toy_rounded,
                      onTap: () => setState(() => _mode = GameMode.bots),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _bigCard(
                      selected: _mode == GameMode.passAndPlay,
                      title: 'Pass & Play',
                      subtitle: 'Same device · friends',
                      icon: Icons.groups_rounded,
                      onTap: () =>
                          setState(() => _mode = GameMode.passAndPlay),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 18),

              // —— PLAYERS ——
              _sectionTitle('PLAYERS'),
              const SizedBox(height: 8),
              Row(
                children: [2, 3, 4].map((n) {
                  final sel = _players == n;
                  return Expanded(
                    child: GestureDetector(
                      onTap: () {
                        Sfx.instance.uiClick();
                        setState(() => _players = n);
                      },
                      child: Container(
                        margin: EdgeInsets.only(right: n == 4 ? 0 : 8),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        decoration: BoxDecoration(
                          gradient: sel ? AppColors.purplePill : null,
                          color:
                              sel ? null : Colors.black.withValues(alpha: 0.28),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: sel ? AppColors.glow : Colors.white12,
                            width: sel ? 1.8 : 1,
                          ),
                        ),
                        child: Center(
                          child: Text(
                            '$n',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w900,
                              color: sel ? Colors.white : Colors.white60,
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),

              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    ),
    );
  }

  Widget _sectionTitle(String t) => Text(
        t,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w800,
          letterSpacing: 1.2,
          color: Colors.white.withValues(alpha: 0.55),
        ),
      );

  Widget _bigCard({
    required bool selected,
    required String title,
    required String subtitle,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: () {
        Sfx.instance.uiClick();
        onTap();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding: const EdgeInsets.fromLTRB(12, 14, 12, 14),
        decoration: BoxDecoration(
          gradient: selected ? AppColors.purplePill : null,
          color: selected ? null : Colors.black.withValues(alpha: 0.28),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected ? AppColors.glow : Colors.white12,
            width: selected ? 1.8 : 1,
          ),
          boxShadow: selected
              ? [
                  BoxShadow(
                    color: const Color(0xFF7B3FE4).withValues(alpha: 0.35),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ]
              : null,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon,
                size: 22,
                color: selected ? Colors.white : Colors.white54),
            const SizedBox(height: 8),
            Text(
              title,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w900,
                color: selected ? Colors.white : Colors.white70,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              subtitle,
              style: TextStyle(
                fontSize: 10.5,
                fontWeight: FontWeight.w600,
                color: selected
                    ? Colors.white.withValues(alpha: 0.75)
                    : Colors.white38,
              ),
            ),
          ],
        ),
      ),
    );
  }
}


// =============================================================================
// Lobby party strip — You in the centre (small PNG), friends left/right.
// Slot count follows setup player count. Tapping a friend opens character pick.
// =============================================================================
class _PartyStrip extends StatelessWidget {
  const _PartyStrip({
    required this.myCharacter,
    required this.friendCharacters,
    required this.playerCount,
    required this.passAndPlay,
    required this.onTapMe,
    required this.onTapFriend,
  });

  final String myCharacter;
  final List<String> friendCharacters;
  final int playerCount;
  final bool passAndPlay;
  final VoidCallback onTapMe;
  final ValueChanged<int> onTapFriend;

  /// Left→right seat indices with local player (0) centred.
  static List<int> _order(int n) {
    switch (n) {
      case 2:
        return const [1, 0];
      case 3:
        return const [1, 0, 2];
      case 4:
        return const [1, 2, 0, 3];
      default:
        return List<int>.generate(n, (i) => i);
    }
  }

  @override
  Widget build(BuildContext context) {
    final n = playerCount.clamp(2, 4);
    final order = _order(n);
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        for (final seat in order) ...[
          if (seat != order.first) const SizedBox(width: 14),
          _slot(seat),
        ],
      ],
    );
  }

  Widget _slot(int seat) {
    final isMe = seat == 0;
    final name = isMe
        ? myCharacter
        : (seat - 1 < friendCharacters.length
            ? friendCharacters[seat - 1]
            : 'Rin');
    final size = isMe ? 72.0 : 64.0;
    final label = isMe ? 'You' : (passAndPlay ? 'P$seat' : 'Bot');
    // Host (You) cannot change via PNG — use sidebar CHARACTER.
    // Friends in Pass & Play still can.
    final canPick = !isMe && passAndPlay;

    return GestureDetector(
      onTap: !canPick
          ? null
          : () {
              if (isMe) {
                onTapMe();
              } else {
                onTapFriend(seat - 1);
              }
            },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isMe
                    ? const Color(0xFFFFD27A)
                    : (passAndPlay
                        ? const Color(0xFF7B3FE4)
                        : Colors.white24),
                width: isMe ? 2.4 : 1.8,
              ),
              boxShadow: const [
                BoxShadow(
                  color: Color(0x66000000),
                  blurRadius: 6,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            clipBehavior: Clip.antiAlias,
            child: CharacterPortrait(
              character: name,
              size: size,
              radius: 10,
              borderWidth: 0,
              alignment: const Alignment(0, -0.35),
              fallbackSeed: name.codeUnits.fold(0, (a, b) => a + b),
            ),
          ),
          const SizedBox(height: 5),
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w800,
              color: isMe ? const Color(0xFFFFD27A) : Colors.white70,
            ),
          ),
        ],
      ),
    );
  }
}
