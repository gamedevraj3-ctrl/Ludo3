import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/audio.dart';
import '../widgets/avatar.dart';

/// Profile built only from Free Fire cropped PNGs (bg removed).
/// Assets live under `assets/ui/ff_profile/`.
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({
    super.key,
    required this.name,
    required this.character,
    required this.onEditName,
    required this.onChangeCharacter,
  });

  final String name;
  final String character;
  final VoidCallback onEditName;
  final Future<void> Function() onChangeCharacter;

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late String _name = widget.name;
  late String _character = widget.character;
  int _tab = 0; // 0 gallery, 1 overview, 2 role, 3+ stack items

  static const _asset = 'assets/ui/ff_profile';
  static const _bg = Color(0xFF0A0A0A);

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
  }

  @override
  void didUpdateWidget(covariant ProfileScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.name != widget.name) _name = widget.name;
    if (oldWidget.character != widget.character) {
      _character = widget.character;
    }
  }

  String get _uid {
    final h = _name.codeUnits.fold(0, (a, b) => (a * 31 + b) & 0x7FFFFFFF);
    return (100000000 + (h % 900000000)).toString();
  }

  int get _likes {
    final h = _name.codeUnits.fold(0, (a, b) => (a * 17 + b) & 0x7FFFFFFF);
    return 1000 + (h % 99000);
  }

  int get _level {
    final h =
        _character.codeUnits.fold(0, (a, b) => (a * 13 + b) & 0x7FFFFFFF);
    return 1 + (h % 80);
  }

  int get _coins {
    final h = _name.codeUnits.fold(0, (a, b) => (a * 7 + b) & 0x7FFFFFFF);
    return 10000 + (h % 90000);
  }

  int get _diamonds {
    final h =
        _character.codeUnits.fold(0, (a, b) => (a * 11 + b) & 0x7FFFFFFF);
    return 100 + (h % 4000);
  }

  void _tap() => Sfx.instance.uiClick();

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    return Scaffold(
      backgroundColor: _bg,
      body: SafeArea(
        child: Column(
          children: [
            _topBar(size.width),
            Expanded(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _leftMenu(size.height),
                  // centre stage
                  Expanded(
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        Center(
                          child: CharacterBlend(
                            character: _character,
                            alignment: Alignment.bottomCenter,
                            widthFactor: 0.9,
                            fallbackSeed:
                                _character.codeUnits.fold(0, (a, b) => a + b),
                          ),
                        ),
                      ],
                    ),
                  ),
                  // right cards — ID + ranked same width (reference proportions)
                  SizedBox(
                    width: size.width * 0.42,
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(8, 10, 14, 10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _idCard(),
                          const SizedBox(height: 8),
                          Expanded(
                            child: Image.asset(
                              '$_asset/panel_ranked.png',
                              fit: BoxFit.fitWidth,
                              alignment: Alignment.topCenter,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            _bottomBar(),
          ],
        ),
      ),
    );
  }

  Widget _topBar(double w) {
    return SizedBox(
      height: 52,
      child: Row(
        children: [
          const SizedBox(width: 8),
          Image.asset('$_asset/chip_brand.png', height: 36),
          const SizedBox(width: 10),
          // Currency bar with single live numbers (baked text stripped from PNG)
          SizedBox(
            height: 40,
            width: w * 0.38,
            child: Stack(
              alignment: Alignment.centerLeft,
              children: [
                Image.asset(
                  '$_asset/bar_currency.png',
                  height: 40,
                  width: w * 0.38,
                  fit: BoxFit.fill,
                ),
                Positioned(
                  left: w * 0.055,
                  child: Text(
                    '$_coins',
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      height: 1,
                    ),
                  ),
                ),
                Positioned(
                  left: w * 0.155,
                  child: Text(
                    '$_diamonds +',
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      height: 1,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const Spacer(),
          GestureDetector(
            onTap: () {
              _tap();
              Navigator.pop(context);
            },
            child: Image.asset('$_asset/btn_profile_close.png', height: 40),
          ),
          const SizedBox(width: 8),
        ],
      ),
    );
  }

  Widget _leftMenu(double h) {
    return SizedBox(
      width: 150,
      child: ListView(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 6),
        children: [
          _menuImg(
            '$_asset/tab_gallery_on.png',
            selected: _tab == 0,
            onTap: () => setState(() => _tab = 0),
          ),
          _menuImg(
            '$_asset/tab_overview.png',
            selected: _tab == 1,
            onTap: () => setState(() => _tab = 1),
          ),
          _menuImg(
            '$_asset/tab_role.png',
            selected: _tab == 2,
            onTap: () => setState(() => _tab = 2),
          ),
          // Individual tabs (stack PNG removed)
          _menuImg(
            '$_asset/tab_history.png',
            selected: _tab == 3,
            onTap: () => setState(() => _tab = 3),
          ),
          _menuImg(
            '$_asset/tab_weapon.png',
            selected: _tab == 4,
            onTap: () => setState(() => _tab = 4),
          ),
          _menuImg(
            '$_asset/tab_recordings.png',
            selected: _tab == 5,
            onTap: () => setState(() => _tab = 5),
          ),
          _menuImg(
            '$_asset/tab_honor_score.png',
            selected: _tab == 6,
            onTap: () => setState(() => _tab = 6),
          ),
          _menuImg(
            '$_asset/tab_wishlist.png',
            selected: _tab == 7,
            onTap: () => setState(() => _tab = 7),
          ),
        ],
      ),
    );
  }

  Widget _menuImg(String path, {required bool selected, required VoidCallback onTap}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: GestureDetector(
        onTap: () {
          _tap();
          onTap();
        },
        child: Opacity(
          opacity: selected ? 1 : 0.85,
          child: Image.asset(path, fit: BoxFit.fitWidth),
        ),
      ),
    );
  }

  Widget _idCard() {
    final likes = _likes >= 1000
        ? '${(_likes / 1000).toStringAsFixed(_likes >= 10000 ? 0 : 1)}K'
        : '$_likes';
    return AspectRatio(
      aspectRatio: 667 / 261,
      child: LayoutBuilder(
        builder: (context, c) {
          final w = c.maxWidth;
          final h = c.maxHeight;
          return Stack(
            fit: StackFit.expand,
            children: [
              Image.asset('$_asset/card_id.png', fit: BoxFit.fill),
              // Character in left frame (knife art removed from PNG)
              Positioned(
                left: w * 0.055,
                top: h * 0.26,
                width: w * 0.17,
                height: h * 0.48,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: CharacterPortrait(
                    character: _character,
                    size: w * 0.17,
                    radius: 4,
                    borderWidth: 0,
                    alignment: const Alignment(0, -0.3),
                    fallbackSeed:
                        _character.codeUnits.fold(0, (a, b) => a + b),
                  ),
                ),
              ),
              // Player name (same slot as old FREE FIRE INDIA)
              Positioned(
                left: w * 0.28,
                top: h * 0.26,
                right: w * 0.22,
                child: Text(
                  _name.toUpperCase(),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: h * 0.13,
                    fontWeight: FontWeight.w900,
                    color: const Color(0xFF1A1A1A),
                    height: 1.05,
                    letterSpacing: 0.3,
                  ),
                ),
              ),
              // Subtitle
              Positioned(
                left: w * 0.28,
                top: h * 0.42,
                child: Text(
                  'English',
                  style: TextStyle(
                    fontSize: h * 0.075,
                    fontWeight: FontWeight.w600,
                    color: const Color(0xFF666666),
                    height: 1,
                  ),
                ),
              ),
              // Level number only (Lv. stays on art)
              Positioned(
                left: w * 0.105,
                bottom: h * 0.07,
                child: Text(
                  '$_level',
                  style: TextStyle(
                    fontSize: h * 0.095,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    height: 1,
                  ),
                ),
              ),
              // Likes
              Positioned(
                right: w * 0.07,
                top: h * 0.52,
                child: Text(
                  likes,
                  style: TextStyle(
                    fontSize: h * 0.095,
                    fontWeight: FontWeight.w800,
                    color: const Color(0xFF1A1A1A),
                    height: 1,
                  ),
                ),
              ),
              // UID
              Positioned(
                right: w * 0.06,
                bottom: h * 0.07,
                child: Text(
                  'UID: $_uid',
                  style: TextStyle(
                    fontSize: h * 0.07,
                    fontWeight: FontWeight.w700,
                    color: Colors.white70,
                    height: 1,
                  ),
                ),
              ),
              // Settings gear hit
              Positioned(
                right: 0,
                top: 0,
                width: w * 0.12,
                height: h * 0.22,
                child: GestureDetector(
                  onTap: () {
                    _tap();
                    widget.onEditName();
                  },
                  behavior: HitTestBehavior.opaque,
                  child: const SizedBox.expand(),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _bottomBar() {
    return SizedBox(
      height: 48,
      child: Row(
        children: [
          const SizedBox(width: 10),
          GestureDetector(
            onTap: _tap,
            child: Image.asset('$_asset/btn_chat.png', height: 36),
          ),
          const Spacer(),
        ],
      ),
    );
  }
}
