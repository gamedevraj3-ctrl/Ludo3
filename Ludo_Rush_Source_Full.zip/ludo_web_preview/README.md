# Ludo Rush — screenshot-based landscape lobby

This Flutter source contains the updated landscape lobby and character picker. The lobby now uses the uploaded Free Fire-style screenshot as its background, with the original 3D character and pet removed. The screenshot crops supplied in the ZIP are aligned to their exact source positions and layered over the screenshot; the top-right settings panel is not replaced. The separate avatar image is not added, as requested.

The supplied profile/player banner is used in the top-left. Its edge-connected black background was removed while preserving the banner artwork. The character-selection screen uses compact three-column cards, vertically scrollable categories, the existing game's 2D character preview, the earlier cropped profile and currency bars, and the supplied Vault / Character / close header.

The profile screen's missing PNG assets are fixed by explicitly registering `assets/ui/ff_profile/`. The user-supplied screenshots and edited lobby background are registered from `assets/ui/user_lobby_screenshots/`.

## Run the lobby in Chrome

```bash
flutter pub get
flutter run -d chrome -t lib/main_lobby.dart
```

Use the screenshot controls to open the profile, store, character picker and setup flows.

## Build the web app

```bash
flutter build web --release -t lib/main_lobby.dart --base-href /
```

The deployable static web output is written to `build/web/`. Upload the contents of that directory to a static web host.
