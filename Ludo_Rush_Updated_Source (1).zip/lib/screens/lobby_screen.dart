import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/audio.dart';
import '../core/theme.dart';
import '../core/game_theme.dart';
import '../widgets/avatar.dart';
import '../game/game_speed.dart';
import '../game/characters.dart' as roster;
import '../game/models.dart';
import 'characters_screen.dart';
import 'profile_screen.dart';
import 'store_screen.dart';
import 'game_screen.dart';

/// ---------------------------------------------------------------------------
/// Part 3 rebuild — "Free Fire hub" lobby.
///
/// This replaces the earlier cyberpunk-cityscape lobby with a pixel-matched
/// recreation of the user's reference screenshot (a Free-Fire-style military
/// camp hub): top-left profile + rank crest, top-centre currency pill,
/// top-right icon trio, purple SUBSCRIBE promo banner, a vertical 6-item
/// sidebar menu, a full hero character overlay standing in the scene, and a
/// bottom-right mode-tag + START combo with a bottom-left chat icon.
///
/// All positions below are driven from the same percentage-based layout that
/// was measured directly off the reference image, so the composition holds
/// at any screen size via `LayoutBuilder` + percentage `Positioned` offsets
/// instead of fixed pixels.
/// ---------------------------------------------------------------------------
class LobbyScreen extends StatefulWidget {
  const LobbyScreen({super.key});

  @override
  State<LobbyScreen> createState() => _LobbyScreenState();
}

class _LobbyScreenState extends State<LobbyScreen>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  String _name = 'You';
  MatchMode _matchMode = MatchMode.rush;
  GameMode _gameMode = GameMode.bots;
  bool _sound = true;

  /// The character the player is wearing. Persisted, so it survives restarts.
  String _character = roster.Characters.byName('Rin').name;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _lockLandscape();
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  void _lockLandscape() {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _lockLandscape();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _name = p.getString('name') ?? 'You';
      _sound = p.getBool('sound_on') ?? true;
      _character = roster.Characters.byName(
        p.getString('character') ?? 'Rin',
      ).name;
      final mi = p.getInt('match_mode');
      if (mi != null && mi >= 0 && mi < MatchMode.values.length) {
        _matchMode = MatchMode.values[mi];
      }
      _players = (p.getInt('last_players') ?? 4).clamp(2, 4);
      _botLevel = (p.getInt('last_level') ?? 3).clamp(1, 3);
      final si = p.getInt('speed');
      if (si != null && si >= 0 && si < SpeedPreset.values.length) {
        _speed = SpeedPreset.values[si];
      }
    });
  }

  Future<void> _saveName(String v) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('name', v);
    if (!mounted) return;
    setState(() => _name = v);
  }

  Future<void> _openCharacters() async {
    Sfx.instance.uiClick();
    final picked = await Navigator.of(context).push<String>(
      MaterialPageRoute(builder: (_) => CharactersScreen(selected: _character)),
    );
    _lockLandscape();
    if (picked != null && mounted) setState(() => _character = picked);
  }

  void _openProfile() {
    Sfx.instance.uiClick();
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ProfileScreen(
          name: _name,
          character: _character,
          onEditName: _editName,
          onChangeCharacter: _openCharacters,
        ),
      ),
    ).then((_) async {
      // refresh name/character after return
      final p = await SharedPreferences.getInstance();
      if (!mounted) return;
      setState(() {
        _name = p.getString('name') ?? _name;
        _character = roster.Characters.byName(
          p.getString('character') ?? _character,
        ).name;
      });
    });
  }

  void _openStore() {

    Sfx.instance.uiClick();
    Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => const StoreScreen()))
        .then((_) => _lockLandscape());
  }

  void _openEmptySheet(String title, String note) {
    Sfx.instance.uiClick();
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.panelDark,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => _EmptySheet(title: title, note: note),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GameColors.bgVoid,
      body: Stack(
        children: [
          // 1) Free-Fire-style military camp backdrop, full-bleed.
          Positioned.fill(
            child: Image.asset(
              GameArt.ffLobbyBackground,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const DecoratedBox(
                decoration: BoxDecoration(gradient: GameGradients.screen),
              ),
            ),
          ),
          // 2) very light scrim so the daylight scene stays bright (like the
          // reference) while the UI chrome is still readable.
          Positioned.fill(
            child: IgnorePointer(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withValues(alpha: 0.22),
                      Colors.black.withValues(alpha: 0.02),
                      Colors.black.withValues(alpha: 0.10),
                      Colors.black.withValues(alpha: 0.38),
                    ],
                    stops: const [0.0, 0.22, 0.6, 1.0],
                  ),
                ),
              ),
            ),
          ),
          SafeArea(
            child: LayoutBuilder(
              builder: (context, cts) {
                final w = cts.maxWidth;
                final h = cts.maxHeight;
                return Stack(
                  clipBehavior: Clip.none,
                  children: [
                    // ---- hero character: centred, chest-up, big ----
                    Positioned(
                      left: w * 0.345,
                      top: h * 0.085,
                      width: w * 0.30,
                      height: h * 0.92,
                      child: GestureDetector(
                        onTap: _openCharacters,
                        behavior: HitTestBehavior.translucent,
                        child: CharacterBlend(
                          character: _character,
                          alignment: Alignment.bottomCenter,
                          widthFactor: 0.82,
                          fallbackSeed: _character.codeUnits.fold(
                            0,
                            (a, b) => a + b,
                          ),
                        ),
                      ),
                    ),

                    // ---- top-left: profile badge + name/level + rank tab --
                    Positioned(
                      left: w * 0.018,
                      top: h * 0.02,
                      child: _ProfileBlock(
                        name: _name,
                        character: _character,
                        onTapAvatar: _openCharacters,
                        onTapName: _editName,
                        onTapRank: () => _openEmptySheet(
                          'RANK',
                          'Ranked matches aren\'t available in this mode yet.',
                        ),
                      ),
                    ),

                    // ---- top-centre: currency pill ----
                    Positioned(
                      left: w * 0.30,
                      top: h * 0.025,
                      child: const _CurrencyBar(gold: '1080', gems: '10'),
                    ),

                    // ---- top-right: camera / settings / signal ----
                    Positioned(
                      right: w * 0.01,
                      top: h * 0.025,
                      child: _TopRightIcons(
                        onCamera: () => _openEmptySheet(
                          'SCREENSHOT',
                          'Screen capture isn\'t wired up in this build.',
                        ),
                        onSettings: _openSettings,
                        sound: _sound,
                      ),
                    ),

                    // ---- left sidebar: 6-item vertical menu ----
                    Positioned(
                      left: w * 0.018,
                      top: h * 0.18,
                      width: w * 0.175,
                      child: _Sidebar(
                        onStore: _openStore,
                        onLuckRoyale: () => _openEmptySheet(
                          'LUCK ROYALE',
                          'No crates available right now.',
                        ),
                        onCharacter: _openCharacters,
                        onVault: () => _openEmptySheet(
                          'VAULT',
                          'No items stored yet.',
                        ),
                        onCollection: () => _openEmptySheet(
                          'COLLECTION',
                          'No collection items yet.',
                        ),
                        onWeapon: () => _openEmptySheet(
                          'WEAPON',
                          'No weapons in this mode.',
                        ),
                      ),
                    ),

                    // ---- Made by Lucifer credit ----
                    Positioned(
                      right: w * 0.02,
                      bottom: h * 0.03,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 5,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.45),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: const Color(0xFFFFC93C).withValues(alpha: 0.55),
                          ),
                        ),
                        child: const Text(
                          'Made by Lucifer',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            color: Color(0xFFFFE082),
                            letterSpacing: 0.6,
                            shadows: [
                              Shadow(color: Colors.black87, blurRadius: 4),
                            ],
                          ),
                        ),
                      ),
                    ),

                    // ---- bottom-left: chat icon ----
                    Positioned(
                      left: w * 0.018,
                      bottom: h * 0.04,
                      child: _ChatIcon(
                        onTap: () => _openEmptySheet(
                          'CHAT',
                          'Chat isn\'t available offline.',
                        ),
                      ),
                    ),

                    // ---- bottom-right: mode tag + START ----
                    Positioned(
                      right: w * 0.012,
                      bottom: h * 0.035,
                      child: _ModeAndStart(
                        matchMode: _matchMode,
                        gameMode: _gameMode,
                        onTapMode: _openSetup,
                        onStart: _startFromLobby,
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // ------------------------------------------------------------------ flows

  void _openSettings() {
    Sfx.instance.uiClick();
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.panelDark,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => _LobbySettingsSheet(
        onEditName: () {
          Navigator.pop(context);
          _editName();
        },
      ),
    );
  }

  void _editName() {
    Sfx.instance.uiClick();
    final ctrl = TextEditingController(text: _name);
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.panelDark,
        title: const Text('Your Name', style: AppText.h2),
        content: TextField(
          controller: ctrl,
          maxLength: 14,
          style: AppText.body,
          decoration: const InputDecoration(hintText: 'Enter name'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              final v = ctrl.text.trim();
              if (v.isNotEmpty) _saveName(v);
              Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  // Setup prefs held on the lobby so START uses them.
  int _players = 4;
  int _matchSeconds = 4 * 60;
  int _turnSeconds = 15;
  int _botLevel = 3;
  SpeedPreset _speed = SpeedPreset.normal;

  void _openSetup(GameMode mode) {
    Sfx.instance.uiClick();
    setState(() => _gameMode = mode);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.panelDark,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => _SetupSheet(
        mode: mode,
        matchMode: _matchMode,
        myName: _name,
        onApply: (cfg) {
          setState(() {
            _gameMode = cfg.mode;
            _matchMode = cfg.matchMode;
            _players = cfg.playerCount;
            _matchSeconds = cfg.matchSeconds;
            _turnSeconds = cfg.turnSeconds;
            _botLevel = cfg.botLevel;
            _speed = cfg.speed;
          });
        },
      ),
    );
  }

  void _startFromLobby() {
    Sfx.instance.uiClick();
    _start(
      GameConfig(
        mode: _gameMode,
        matchMode: _matchMode,
        playerCount: _players,
        matchSeconds: _matchSeconds,
        turnSeconds: _turnSeconds,
        myName: _name,
        botLevel: _botLevel,
        speed: _speed,
      ),
    );
  }

  void _start(GameConfig cfg) {
    Navigator.of(context)
        .push(
          MaterialPageRoute(
            builder: (_) => GameScreen(
              config: GameConfig(
                mode: cfg.mode,
                matchMode: cfg.matchMode,
                playerCount: cfg.playerCount,
                matchSeconds: cfg.matchSeconds,
                turnSeconds: cfg.turnSeconds,
                myName: _name,
                myCharacter: _character,
                botLevel: cfg.botLevel,
                speed: cfg.speed,
              ),
            ),
          ),
        )
        .then((_) {
          // The match locks portrait while it's playing; re-assert landscape
          // now that we're back so the lobby never gets stuck in portrait.
          _lockLandscape();
          _load();
        });
  }
}

// =============================================================================
// Top-left profile block: avatar badge + name/level + winged rank crest tab.
// =============================================================================
class _ProfileBlock extends StatelessWidget {
  const _ProfileBlock({
    required this.name,
    required this.character,
    required this.onTapAvatar,
    required this.onTapName,
    required this.onTapRank,
  });

  final String name;
  final String character;
  final VoidCallback onTapAvatar;
  final VoidCallback onTapName;
  final VoidCallback onTapRank;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            GestureDetector(
              onTap: onTapAvatar,
              child: Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF9B6BFF), Color(0xFF4A1A9E)],
                  ),
                  border: Border.all(color: Colors.white, width: 2),
                  boxShadow: GameShadows.raised,
                ),
                child: Center(
                  child: Text(
                    character.isNotEmpty ? character[0].toUpperCase() : 'A',
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      shadows: [
                        Shadow(color: Colors.black54, blurRadius: 3),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 7),
            GestureDetector(
              onTap: onTapName,
              child: Container(
                constraints: const BoxConstraints(maxWidth: 110),
                padding: const EdgeInsets.symmetric(
                  horizontal: 8,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: Colors.black.withValues(alpha: 0.42),
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        shadows: [
                          Shadow(color: Colors.black87, blurRadius: 3),
                        ],
                      ),
                    ),
                    const Text(
                      'Lv.1',
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFFE0B34A),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

// =============================================================================
// Top-centre currency pill: gold coins + purple gems on a slanted dark bar.
// =============================================================================
class _CurrencyBar extends StatelessWidget {
  const _CurrencyBar({required this.gold, required this.gems});

  final String gold;
  final String gems;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 30,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: const Color(0xFF1C2433).withValues(alpha: 0.72),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white24, width: 1),
        boxShadow: GameShadows.raised,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _coinIcon(),
          const SizedBox(width: 6),
          Text(
            gold,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w900,
              color: Colors.white,
            ),
          ),
          Container(
            width: 1,
            height: 16,
            margin: const EdgeInsets.symmetric(horizontal: 12),
            color: Colors.white24,
          ),
          _gemIcon(),
          const SizedBox(width: 6),
          Text(
            gems,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w900,
              color: Colors.white,
            ),
          ),
          const SizedBox(width: 6),
          Container(
            width: 16,
            height: 16,
            decoration: const BoxDecoration(
              color: Color(0xFF3EBE52),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.add, size: 12, color: Colors.white),
          ),
        ],
      ),
    );
  }

  Widget _coinIcon() => Container(
    width: 16,
    height: 16,
    decoration: const BoxDecoration(
      color: GameColors.coin,
      shape: BoxShape.circle,
    ),
    child: const Center(
      child: Text(
        '\$',
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w900,
          color: Color(0xFF8A5A00),
        ),
      ),
    ),
  );

  Widget _gemIcon() => const Icon(
    Icons.diamond,
    size: 15,
    color: Color(0xFF9B6BD8),
  );
}

// =============================================================================
// Top-right icon trio: camera / settings / signal+battery.
// =============================================================================
class _TopRightIcons extends StatelessWidget {
  const _TopRightIcons({
    required this.onCamera,
    required this.onSettings,
    required this.sound,
  });

  final VoidCallback onCamera;
  final VoidCallback onSettings;
  final bool sound;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _dot(icon: Icons.camera_alt_rounded, onTap: onCamera),
        const SizedBox(width: 8),
        _dot(icon: Icons.settings_rounded, onTap: onSettings),
        const SizedBox(width: 8),
        Container(
          width: 30,
          height: 30,
          decoration: BoxDecoration(
            color: Colors.black.withValues(alpha: 0.38),
            shape: BoxShape.circle,
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              const Icon(Icons.wifi_rounded, size: 15, color: Colors.white),
              Positioned(
                right: 4,
                top: 5,
                child: Container(
                  width: 6,
                  height: 6,
                  decoration: const BoxDecoration(
                    color: Color(0xFF3EBE52),
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _dot({required IconData icon, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 30,
        height: 30,
        decoration: BoxDecoration(
          color: Colors.black.withValues(alpha: 0.38),
          shape: BoxShape.circle,
        ),
        child: Icon(icon, size: 15, color: Colors.white),
      ),
    );
  }
}

// =============================================================================
// Purple "FFI GAME DEV RAJ" promo banner + red SUBSCRIBE pill.
// =============================================================================
class _PromoBanner extends StatelessWidget {
  const _PromoBanner();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF5E1A63), Color(0xFF3A1042)],
        ),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: const Color(0xFFC79CF0).withValues(alpha: 0.55),
          width: 1,
        ),
        boxShadow: GameShadows.raised,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text(
            'FFI',
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w900,
              color: Colors.white,
              letterSpacing: 0.5,
              shadows: [Shadow(color: Colors.black54, blurRadius: 3)],
            ),
          ),
          const Text(
            'GAME DEV RAJ',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w900,
              color: Colors.white,
              letterSpacing: 0.3,
              shadows: [Shadow(color: Colors.black54, blurRadius: 3)],
            ),
          ),
          const SizedBox(height: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: const Color(0xFFE0302C),
              borderRadius: BorderRadius.circular(5),
              boxShadow: GameShadows.button,
            ),
            child: const Text(
              'SUBSCRIBE',
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w900,
                color: Colors.white,
                letterSpacing: 0.4,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// =============================================================================
// Left vertical sidebar: Store / Luck Royale / Character / Vault / Collection
// / Weapon — translucent dark pills, gold highlight on Store's icon.
// =============================================================================
class _Sidebar extends StatelessWidget {
  const _Sidebar({
    required this.onStore,
    required this.onLuckRoyale,
    required this.onCharacter,
    required this.onVault,
    required this.onCollection,
    required this.onWeapon,
  });

  final VoidCallback onStore;
  final VoidCallback onLuckRoyale;
  final VoidCallback onCharacter;
  final VoidCallback onVault;
  final VoidCallback onCollection;
  final VoidCallback onWeapon;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _item(
          icon: Icons.shopping_cart_rounded,
          label: 'Store',
          iconColor: const Color(0xFFFFC93C),
          glow: true,
          onTap: onStore,
        ),
        const SizedBox(height: 6),
        _item(
          icon: Icons.casino_rounded,
          label: 'LUCK ROYALE',
          iconColor: const Color(0xFFFFC93C),
          onTap: onLuckRoyale,
        ),
        const SizedBox(height: 6),
        _item(
          icon: Icons.sports_martial_arts_rounded,
          label: 'CHARACTER',
          iconColor: Colors.white,
          onTap: onCharacter,
        ),
        const SizedBox(height: 6),
        _item(
          icon: Icons.backpack_rounded,
          label: 'VAULT',
          iconColor: Colors.white,
          onTap: onVault,
        ),
        const SizedBox(height: 6),
        _item(
          icon: Icons.emoji_events_rounded,
          label: 'COLLECTION',
          iconColor: Colors.white,
          onTap: onCollection,
        ),
        const SizedBox(height: 6),
        _item(
          icon: Icons.gps_fixed_rounded,
          label: 'WEAPON',
          iconColor: Colors.white,
          onTap: onWeapon,
        ),
      ],
    );
  }

  Widget _item({
    required IconData icon,
    required String label,
    required Color iconColor,
    required VoidCallback onTap,
    bool glow = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(
          color: Colors.black.withValues(alpha: 0.46),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withValues(alpha: 0.12)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: 15,
              color: iconColor,
              shadows: glow
                  ? [
                      Shadow(
                        color: iconColor.withValues(alpha: 0.8),
                        blurRadius: 6,
                      ),
                    ]
                  : null,
            ),
            const SizedBox(width: 6),
            Flexible(
              child: FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(
                  label,
                  maxLines: 1,
                  softWrap: false,
                  style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    letterSpacing: 0.4,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// =============================================================================
// Bottom-left chat icon.
// =============================================================================
class _ChatIcon extends StatelessWidget {
  const _ChatIcon({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 42,
        height: 36,
        decoration: BoxDecoration(
          color: Colors.black.withValues(alpha: 0.5),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.white.withValues(alpha: 0.14)),
        ),
        child: const Icon(
          Icons.chat_bubble_rounded,
          size: 16,
          color: Colors.white70,
        ),
      ),
    );
  }
}

// =============================================================================
// Bottom-right mode tag + big gold START button.
// =============================================================================
class _ModeAndStart extends StatelessWidget {
  const _ModeAndStart({
    required this.matchMode,
    required this.gameMode,
    required this.onTapMode,
    required this.onStart,
  });

  final MatchMode matchMode;
  final GameMode gameMode;
  final void Function(GameMode) onTapMode;
  final VoidCallback onStart;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        GestureDetector(
          onTap: () => onTapMode(gameMode),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
            decoration: BoxDecoration(
              color: const Color(0xFF1A1D22).withValues(alpha: 0.88),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: const Color(0xFFE0B34A).withValues(alpha: 0.6),
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      matchMode.isRush ? 'Rush Match' : 'Classic Squad',
                      style: const TextStyle(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFFFFD27A),
                        letterSpacing: 0.3,
                      ),
                    ),
                    Text(
                      gameMode == GameMode.bots
                          ? 'VS Bots · BERMUDA'
                          : 'Pass & Play · BERMUDA',
                      style: const TextStyle(
                        fontSize: 8.5,
                        fontWeight: FontWeight.w700,
                        color: Colors.white60,
                      ),
                    ),
                  ],
                ),
                const SizedBox(width: 6),
                const Icon(
                  Icons.person_rounded,
                  size: 16,
                  color: Colors.white70,
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        GestureDetector(
          onTap: onStart,
          child: Container(
            width: 150,
            height: 50,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFFFDBB00), Color(0xFFED7800)],
              ),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.white54, width: 1.4),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFF8A3D).withValues(alpha: 0.6),
                  blurRadius: 16,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: const Center(
              child: Text(
                'START',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2,
                  color: Colors.white,
                  shadows: [
                    Shadow(color: Colors.black45, blurRadius: 4, offset: Offset(0, 2)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

// =============================================================================
// Generic "coming soon" bottom sheet used by every sidebar/HUD placeholder.
// =============================================================================
class _EmptySheet extends StatelessWidget {
  const _EmptySheet({required this.title, required this.note});

  final String title;
  final String note;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 46,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
            const SizedBox(height: 16),
            Text(title, style: AppText.h2),
            const SizedBox(height: 8),
            Text(note, style: AppText.small, textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}

/// Lobby settings sheet: sound effects toggle and a name shortcut.
class _LobbySettingsSheet extends StatefulWidget {
  const _LobbySettingsSheet({required this.onEditName});

  final VoidCallback onEditName;

  @override
  State<_LobbySettingsSheet> createState() => _LobbySettingsSheetState();
}

class _LobbySettingsSheetState extends State<_LobbySettingsSheet> {
  @override
  Widget build(BuildContext context) {
    final on = Sfx.instance.enabled;
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 46,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ),
            const SizedBox(height: 14),
            const Text('Settings', style: AppText.h2),
            const SizedBox(height: 12),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              value: on,
              activeThumbColor: AppColors.online,
              secondary: Icon(
                on ? Icons.volume_up_rounded : Icons.volume_off_rounded,
                color: on ? AppColors.online : Colors.white38,
              ),
              title: const Text('Sound effects', style: AppText.body),
              subtitle: Text(
                on ? 'Dice, hops, cuts & fanfare' : 'Muted',
                style: AppText.small,
              ),
              onChanged: (v) async {
                await Sfx.instance.setEnabled(v);
                if (!mounted) return;
                setState(() {});
                if (v) Sfx.instance.uiClick();
              },
            ),
            const Divider(color: Colors.white12, height: 1),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.badge_outlined, color: Colors.white70),
              title: const Text('Edit name', style: AppText.body),
              trailing: const Icon(Icons.chevron_right, color: Colors.white38),
              onTap: widget.onEditName,
            ),
          ],
        ),
      ),
    );
  }
}

/// Bottom sheet to pick rule set / players / duration / difficulty.
class _SetupSheet extends StatefulWidget {
  const _SetupSheet({
    required this.mode,
    required this.matchMode,
    required this.myName,
    required this.onApply,
  });

  final GameMode mode;
  final MatchMode matchMode;
  final String myName;
  final void Function(GameConfig) onApply;

  @override
  State<_SetupSheet> createState() => _SetupSheetState();
}

class _SetupSheetState extends State<_SetupSheet> {
  late MatchMode _match;
  int _players = 4;
  int _minutes = 4;
  bool _customTime = false;
  double _customMinutes = 8;
  int _turnSec = 15;
  int _level = 3;
  SpeedPreset _speed = SpeedPreset.normal;

  @override
  void initState() {
    super.initState();
    _match = widget.matchMode;
    _loadPrefs();
  }

  Future<void> _loadPrefs() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    final i = p.getInt('speed');
    setState(() {
      if (i != null && i >= 0 && i < SpeedPreset.values.length) {
        _speed = SpeedPreset.values[i];
      }
      _players = (p.getInt('last_players') ?? 4).clamp(2, 4);
      _level = (p.getInt('last_level') ?? 3).clamp(1, 3);
    });
  }

  Future<void> _saveSpeed(SpeedPreset s) async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('speed', s.index);
  }

  Future<void> _remember() async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('last_players', _players);
    await p.setInt('last_level', _level);
    await p.setInt('match_mode', _match.index);
  }

  int get _finalMinutes => _customTime ? _customMinutes.round() : _minutes;

  @override
  Widget build(BuildContext context) {
    final isBots = widget.mode == GameMode.bots;
    final rush = _match.isRush;

    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 20),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 46,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Icon(
                    isBots ? Icons.smart_toy : Icons.groups,
                    size: 20,
                    color: AppColors.glow,
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Text(
                      isBots ? 'Play with Bots' : 'Pass & Play with Friends',
                      style: AppText.h2,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // ------------------------------------------------- rule set
              _labelRow('Rule set'),
              const SizedBox(height: 8),
              Row(
                children: MatchMode.values.map((m) {
                  final sel = _match == m;
                  return Expanded(
                    child: GestureDetector(
                      onTap: () {
                        Sfx.instance.uiClick();
                        setState(() => _match = m);
                      },
                      child: Container(
                        margin: const EdgeInsets.only(right: 8),
                        padding: const EdgeInsets.symmetric(vertical: 11),
                        decoration: BoxDecoration(
                          gradient: sel ? AppColors.purplePill : null,
                          color: sel
                              ? null
                              : Colors.black.withValues(alpha: 0.26),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: sel ? AppColors.glow : Colors.white12,
                            width: sel ? 1.6 : 1,
                          ),
                        ),
                        child: Center(
                          child: Text(
                            m.label,
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w800,
                              color: sel ? Colors.white : Colors.white60,
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 6),
              Text(_match.tagline, style: AppText.small),
              const SizedBox(height: 14),

              // -------------------------------------------------- players
              _chips(
                'Players',
                const [2, 3, 4],
                _players,
                (v) => setState(() => _players = v),
                suffix: '',
              ),
              const SizedBox(height: 14),

              // ----------------------------------------------- match time
              if (rush) ...[
                Row(
                  children: [
                    Expanded(child: _labelRow('Match time')),
                    GestureDetector(
                      onTap: () {
                        Sfx.instance.uiClick();
                        setState(() => _customTime = !_customTime);
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 5,
                        ),
                        decoration: BoxDecoration(
                          color: _customTime
                              ? AppColors.accentDeep
                              : Colors.black.withValues(alpha: 0.30),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: _customTime
                                ? AppColors.glow
                                : Colors.white24,
                          ),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              _customTime
                                  ? Icons.tune_rounded
                                  : Icons.tune_outlined,
                              size: 13,
                              color: _customTime
                                  ? Colors.white
                                  : Colors.white54,
                            ),
                            const SizedBox(width: 5),
                            Text(
                              'Custom',
                              style: TextStyle(
                                fontSize: 10.5,
                                fontWeight: FontWeight.w800,
                                color: _customTime
                                    ? Colors.white
                                    : Colors.white54,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                if (!_customTime)
                  Row(
                    children: const [4, 6].map((v) {
                      final sel = v == _minutes;
                      return Expanded(
                        child: GestureDetector(
                          onTap: () {
                            Sfx.instance.uiClick();
                            setState(() => _minutes = v);
                          },
                          child: Container(
                            margin: const EdgeInsets.only(right: 8),
                            padding: const EdgeInsets.symmetric(vertical: 11),
                            decoration: BoxDecoration(
                              gradient: sel ? AppColors.purplePill : null,
                              color: sel
                                  ? null
                                  : Colors.black.withValues(alpha: 0.26),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: sel ? AppColors.glow : Colors.white12,
                                width: sel ? 1.6 : 1,
                              ),
                            ),
                            child: Center(
                              child: Text(
                                '$v min',
                                style: TextStyle(
                                  fontSize: 13.5,
                                  fontWeight: FontWeight.w800,
                                  color: sel ? Colors.white : Colors.white60,
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  )
                else
                  _customTimeSlider(),
                const SizedBox(height: 14),
              ],

              // ----------------------------------------------- turn timer
              _chips(
                'Turn timer',
                const [10, 15, 20],
                _turnSec,
                (v) => setState(() => _turnSec = v),
                suffix: ' sec',
              ),
              const SizedBox(height: 14),

              // ---------------------------------------------- game speed
              _labelRow('Game speed'),
              const SizedBox(height: 8),
              Row(
                children: SpeedPreset.values.map((sp) {
                  final sel = _speed == sp;
                  return Expanded(
                    child: GestureDetector(
                      onTap: () {
                        Sfx.instance.uiClick();
                        setState(() => _speed = sp);
                        _saveSpeed(sp);
                      },
                      child: Container(
                        margin: const EdgeInsets.only(right: 8),
                        padding: const EdgeInsets.symmetric(vertical: 11),
                        decoration: BoxDecoration(
                          gradient: sel ? AppColors.purplePill : null,
                          color: sel
                              ? null
                              : Colors.black.withValues(alpha: 0.26),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: sel ? AppColors.glow : Colors.white12,
                            width: sel ? 1.6 : 1,
                          ),
                        ),
                        child: Center(
                          child: Text(
                            sp.label,
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w800,
                              color: sel ? Colors.white : Colors.white60,
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 6),
              Text(_speed.hint, style: AppText.small),

              // ------------------------------------------ bot difficulty
              if (isBots) ...[
                const SizedBox(height: 14),
                _labelRow('Bot skill'),
                const SizedBox(height: 8),
                Row(
                  children: List.generate(3, (i) {
                    const names = ['Casual', 'Sharp', 'Pro'];
                    final lv = i + 1;
                    final sel = _level == lv;
                    return Expanded(
                      child: GestureDetector(
                        onTap: () {
                          Sfx.instance.uiClick();
                          setState(() => _level = lv);
                        },
                        child: Container(
                          margin: const EdgeInsets.only(right: 8),
                          padding: const EdgeInsets.symmetric(vertical: 11),
                          decoration: BoxDecoration(
                            gradient: sel ? AppColors.purplePill : null,
                            color: sel
                                ? null
                                : Colors.black.withValues(alpha: 0.26),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: sel ? AppColors.glow : Colors.white12,
                              width: sel ? 1.6 : 1,
                            ),
                          ),
                          child: Center(
                            child: Text(
                              names[i],
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w800,
                                color: sel ? Colors.white : Colors.white60,
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  }),
                ),
              ],

              const SizedBox(height: 20),
              SizedBox(
                height: 52,
                child: FilledButton(
                  style: FilledButton.styleFrom(
                    backgroundColor: AppColors.accentDeep,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  onPressed: () {
                    Sfx.instance.uiClick();
                    _remember();
                    widget.onApply(
                      GameConfig(
                        mode: widget.mode,
                        matchMode: _match,
                        playerCount: _players,
                        matchSeconds: _finalMinutes * 60,
                        turnSeconds: _turnSec,
                        myName: widget.myName,
                        botLevel: _level,
                        speed: _speed,
                      ),
                    );
                    Navigator.pop(context);
                  },
                  child: Text(
                    rush
                        ? 'SAVE $_finalMinutes-MIN RUSH'
                        : 'SAVE CLASSIC SETUP',
                    style: const TextStyle(
                      fontSize: 15.5,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.0,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Free-form match length picker (1 - 30 minutes).
  Widget _customTimeSlider() {
    final m = _customMinutes.round();
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 6),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.28),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.glow.withValues(alpha: 0.45)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.timer_outlined, size: 15, color: AppColors.gold),
              const SizedBox(width: 7),
              Text(
                '$m minute${m == 1 ? '' : 's'}',
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                  color: Colors.white,
                ),
              ),
              const Spacer(),
              Text(
                m <= 3
                    ? 'Blitz'
                    : m <= 6
                    ? 'Quick'
                    : m <= 12
                    ? 'Standard'
                    : 'Marathon',
                style: const TextStyle(
                  fontSize: 10.5,
                  fontWeight: FontWeight.w800,
                  color: AppColors.gold,
                ),
              ),
            ],
          ),
          SliderTheme(
            data: SliderThemeData(
              trackHeight: 5,
              activeTrackColor: AppColors.glow,
              inactiveTrackColor: Colors.white12,
              thumbColor: Colors.white,
              overlayColor: AppColors.glow.withValues(alpha: 0.18),
              valueIndicatorColor: AppColors.accentDeep,
            ),
            child: Slider(
              value: _customMinutes,
              min: 1,
              max: 30,
              divisions: 29,
              label: '$m min',
              onChanged: (v) => setState(() => _customMinutes = v),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 2, bottom: 4),
            child: Text(
              'Drag to set any length from 1 to 30 minutes',
              style: AppText.small,
            ),
          ),
        ],
      ),
    );
  }

  Widget _labelRow(String text) => Text(text, style: AppText.small);

  Widget _chips(
    String label,
    List<int> values,
    int selected,
    ValueChanged<int> onSel, {
    required String suffix,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _labelRow(label),
        const SizedBox(height: 8),
        Row(
          children: values.map((v) {
            final sel = v == selected;
            return Expanded(
              child: GestureDetector(
                onTap: () {
                  Sfx.instance.uiClick();
                  onSel(v);
                },
                child: Container(
                  margin: const EdgeInsets.only(right: 8),
                  padding: const EdgeInsets.symmetric(vertical: 11),
                  decoration: BoxDecoration(
                    gradient: sel ? AppColors.purplePill : null,
                    color: sel ? null : Colors.black.withValues(alpha: 0.26),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: sel ? AppColors.glow : Colors.white12,
                      width: sel ? 1.6 : 1,
                    ),
                  ),
                  child: Center(
                    child: Text(
                      '$v$suffix',
                      style: TextStyle(
                        fontSize: 13.5,
                        fontWeight: FontWeight.w800,
                        color: sel ? Colors.white : Colors.white60,
                      ),
                    ),
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }
}
