import 'dart:math';

import 'package:flutter/material.dart';

import '../core/audio.dart';
import 'lobby_screen.dart';

/// Free-Fire-style login: full art background, centered button block only.
/// Buttons: Facebook / Guest / More — same visual weight as the reference.
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _in = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 520),
  )..forward();

  bool _leaving = false;

  @override
  void dispose() {
    _in.dispose();
    super.dispose();
  }

  void _continueAsGuest() {
    if (_leaving) return;
    setState(() => _leaving = true);
    Sfx.instance.uiClick();
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 420),
        pageBuilder: (_, a, __) =>
            FadeTransition(opacity: a, child: const LobbyScreen()),
      ),
    );
  }

  void _onFacebook() {
    // Offline game — Facebook is visual only; same path as Guest.
    _continueAsGuest();
  }

  void _onMore() {
    Sfx.instance.uiClick();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            'assets/ui/ff_loading_bg.jpg',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Image.asset(
              'assets/ui/ff_hero_bg.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) =>
                  Container(color: const Color(0xFF0A1520)),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            height: MediaQuery.sizeOf(context).height * 0.42,
            child: IgnorePointer(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      Colors.black.withValues(alpha: 0.35),
                      Colors.black.withValues(alpha: 0.55),
                    ],
                  ),
                ),
              ),
            ),
          ),
          SafeArea(
            child: LayoutBuilder(
              builder: (context, cts) {
                final blockW = min(cts.maxWidth * 0.55, 320.0);
                return Align(
                  alignment: const Alignment(0, 0.55),
                  child: FadeTransition(
                    opacity: _in,
                    child: SizedBox(
                      width: blockW,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          _pillButton(
                            width: blockW,
                            height: blockW * 0.145,
                            color: const Color(0xFF1877F2),
                            onTap: _onFacebook,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.facebook,
                                  color: Colors.white,
                                  size: blockW * 0.075,
                                ),
                                SizedBox(width: blockW * 0.03),
                                Text(
                                  'Sign in with Facebook',
                                  style: TextStyle(
                                    fontSize: blockW * 0.048,
                                    fontWeight: FontWeight.w700,
                                    color: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: blockW * 0.045),
                          Text(
                            'or',
                            style: TextStyle(
                              fontSize: blockW * 0.04,
                              color: Colors.white70,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: blockW * 0.045),
                          Row(
                            children: [
                              Expanded(
                                child: _pillButton(
                                  width: blockW,
                                  height: blockW * 0.13,
                                  color: const Color(0xFFE8EEF5),
                                  onTap: _continueAsGuest,
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(
                                        Icons.person_outline,
                                        size: blockW * 0.065,
                                        color: const Color(0xFF333B48),
                                      ),
                                      SizedBox(width: blockW * 0.025),
                                      Text(
                                        'Guest',
                                        style: TextStyle(
                                          fontSize: blockW * 0.048,
                                          fontWeight: FontWeight.w700,
                                          color: const Color(0xFF333B48),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              SizedBox(width: blockW * 0.04),
                              Expanded(
                                child: _pillButton(
                                  width: blockW,
                                  height: blockW * 0.13,
                                  color: const Color(0xFFE8EEF5),
                                  onTap: _onMore,
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(
                                        Icons.more_horiz,
                                        size: blockW * 0.07,
                                        color: const Color(0xFF333B48),
                                      ),
                                      SizedBox(width: blockW * 0.025),
                                      Text(
                                        'More',
                                        style: TextStyle(
                                          fontSize: blockW * 0.048,
                                          fontWeight: FontWeight.w700,
                                          color: const Color(0xFF333B48),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _pillButton({
    required double width,
    required double height,
    required Color color,
    required VoidCallback onTap,
    required Widget child,
  }) {
    return Material(
      color: color,
      borderRadius: BorderRadius.circular(height * 0.35),
      elevation: 2,
      shadowColor: Colors.black45,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(height * 0.35),
        child: SizedBox(
          height: height,
          width: width,
          child: Center(child: child),
        ),
      ),
    );
  }
}
