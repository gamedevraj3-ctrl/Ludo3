import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/audio.dart';
import '../core/theme.dart';
import '../game/characters.dart' as roster;
import '../widgets/avatar.dart';

/// Free-Fire-style profile: full character, ID card, ranked tabs, stats.
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({
    super.key,
    required this.name,
    required this.character,
    required this.onEditName,
    required this.onChangeCharacter,
  });

  final String name;
  final String character;
  final VoidCallback onEditName;
  final Future<void> Function() onChangeCharacter;

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late String _name = widget.name;
  late String _character = widget.character;
  int _tab = 0; // 0 Gallery 1 Overview 2 History

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
  }

  Future<void> _changeChar() async {
    await widget.onChangeCharacter();
    if (!mounted) return;
    // parent updates prefs; re-read via callback path — refresh from widget
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final c = roster.Characters.byName(_character);
    // ignore: unused if tab changes
    return Scaffold(
      backgroundColor: const Color(0xFF0B0E14),
      body: Stack(
        fit: StackFit.expand,
        children: [
          // dark studio bg
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF1A2230), Color(0xFF0A0C12)],
              ),
            ),
          ),
          // soft floor light
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            height: 120,
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.black.withValues(alpha: 0.55),
                  ],
                ),
              ),
            ),
          ),

          SafeArea(
            child: LayoutBuilder(
              builder: (context, cts) {
                final w = cts.maxWidth;
                final h = cts.maxHeight;
                return Row(
                  children: [
                    // LEFT tabs
                    SizedBox(
                      width: w * 0.13,
                      child: Column(
                        children: [
                          const SizedBox(height: 8),
                          _sideTab('GALLERY', 0),
                          _sideTab('OVERVIEW', 1),
                          _sideTab('HISTORY', 2),
                        ],
                      ),
                    ),
                    // CENTER character
                    Expanded(
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          CharacterBlend(
                            character: _character,
                            alignment: Alignment.bottomCenter,
                            widthFactor: 0.95,
                            fallbackSeed:
                                _character.codeUnits.fold(0, (a, b) => a + b),
                          ),
                          Positioned(
                            bottom: 12,
                            child: TextButton.icon(
                              onPressed: () async {
                                Sfx.instance.uiClick();
                                await widget.onChangeCharacter();
                              },
                              icon: const Icon(Icons.checkroom,
                                  color: Color(0xFFFFC93C), size: 16),
                              label: const Text(
                                'CHANGE CHARACTER',
                                style: TextStyle(
                                  color: Color(0xFFFFC93C),
                                  fontWeight: FontWeight.w800,
                                  fontSize: 11,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    // RIGHT info card
                    SizedBox(
                      width: w * 0.34,
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(8, 10, 14, 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            // header
                            Row(
                              children: [
                                const Spacer(),
                                const Text(
                                  'PROFILE',
                                  style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w900,
                                    color: Colors.white70,
                                    letterSpacing: 1.2,
                                  ),
                                ),
                                const Spacer(),
                                GestureDetector(
                                  onTap: () {
                                    Sfx.instance.uiClick();
                                    Navigator.pop(context);
                                  },
                                  child: Container(
                                    width: 28,
                                    height: 28,
                                    decoration: const BoxDecoration(
                                      color: Color(0xFFE0302C),
                                      shape: BoxShape.circle,
                                    ),
                                    child: const Icon(Icons.close,
                                        size: 16, color: Colors.white),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            // ID card
                            Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  colors: [
                                    Color(0xFF2A3548),
                                    Color(0xFF1A2230)
                                  ],
                                ),
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  color: const Color(0xFFFFC93C)
                                      .withValues(alpha: 0.45),
                                ),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        width: 40,
                                        height: 40,
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(6),
                                          gradient: const LinearGradient(
                                            colors: [
                                              Color(0xFF9B6BFF),
                                              Color(0xFF4A1A9E)
                                            ],
                                          ),
                                        ),
                                        child: Center(
                                          child: Text(
                                            _name.isNotEmpty
                                                ? _name[0].toUpperCase()
                                                : 'Y',
                                            style: const TextStyle(
                                              fontSize: 18,
                                              fontWeight: FontWeight.w900,
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              _name,
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              style: const TextStyle(
                                                fontSize: 15,
                                                fontWeight: FontWeight.w900,
                                                color: Colors.white,
                                              ),
                                            ),
                                            Text(
                                              'ID: ${_uidFromName(_name)}',
                                              style: const TextStyle(
                                                fontSize: 10,
                                                color: Colors.white60,
                                                fontWeight: FontWeight.w600,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      GestureDetector(
                                        onTap: () {
                                          Sfx.instance.uiClick();
                                          widget.onEditName();
                                        },
                                        child: const Icon(Icons.edit,
                                            size: 16, color: Colors.white54),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 10),
                                  Row(
                                    children: [
                                      _chip('Lv.1', const Color(0xFFE0B34A)),
                                      const SizedBox(width: 6),
                                      _chip(c.category.name.toUpperCase(),
                                          const Color(0xFF6BCBFF)),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 10),
                            // ranked row
                            Row(
                              children: [
                                Expanded(
                                  child: _rankCard(
                                      'RUSH RANKED', '—', Icons.flash_on),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: _rankCard(
                                      'CLASSIC', '—', Icons.emoji_events),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),
                            Expanded(
                              child: Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: Colors.black.withValues(alpha: 0.35),
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(color: Colors.white12),
                                ),
                                child: _tab == 0
                                    ? _galleryBody(c.name)
                                    : _tab == 1
                                        ? _overviewBody()
                                        : _historyBody(),
                              ),
                            ),
                            const SizedBox(height: 6),
                            const Text(
                              'Made by Lucifer',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w700,
                                color: Color(0xFFFFE082),
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _sideTab(String label, int i) {
    final sel = _tab == i;
    return GestureDetector(
      onTap: () {
        Sfx.instance.uiClick();
        setState(() => _tab = i);
      },
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.symmetric(vertical: 3, horizontal: 6),
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: sel ? const Color(0xFFE8A020) : Colors.black38,
          borderRadius: BorderRadius.circular(4),
        ),
        child: RotatedBox(
          quarterTurns: 0,
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w900,
              color: sel ? Colors.black : Colors.white70,
              letterSpacing: 0.6,
            ),
          ),
        ),
      ),
    );
  }

  Widget _chip(String t, Color c) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(
          color: c.withValues(alpha: 0.2),
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: c.withValues(alpha: 0.6)),
        ),
        child: Text(
          t,
          style: TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w800,
            color: c,
          ),
        ),
      );

  Widget _rankCard(String title, String value, IconData icon) => Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
        decoration: BoxDecoration(
          color: Colors.black.withValues(alpha: 0.35),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.white12),
        ),
        child: Column(
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 9,
                fontWeight: FontWeight.w800,
                color: Colors.white54,
                letterSpacing: 0.4,
              ),
            ),
            const SizedBox(height: 4),
            Icon(icon, size: 20, color: const Color(0xFFFFC93C)),
            Text(
              value,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w900,
                color: Colors.white,
              ),
            ),
          ],
        ),
      );

  Widget _galleryBody(String charName) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('EQUIPPED',
              style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                  color: Colors.white54)),
          const SizedBox(height: 8),
          Text(charName,
              style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                  color: Colors.white)),
          const SizedBox(height: 6),
          const Text(
            'Tap CHANGE CHARACTER to open the roster.',
            style: TextStyle(fontSize: 11, color: Colors.white60),
          ),
        ],
      );

  Widget _overviewBody() => const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('STATS',
              style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                  color: Colors.white54)),
          SizedBox(height: 10),
          _StatRow(label: 'Matches played', value: '0'),
          _StatRow(label: 'Wins', value: '0'),
          _StatRow(label: 'Booyah rate', value: '—'),
          _StatRow(label: 'Favourite mode', value: 'Rush'),
        ],
      );

  Widget _historyBody() => const Center(
        child: Text(
          'No match history yet.\nPlay a match to fill this tab.',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.white54, fontSize: 12),
        ),
      );

  static String _uidFromName(String n) {
    final h = n.codeUnits.fold(0, (a, b) => (a * 31 + b) & 0x7FFFFFFF);
    return (100000000 + (h % 900000000)).toString();
  }
}

class _StatRow extends StatelessWidget {
  const _StatRow({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(
            child: Text(label,
                style: const TextStyle(fontSize: 12, color: Colors.white70)),
          ),
          Text(value,
              style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  color: Colors.white)),
        ],
      ),
    );
  }
}
