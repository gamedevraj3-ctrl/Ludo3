import 'dart:math';

import 'package:flutter/material.dart';

import '../core/audio.dart';
import 'lobby_screen.dart';

/// Free-Fire-style login: full art background, centered button block only.
/// Buttons: Facebook / Guest / More — same visual weight as the reference.
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _in = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 520),
  )..forward();

  bool _leaving = false;

  @override
  void dispose() {
    _in.dispose();
    super.dispose();
  }

  void _continueAsGuest() {
    if (_leaving) return;
    setState(() => _leaving = true);
    Sfx.instance.uiClick();
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 420),
        pageBuilder: (_, a, __) =>
            FadeTransition(opacity: a, child: const LobbyScreen()),
      ),
    );
  }

  void _onFacebook() {
    // Offline game — Facebook is visual only; same path as Guest.
    _continueAsGuest();
  }

  void _onMore() {
    Sfx.instance.uiClick();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          Container(color: Colors.black),
          Positioned.fill(
            child: Image.asset(
              'assets/ui/ff_loading_bg.jpg',
              fit: BoxFit.contain,
              alignment: Alignment.center,
              errorBuilder: (_, __, ___) => Image.asset(
                'assets/ui/ff_hero_bg.jpg',
                fit: BoxFit.contain,
                alignment: Alignment.center,
                errorBuilder: (_, __, ___) =>
                    Container(color: const Color(0xFF0A1520)),
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            height: MediaQuery.sizeOf(context).height * 0.42,
            child: IgnorePointer(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      Colors.black.withValues(alpha: 0.35),
                      Colors.black.withValues(alpha: 0.55),
                    ],
                  ),
                ),
              ),
            ),
          ),
          SafeArea(
            child: LayoutBuilder(
              builder: (context, cts) {
                // FF-style centred bottom cluster
                final maxW = min(cts.maxWidth * 0.62, 360.0);
                final fbH = 48.0;
                final subH = 44.0;
                return Align(
                  alignment: const Alignment(0, 0.62),
                  child: FadeTransition(
                    opacity: _in,
                    child: SizedBox(
                      width: maxW,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // Facebook — bright blue full pill
                          Material(
                            color: const Color(0xFF1877F2),
                            borderRadius: BorderRadius.circular(fbH / 2),
                            elevation: 6,
                            shadowColor: Colors.black54,
                            child: InkWell(
                              onTap: _onFacebook,
                              borderRadius: BorderRadius.circular(fbH / 2),
                              child: SizedBox(
                                height: fbH,
                                width: maxW,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      width: 26,
                                      height: 26,
                                      decoration: const BoxDecoration(
                                        color: Colors.white,
                                        shape: BoxShape.circle,
                                      ),
                                      child: const Center(
                                        child: Text(
                                          'f',
                                          style: TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.w900,
                                            color: Color(0xFF1877F2),
                                            height: 1,
                                          ),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 10),
                                    const Text(
                                      'Sign in with Facebook',
                                      style: TextStyle(
                                        fontSize: 15.5,
                                        fontWeight: FontWeight.w700,
                                        color: Colors.white,
                                        letterSpacing: 0.2,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 14),
                          Text(
                            'or',
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: Colors.white.withValues(alpha: 0.85),
                              shadows: const [
                                Shadow(color: Colors.black54, blurRadius: 4),
                              ],
                            ),
                          ),
                          const SizedBox(height: 14),
                          // Guest + More — soft white pills
                          Row(
                            children: [
                              Expanded(
                                child: Material(
                                  color: const Color(0xFFF2F4F7),
                                  borderRadius: BorderRadius.circular(subH / 2),
                                  elevation: 4,
                                  shadowColor: Colors.black38,
                                  child: InkWell(
                                    onTap: _continueAsGuest,
                                    borderRadius:
                                        BorderRadius.circular(subH / 2),
                                    child: SizedBox(
                                      height: subH,
                                      child: const Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Icon(
                                            Icons.person_outline_rounded,
                                            size: 20,
                                            color: Color(0xFF3A4250),
                                          ),
                                          SizedBox(width: 6),
                                          Text(
                                            'Guest',
                                            style: TextStyle(
                                              fontSize: 14.5,
                                              fontWeight: FontWeight.w700,
                                              color: Color(0xFF3A4250),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Material(
                                  color: const Color(0xFFF2F4F7),
                                  borderRadius: BorderRadius.circular(subH / 2),
                                  elevation: 4,
                                  shadowColor: Colors.black38,
                                  child: InkWell(
                                    onTap: _onMore,
                                    borderRadius:
                                        BorderRadius.circular(subH / 2),
                                    child: SizedBox(
                                      height: subH,
                                      child: const Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Icon(
                                            Icons.more_horiz_rounded,
                                            size: 22,
                                            color: Color(0xFF3A4250),
                                          ),
                                          SizedBox(width: 6),
                                          Text(
                                            'More',
                                            style: TextStyle(
                                              fontSize: 14.5,
                                              fontWeight: FontWeight.w700,
                                              color: Color(0xFF3A4250),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
