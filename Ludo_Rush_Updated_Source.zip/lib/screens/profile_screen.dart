import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/audio.dart';
import '../game/characters.dart' as roster;
import '../widgets/avatar.dart';

/// Free Fire–style profile screen (same layout as reference):
/// left vertical tabs · centre full-body character · right ID / ranks / stats.
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({
    super.key,
    required this.name,
    required this.character,
    required this.onEditName,
    required this.onChangeCharacter,
  });

  final String name;
  final String character;
  final VoidCallback onEditName;
  final Future<void> Function() onChangeCharacter;

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late String _name = widget.name;
  late String _character = widget.character;
  int _tab = 0; // Gallery / Overview / History

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
  }

  String get _uid {
    final h = _name.codeUnits.fold(0, (a, b) => (a * 31 + b) & 0x7FFFFFFF);
    return (100000000 + (h % 900000000)).toString();
  }

  @override
  Widget build(BuildContext context) {
    final cat = roster.Characters.byName(_character).category.name.toUpperCase();
    return Scaffold(
      backgroundColor: const Color(0xFF0D1118),
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Studio background
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF1C2433), Color(0xFF0A0C10), Color(0xFF050608)],
              ),
            ),
          ),
          // Floor fade
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            height: 140,
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.black.withValues(alpha: 0.65),
                  ],
                ),
              ),
            ),
          ),

          SafeArea(
            child: LayoutBuilder(
              builder: (context, cts) {
                final w = cts.maxWidth;
                final h = cts.maxHeight;
                return Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // ========== LEFT TABS (yellow active like FF) ==========
                    SizedBox(
                      width: (w * 0.09).clamp(64.0, 88.0),
                      child: Column(
                        children: [
                          const SizedBox(height: 12),
                          _vTab('GALLERY', 0),
                          _vTab('OVERVIEW', 1),
                          _vTab('HISTORY', 2),
                          const Spacer(),
                          // chat bubble like FF bottom-left
                          Padding(
                            padding: const EdgeInsets.only(bottom: 12),
                            child: Icon(
                              Icons.chat_bubble_outline,
                              size: 22,
                              color: Colors.white.withValues(alpha: 0.45),
                            ),
                          ),
                        ],
                      ),
                    ),

                    // ========== CENTRE CHARACTER ==========
                    Expanded(
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Positioned.fill(
                            child: CharacterBlend(
                              character: _character,
                              alignment: Alignment.bottomCenter,
                              widthFactor: 0.72,
                              fallbackSeed:
                                  _character.codeUnits.fold(0, (a, b) => a + b),
                            ),
                          ),
                          Positioned(
                            bottom: 10,
                            child: TextButton.icon(
                              style: TextButton.styleFrom(
                                backgroundColor:
                                    Colors.black.withValues(alpha: 0.45),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 12, vertical: 6),
                              ),
                              onPressed: () async {
                                Sfx.instance.uiClick();
                                await widget.onChangeCharacter();
                              },
                              icon: const Icon(Icons.checkroom,
                                  color: Color(0xFFFFC93C), size: 15),
                              label: const Text(
                                'CHANGE CHARACTER',
                                style: TextStyle(
                                  color: Color(0xFFFFC93C),
                                  fontWeight: FontWeight.w800,
                                  fontSize: 11,
                                  letterSpacing: 0.6,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    // ========== RIGHT PANEL ==========
                    SizedBox(
                      width: w * 0.36,
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(6, 8, 12, 8),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            // Title + close
                            Row(
                              children: [
                                const Spacer(),
                                const Text(
                                  'PROFILE',
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w900,
                                    color: Colors.white70,
                                    letterSpacing: 2,
                                  ),
                                ),
                                const Spacer(),
                                GestureDetector(
                                  onTap: () {
                                    Sfx.instance.uiClick();
                                    Navigator.pop(context);
                                  },
                                  child: Container(
                                    width: 28,
                                    height: 28,
                                    decoration: const BoxDecoration(
                                      color: Color(0xFFE0302C),
                                      shape: BoxShape.circle,
                                    ),
                                    child: const Icon(Icons.close,
                                        size: 16, color: Colors.white),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),

                            // --- ID CARD (yellow border like FF) ---
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [
                                    Color(0xFF2A3548),
                                    Color(0xFF151C28),
                                  ],
                                ),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                  color: const Color(0xFFFFC93C),
                                  width: 1.4,
                                ),
                              ),
                              child: Row(
                                children: [
                                  // avatar thumb
                                  Container(
                                    width: 44,
                                    height: 44,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(6),
                                      border: Border.all(
                                          color: const Color(0xFFFFC93C),
                                          width: 1.5),
                                    ),
                                    clipBehavior: Clip.antiAlias,
                                    child: CharacterPortrait(
                                      character: _character,
                                      size: 44,
                                      radius: 5,
                                      borderWidth: 0,
                                      alignment: const Alignment(0, -0.4),
                                      fallbackSeed: _character.codeUnits
                                          .fold(0, (a, b) => a + b),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          children: [
                                            Expanded(
                                              child: Text(
                                                _name,
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                                style: const TextStyle(
                                                  fontSize: 15,
                                                  fontWeight: FontWeight.w900,
                                                  color: Colors.white,
                                                ),
                                              ),
                                            ),
                                            GestureDetector(
                                              onTap: () {
                                                Sfx.instance.uiClick();
                                                widget.onEditName();
                                              },
                                              child: const Icon(Icons.edit,
                                                  size: 14,
                                                  color: Colors.white54),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 2),
                                        Text(
                                          'English · $cat',
                                          style: const TextStyle(
                                            fontSize: 10,
                                            color: Colors.white60,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                        const SizedBox(height: 3),
                                        Row(
                                          children: [
                                            const Text(
                                              'Lv.1',
                                              style: TextStyle(
                                                fontSize: 11,
                                                fontWeight: FontWeight.w800,
                                                color: Color(0xFFE0B34A),
                                              ),
                                            ),
                                            const SizedBox(width: 8),
                                            Flexible(
                                              child: Text(
                                                'UID:$_uid',
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                                style: const TextStyle(
                                                  fontSize: 10,
                                                  fontWeight: FontWeight.w700,
                                                  color: Color(0xFF7EC8FF),
                                                  letterSpacing: 0.3,
                                                ),
                                              ),
                                            ),
                                            const Icon(Icons.copy,
                                                size: 12,
                                                color: Colors.white38),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 8),

                            // Ranked tabs
                            Row(
                              children: [
                                Expanded(
                                  child: _rankBox(
                                    'RUSH RANKED',
                                    Icons.flash_on_rounded,
                                    '—',
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Expanded(
                                  child: _rankBox(
                                    'CLASSIC',
                                    Icons.emoji_events_rounded,
                                    '—',
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),

                            // Season / emblem strip
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 8),
                              decoration: BoxDecoration(
                                color: Colors.black.withValues(alpha: 0.35),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: Colors.white12),
                              ),
                              child: Row(
                                children: [
                                  const Icon(Icons.shield,
                                      color: Color(0xFFFFC93C), size: 22),
                                  const SizedBox(width: 8),
                                  const Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'SEASON 1',
                                          style: TextStyle(
                                            fontSize: 9,
                                            fontWeight: FontWeight.w800,
                                            color: Colors.white54,
                                            letterSpacing: 0.5,
                                          ),
                                        ),
                                        Text(
                                          'ROOKIE EMBLEM',
                                          style: TextStyle(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w900,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  _miniStat(Icons.favorite, '0'),
                                  _miniStat(Icons.star, '0'),
                                  _miniStat(Icons.workspace_premium, '0'),
                                ],
                              ),
                            ),
                            const SizedBox(height: 8),

                            // Tab body
                            Expanded(
                              child: Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: Colors.black.withValues(alpha: 0.32),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: Colors.white10),
                                ),
                                child: _tab == 0
                                    ? _galleryPane()
                                    : _tab == 1
                                        ? _overviewPane()
                                        : _historyPane(),
                              ),
                            ),
                            const SizedBox(height: 4),
                            const Text(
                              'Made by Lucifer',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w800,
                                color: Color(0xFFFFE082),
                                letterSpacing: 0.6,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _vTab(String label, int i) {
    final sel = _tab == i;
    return GestureDetector(
      onTap: () {
        Sfx.instance.uiClick();
        setState(() => _tab = i);
      },
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.symmetric(vertical: 3, horizontal: 5),
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: sel ? const Color(0xFFE8A020) : const Color(0xFF1A1F28),
          borderRadius: BorderRadius.circular(3),
          border: sel
              ? null
              : Border.all(color: Colors.white.withValues(alpha: 0.08)),
        ),
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 9.5,
            fontWeight: FontWeight.w900,
            letterSpacing: 0.5,
            color: sel ? Colors.black : Colors.white60,
          ),
        ),
      ),
    );
  }

  Widget _rankBox(String title, IconData icon, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.35),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.white12),
      ),
      child: Column(
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 8.5,
              fontWeight: FontWeight.w800,
              color: Colors.white54,
              letterSpacing: 0.4,
            ),
          ),
          const SizedBox(height: 4),
          Icon(icon, size: 22, color: const Color(0xFFFFC93C)),
          Text(
            value,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w900,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  Widget _miniStat(IconData icon, String v) {
    return Padding(
      padding: const EdgeInsets.only(left: 8),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: Colors.white54),
          const SizedBox(width: 2),
          Text(
            v,
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w800,
              color: Colors.white70,
            ),
          ),
        ],
      ),
    );
  }

  Widget _galleryPane() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'EQUIPPED CHARACTER',
          style: TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w800,
            color: Colors.white54,
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          _character,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w900,
            color: Colors.white,
          ),
        ),
        const SizedBox(height: 6),
        const Text(
          'Battle Style: not configured',
          style: TextStyle(fontSize: 11, color: Colors.white54),
        ),
        const SizedBox(height: 4),
        const Text(
          'Social Style: not configured',
          style: TextStyle(fontSize: 11, color: Colors.white54),
        ),
        const Spacer(),
        Text(
          'I love Ludo Rush',
          style: TextStyle(
            fontSize: 12,
            fontStyle: FontStyle.italic,
            color: Colors.white.withValues(alpha: 0.55),
          ),
        ),
      ],
    );
  }

  Widget _overviewPane() {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'STATS',
          style: TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w800,
            color: Colors.white54,
            letterSpacing: 0.5,
          ),
        ),
        SizedBox(height: 10),
        _StatLine(label: 'Matches played', value: '0'),
        _StatLine(label: 'Wins', value: '0'),
        _StatLine(label: 'Booyah rate', value: '—'),
        _StatLine(label: 'Favourite mode', value: 'Rush'),
        _StatLine(label: 'Tokens captured', value: '0'),
      ],
    );
  }

  Widget _historyPane() {
    return const Center(
      child: Text(
        'No match history yet.\nPlay a match to fill this tab.',
        textAlign: TextAlign.center,
        style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.4),
      ),
    );
  }
}

class _StatLine extends StatelessWidget {
  const _StatLine({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: const TextStyle(fontSize: 12, color: Colors.white70),
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w800,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}
